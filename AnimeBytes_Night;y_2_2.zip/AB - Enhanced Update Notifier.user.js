// ==UserScript==
// @name         AB - Enhanced Update Notifier
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.8
// @description  Shows bell icon + one-time dismissible popup when update available (bell re-opens popup anytime)
// @match        https://animebytes.tv/*
// @require      https://code.jquery.com/jquery-3.6.0.min.js
// @require      https://gist.github.com/raw/2625891/waitForKeyElements.js
// @icon         http://animebytes.tv/favicon.ico
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// ==/UserScript==

(function() {
    'use strict';
    const SCRIPT_VERSION = "2.2";
    const VERSION_URL = `https://raw.githubusercontent.com/MitsukiHaruko/waitForKeyElements/refs/heads/main/AnimeBytes%20Nightly%20Update%20Notifier?v=${Date.now()}`;
    const THREAD_URL = "https://animebytes.tv/forums.php?action=viewthread&threadid=30781";
    const DISMISSED_KEY = "ab_nightly_dismissed_version";

    // ── Your original styling, unchanged ──
    GM_addStyle(`
    #nightly-update-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 999999;
        max-width: 90vw;
        width: fit-content;
        min-width: 320px;
        box-sizing: border-box;
    }
    #nightly-update-header {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        padding: 12px 16px 4px;
    }
    #nightly-update-bell {
        font-size: 2.0em;
    }
    #nightly-update-close {
        position: absolute;
        right: 10px;
        top: 2px;
        font-size: 28px;
        line-height: 1;
        cursor: pointer;
        background: none;
        border: none;
        padding: 0;
    }
    #nightly-update-body {
        padding: 12px 16px 16px;
        text-align: center;
    }
    #nightly-update-body a {
        font-weight: bold;
        text-decoration: underline;
    }

    #changelog:empty {
        display: none;
    }
    `);

    let popupOpen = false;

    function showUpdatePopup(latestVersion, zipUrl, changelogLines) {
        if (popupOpen) return;
        popupOpen = true;

        const popup = document.createElement("div");
        popup.id = "nightly-update-popup";

        // Build changelog HTML (if any lines exist)
        let changelogHTML = "";
        if (changelogLines.length > 0) {
            changelogHTML = `
                <div id="changelog"><strong>What's new:</strong><br>
${changelogLines.map(line => line.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')).join("<br>")}</div>
            `;
        }

        popup.innerHTML = `
            <div id="nightly-update-header">
                <span id="nightly-update-bell">🔔</span>
            </div>
            <button id="nightly-update-close" title="Don't show again for this version">×</button>
            <div id="nightly-update-body">
                A new Nightly version is available!<br><br>
                <strong>${SCRIPT_VERSION} → ${latestVersion}</strong><br><br>
                <a href="${zipUrl}" target="_blank" rel="noopener">ZIP</a><br><br>
${changelogHTML}
                <details id="update-instructions">
                    <summary>UPDATE INSTRUCTIONS</summary><br>
                    <div class="instructions-content">In the Tampermonkey Extensions settings (called Dashboard), navigate to the Utilities tab and import the ZIP with 'import from file'<br>
<a href="${THREAD_URL}" target="_blank" rel="noopener">Visit Nightly thread</a></div>
                </details>
            </div>
        `;

        document.body.appendChild(popup);

        // Close button → dismiss permanently
        popup.querySelector("#nightly-update-close").addEventListener("click", () => {
            GM_setValue(DISMISSED_KEY, SCRIPT_VERSION);
            popup.remove();
            popupOpen = false;
        });

        // Thread link → also dismiss (original behavior)
        popup.querySelectorAll("#nightly-update-body a").forEach(link => {
            if (link.href.includes(THREAD_URL)) {
                link.addEventListener("click", () => {
                    GM_setValue(DISMISSED_KEY, SCRIPT_VERSION);
                });
            }
        });

        // Click outside to close (no dismiss)
        const outsideHandler = e => {
            if (!popup.contains(e.target)) {
                popup.remove();
                popupOpen = false;
                document.removeEventListener("click", outsideHandler);
            }
        };
        setTimeout(() => document.addEventListener("click", outsideHandler), 100);
    }

    function createUpdateBell(latestVersion, zipUrl, changelogLines) {
        const bell = document.createElement("span");
        bell.innerHTML = "🔔";
        bell.className = "update-bell";
        bell.title = `Update available: v${latestVersion}`;
        bell.style.cursor = "pointer";
        bell.addEventListener("click", e => {
            e.stopPropagation();
            showUpdatePopup(latestVersion, zipUrl, changelogLines);
        });
        return bell;
    }

    function checkForUpdates(jNode) {
        GM_xmlhttpRequest({
            method: "GET",
            url: VERSION_URL,
            headers: { "Cache-Control": "no-cache" },
            onload: function(response) {
                const lines = response.responseText.split('\n').map(l => l.trim()).filter(l => l);

                if (lines.length < 2) {
                    console.warn("Version file missing version or ZIP URL");
                    return;
                }

                const latestVersion = lines[0];
                const zipUrl = lines[1];
                // Everything from line 3 onwards = changelog
                const changelogLines = lines.slice(2);

                if (!/^\d+\.\d+$/.test(latestVersion)) {
                    console.warn("Invalid version format:", latestVersion);
                    return;
                }

                if (latestVersion !== SCRIPT_VERSION && jNode.length) {
                    const bell = createUpdateBell(latestVersion, zipUrl, changelogLines);
                    jNode[0].insertAdjacentElement("beforebegin", bell);

                    if (GM_getValue(DISMISSED_KEY, "") !== SCRIPT_VERSION) {
                        showUpdatePopup(latestVersion, zipUrl, changelogLines);
                    }
                }
            },
            onerror: function(err) {
                console.error("Update check failed", err);
            }
        });
    }

    waitForKeyElements("#username_menu", checkForUpdates, true);
})();