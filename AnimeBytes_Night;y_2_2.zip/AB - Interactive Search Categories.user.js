// ==UserScript==
// @name          AB - Interactive Search Categories
// @namespace     AnimeBytes Nightly
// @version       1.0
// @author        TalkingJello
// @description   Highlights the current subcategories with a hardcoded color and preserves your search, along with any filters, when switching between "Anime" and "Music" or their subcategories on AB search.
// @icon          http://animebytes.tv/favicon.ico
// @license       MIT
// @match         *://animebytes.tv/torrents.php*
// @match         *://animebytes.tv/torrents2.php*
// @match         *://animebytes.tv/user.php?action=edit*
// ==/UserScript==

(function() {
    'use strict';

    // Hardcoded color settings
    const settings = {
        subcategoriesActiveColor: "#fe2a73"
    };

    // Only run on search pages
    if (window.location.pathname === "/user.php") {
        return;
    }

    // Helper function to extract category key from a link
    function categoryKeyFromLink(link) {
        for (const key of [...(new URL(link).searchParams.keys())]) {
            if (key.startsWith('filter_cat[')) {
                return key;
            }
        }
        return '';
    }

    // Prep work
    const currentCategory = categoryKeyFromLink(window.location.href);
    const categoryNumber = parseInt(currentCategory.slice(11, -1));

    // Move inside Anime or inside Music between categories
    $('#categories > li > a').each(function () {
        const thisLinkCategory = categoryKeyFromLink($(this).prop('href'));

        // Make URL without category filter
        const targetUrl = new URL(window.location.href);
        if (currentCategory) {
            targetUrl.searchParams.delete(currentCategory);
        }

        // Uncategory search
        if (thisLinkCategory === currentCategory) {
            $(this).css('color', settings.subcategoriesActiveColor);
            $(this).prop('href', targetUrl.toString());
            return;
        }

        // Intentionally not editing search params to avoid encoding the "[]"
        if (targetUrl.search) {
            targetUrl.search += `&${thisLinkCategory}=1`;
        } else {
            targetUrl.search = `?${thisLinkCategory}=1`;
        }
        $(this).prop('href', targetUrl.toString());
    });

    // Move between Anime and Music
    const animeLink = $('#browse_nav_sections > h2 > a[href="/torrents.php"]');
    const musicLink = $('#browse_nav_sections > h2 > a[href="/torrents2.php"]');

    // Disable active link navigation
    const isMusic = window.location.pathname.startsWith('/torrents2.php');
    const activeLink = isMusic ? musicLink : animeLink;
    activeLink.css('cursor', 'default');
    activeLink.attr('href', 'javascript:void(0);');

    // Hide category-specific filters for filtered-out categories
    if (!isMusic && categoryNumber) {
        $(`#accordion > h3:not(#ui-id-${categoryNumber*2+1}):not(#ui-id-1)`).hide();
    }

    // Patch href for Anime/Music links
    const ANIME_MUSIC_SHARED_PARAMS = ['year', 'year2', 'tags', 'sort', 'way', 'showhidden', 'freeleech'];
    const params = new URL(window.location.href).searchParams;
    for (const [key, value] of [...params.entries()]) {
        if (isMusic && key === 'groupname') {
            params.set('searchstr', value);
        }
        if (!isMusic && key === 'searchstr') {
            params.set('groupname', value);
        }
        if (!ANIME_MUSIC_SHARED_PARAMS.includes(key)) {
            params.delete(key);
        }
    }

    if (isMusic) {
        animeLink.attr('href', `/torrents.php?${params.toString()}`);
    } else {
        musicLink.attr('href', `/torrents2.php?${params.toString()}`);
    }
})();