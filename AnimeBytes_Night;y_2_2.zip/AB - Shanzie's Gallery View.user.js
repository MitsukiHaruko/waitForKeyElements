// ==UserScript==
// @name         AB - Shanzie's Gallery View
// @namespace    AnimeBytes Nightly
// @version      1.0
// @description  Transforms torrent listings on AnimeBytes into a gallery with a toggle, color-coded tags, hover-reveal descriptions, and persistent view state. Links open in the same tab.
// @author       Shanzie
// @match        https://animebytes.tv/torrents.php*
// @match        https://animebytes.tv/torrents2.php*
// @grant        GM_addStyle
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

(function() {
    'use strict';

    const LOCALSTORAGE_KEY_GALLERY_VIEW = 'animebytesGalleryViewActive_v1'; 

    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
    // ---  CSS STYLES FOR GALLERY, TOGGLE, TAGS, DESCRIPTION ---
    // --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---
    const styles = `
        .ab-gallery-container { 
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            padding: 20px;
            justify-content: center;
            max-width: 100%; 
        }
        .gallery-item {
            width: 240px; 
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            transition: transform 0.2s ease-out, box-shadow 0.2s ease-out;
            display: flex;
            flex-direction: column;
            position: relative; 
            overflow: hidden; 
        }
        .gallery-item:hover {
            transform: scale(1.03);
            box-shadow: 0 6px 18px rgba(0,0,0,0.6);
            overflow: visible; 
        }

        .gallery-item-clickable-area { 
            text-decoration: none;
            color: inherit;
            display: flex; 
            flex-direction: column; 
            position: relative; 
            z-index: 2; 
        }

        .gallery-item img.gallery-cover-image {
            width: 100%;
            height: 375px;
            object-fit: cover;
            display: block;
            background-color: #333;
        }
        .gallery-item .title-container {
            padding: 10px 8px;
            text-align: center;
            background-color: rgba(0,0,0,0.6);
            color: #fff;
            font-size: 0.9em;
            min-height: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
        }
        .gallery-item .title-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.3;
        }

        .gallery-tags-container {
            padding: 8px 8px 4px 8px;
            text-align: center;
            border-top: 1px solid #444;
            min-height: 28px;
            position: relative; 
            z-index: 1; 
        }
        .gallery-tag {
            display: inline-block;
            background-color: #4a5568; 
            color: #e2e8f0; 
            padding: 3px 7px;
            margin: 2px;
            border-radius: 4px;
            font-size: 0.78em;
            line-height: 1.2;
            text-transform: capitalize;
        }
        
        .gallery-description-on-hover {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            color: #e8e8e8; 
            padding: 12px;
            box-sizing: border-box;
            max-height: 75%; 
            overflow-y: auto;
            opacity: 0;
            visibility: hidden;
            transform: translateY(100%); 
            transition: opacity 0.25s ease-out, transform 0.25s ease-out, visibility 0s linear 0.25s;
            z-index: 3; 
            font-size: 0.82em; 
            line-height: 1.45;
            border-top: 1px solid #555; 
        }
        .gallery-item:hover .gallery-description-on-hover {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            transition-delay: 0.1s, 0.1s, 0.1s; 
        }
        .gallery-description-on-hover::-webkit-scrollbar { width: 6px; }
        .gallery-description-on-hover::-webkit-scrollbar-track { background: #383838; }
        .gallery-description-on-hover::-webkit-scrollbar-thumb { background: #666; border-radius: 3px; }
        .gallery-description-on-hover::-webkit-scrollbar-thumb:hover { background: #888; }

        .original-torrent-group-hidden { display: none !important; }

        #gallery-toggle-button {
            display: block; margin: 15px auto 20px; padding: 10px 20px;
            font-size: 1em;
            border: none; border-radius: 6px; cursor: pointer;
            transition: background-color 0.2s ease-in-out;
        }
        
    `;

    const dynamicLayoutStyles = `
        #content.gallery-content-wrapper-active {
            max-width: 1600px !important; 
            width: auto !important; 
            margin-left: auto !important;
            margin-right: auto !important;
        }

        #content.gallery-content-wrapper-active > .thin,
        #content.gallery-content-wrapper-active > div.thin {
            max-width: 100% !important; 
            width: 100% !important; 
        }

        #content.gallery-content-wrapper-active > .thin > #browse_nav_bottom {
            max-width: 1100px !important; 
            width: 100%; 
            margin-left: auto !important;
            margin-right: auto !important;
        }
    `;

    const tagColors = {
        'action': '#FF6347', // Tomato
        'adventure': { background: '#FFD700', color: '#333333' }, // Gold
        'classic': '#D2B48C', // Tan
        'comedy': { background: '#90EE90', color: '#333333' }, // LightGreen
        'contemporary.fantasy': '#DA70D6', // Orchid
        'drama': '#4682B4', // SteelBlue
        'ecchi': { background: '#FFB6C1', color: '#333333' }, // LightPink
        'fantasy': '#8A2BE2', // BlueViolet
        'fighting': '#B22222', // Firebrick
        'gender.bender': '#FF69B4', // HotPink
        'harem': { background: '#FFA07A', color: '#333333' }, // LightSalmon
        'historical': '#8B4513', // SaddleBrown
        'isekai': '#20B2AA', // LightSeaGreen
        'love.polygon': { background: '#FFC0CB', color: '#333333' }, // Pink
        'magic': '#9370DB', // MediumPurple
        'mahou.shoujo': '#DB7093', // PaleVioletRed
        'mecha': '#708090', // SlateGray
        'military': '#556B2F', // DarkOliveGreen
        'music': '#1E90FF', // DodgerBlue
        'mystery': { background: '#4B0082', color: '#FFFFFF' }, // Indigo
        'new': { background: '#FFFFFF', color: '#333333', border: '1px solid #ccc' }, // White
        'piloted.robot': '#607D8B', // Blue Grey
        'psychological': { background: '#2F4F4F', color: '#FFFFFF' }, // DarkSlateGray
        'romance': '#FF1493', // DeepPink
        'school.life': { background: '#87CEEB', color: '#333333' }, // SkyBlue
        'science.fiction': '#00CED1', // DarkTurquoise
        'seinen': '#696969', // DimGray
        'shoujo': { background: '#FFDAE9', color: '#333333' }, // Light Pink variant
        'shounen': '#FFA500', // Orange
        'shounen.ai': { background: '#ADD8E6', color: '#333333' }, // LightBlue
        'slapstick': { background: '#FFFFE0', color: '#555555' }, // LightYellow
        'slice.of.life': { background: '#98FB98', color: '#333333' }, // PaleGreen
        'steampunk': '#CD853F', // Peru
        'super.power': '#DC143C', // Crimson
        'supernatural': { background: '#483D8B', color: '#FFFFFF' }, // DarkSlateBlue
        'thriller': { background: '#1A1A1A', color: '#FFFFFF' }, // Very Dark Gray/Almost Black
        'underworld': { background: '#333333', color: '#FFFFFF' }, // Darker Gray
        'violence': '#8B0000', // DarkRed
        'yaoi': { background: '#AFEEEE', color: '#333333' }, // PaleTurquoise
        'yuri': { background: '#F08080', color: '#333333' }  // LightCoral
    };

    let galleryContainerElement = null;
    let originalTorrentGroupElements = null;
    let isGalleryViewActive = true; 
    let toggleButtonElement = null;

    function buildGalleryItems() {
        if (!galleryContainerElement || !originalTorrentGroupElements) return 0;
        galleryContainerElement.innerHTML = '';

        let itemsAdded = 0;
        originalTorrentGroupElements.forEach((groupDiv) => {
            try {
                const coverImgElement = groupDiv.querySelector('div.group_img span.mainimg a img');
                let coverImageUrl = coverImgElement ? coverImgElement.src : null;

                const torrentLinkElement = groupDiv.querySelector('div.group_img span.mainimg a');
                const torrentPageUrl = torrentLinkElement ? new URL(torrentLinkElement.href, window.location.origin).href : '#';

                let torrentTitle = 'Untitled';
                if (coverImgElement) {
                    torrentTitle = coverImgElement.alt || coverImgElement.title || 'Untitled';
                }
                if (torrentTitle === 'Untitled' || torrentTitle.trim() === '') {
                    const titleStrongAElement = groupDiv.querySelector('div.group_main span.group_title strong a');
                    if (titleStrongAElement) torrentTitle = titleStrongAElement.textContent.trim();
                }
                const tempTitleDiv = document.createElement('div');
                tempTitleDiv.innerHTML = torrentTitle;
                torrentTitle = tempTitleDiv.textContent || tempTitleDiv.innerText || 'Untitled';

                if (!coverImageUrl) {
                    coverImageUrl = `https://placehold.co/240x375/282828/555555?text=${encodeURIComponent(torrentTitle.substring(0,10))}`;
                } else if (coverImageUrl.includes('static/common/noartwork')) {
                    coverImageUrl = `https://placehold.co/240x375/282828/555555?text=No+Cover`;
                } else if (coverImageUrl && !coverImageUrl.startsWith('http')) {
                    coverImageUrl = new URL(coverImageUrl, window.location.origin).href;
                }

                const tagsContainer = groupDiv.querySelector('div.tags_sm div.tags');
                let tagsHTML = '<div class="gallery-tags-container">';
                if (tagsContainer) {
                    const tagLinks = tagsContainer.querySelectorAll('a');
                    const tagNames = Array.from(tagLinks).map(a => a.textContent.trim().toLowerCase()).slice(0, 4);
                    if (tagNames.length > 0) {
                        tagsHTML += tagNames.map(tag => {
                            const colorStyle = tagColors[tag];
                            let styleAttr = '';
                            if (typeof colorStyle === 'object') {
                                styleAttr = `background-color: ${colorStyle.background};`;
                                if (colorStyle.color) styleAttr += ` color: ${colorStyle.color};`;
                                if (colorStyle.border) styleAttr += ` border: ${colorStyle.border};`;
                            } else if (typeof colorStyle === 'string') {
                                styleAttr = `background-color: ${colorStyle};`;
                            }
                            return `<span class="gallery-tag" style="${styleAttr.trim()}">${tag.replace(/\./g, ' ')}</span>`;
                        }).join(' ');
                    } else {
                        tagsHTML += '<span style="font-size:0.8em; color:#777;">No tags</span>';
                    }
                } else {
                     tagsHTML += '<span style="font-size:0.8em; color:#777;">No tags</span>';
                }
                tagsHTML += '</div>';

                const descriptionElement = groupDiv.querySelector('div.torrent_desc');
                const descriptionText = descriptionElement ? descriptionElement.innerHTML.trim() : 'No description available.'; 

                const galleryItem = document.createElement('div');
                galleryItem.className = 'gallery-item';
                // Removed target="_blank" from the <a> tag below
                galleryItem.innerHTML = `
                    <a href="${torrentPageUrl}" title="${torrentTitle}" class="gallery-item-clickable-area">
                        <img src="${coverImageUrl}" alt="${torrentTitle}" class="gallery-cover-image" onerror="this.onerror=null;this.src='https://placehold.co/240x375/333333/777777?text=Load+Error';">
                        <div class="title-container">
                            <span class="title-text">${torrentTitle}</span>
                        </div>
                    </a>
                    ${tagsHTML}
                    <div class="gallery-description-on-hover">${descriptionText}</div>
                `;
                galleryContainerElement.appendChild(galleryItem);
                itemsAdded++;
            } catch (e) {
                console.error("AnimeBytes Gallery: Error processing a torrent group div:", e, groupDiv);
            }
        });
        return itemsAdded;
    }

    function applyCurrentView() {
        if (!galleryContainerElement || !originalTorrentGroupElements || !toggleButtonElement) return;
        const contentDiv = document.getElementById('content'); 

        if (isGalleryViewActive) {
            galleryContainerElement.style.display = 'flex';
            originalTorrentGroupElements.forEach(div => div.classList.add('original-torrent-group-hidden'));
            toggleButtonElement.textContent = 'Show Original View';
            if(contentDiv) contentDiv.classList.add('gallery-content-wrapper-active');

        } else {
            galleryContainerElement.style.display = 'none';
            originalTorrentGroupElements.forEach(div => div.classList.remove('original-torrent-group-hidden'));
            toggleButtonElement.textContent = 'Show Gallery View';
            if(contentDiv) contentDiv.classList.remove('gallery-content-wrapper-active');
        }
    }

    function handleToggleViewClick() {
        isGalleryViewActive = !isGalleryViewActive;
        localStorage.setItem(LOCALSTORAGE_KEY_GALLERY_VIEW, isGalleryViewActive.toString());
        applyCurrentView();
    }

    function initializeGalleryMod() {
        const savedPreference = localStorage.getItem(LOCALSTORAGE_KEY_GALLERY_VIEW);
        if (savedPreference !== null) {
            isGalleryViewActive = (savedPreference === 'true');
        }
        
        GM_addStyle(styles + dynamicLayoutStyles); 

        originalTorrentGroupElements = document.querySelectorAll('div.group_cont.box');
        if (originalTorrentGroupElements.length === 0) {
            console.log("AnimeBytes Gallery: No torrent group divs found.");
            return;
        }

        galleryContainerElement = document.createElement('div');
        galleryContainerElement.className = 'ab-gallery-container'; 
        galleryContainerElement.style.display = 'none'; 

        const itemsAdded = buildGalleryItems();

        if (itemsAdded > 0) {
            toggleButtonElement = document.createElement('button');
            toggleButtonElement.id = 'gallery-toggle-button';
            toggleButtonElement.addEventListener('click', handleToggleViewClick);

            const firstGroup = originalTorrentGroupElements[0];
            let insertionPoint = firstGroup ? firstGroup.parentNode : null; 
            let referenceNodeForInsertion = firstGroup; 
            
            if (!insertionPoint || !referenceNodeForInsertion) {
                insertionPoint = document.querySelector('#content > .thin, #content > div.thin');
                if (insertionPoint) {
                    referenceNodeForInsertion = insertionPoint.firstChild;
                     console.warn("AnimeBytes Gallery: Used .thin as fallback for button and gallery insertion point.");
                } else {
                    insertionPoint = document.body;
                    referenceNodeForInsertion = document.body.firstChild;
                    console.warn("AnimeBytes Gallery: Used absolute fallback (body) for button and gallery insertion.");
                }
            }
            
            if (insertionPoint) {
                insertionPoint.insertBefore(galleryContainerElement, referenceNodeForInsertion);
                insertionPoint.insertBefore(toggleButtonElement, galleryContainerElement); 
            } else {
                console.error("AnimeBytes Gallery: Could not find a valid insertion point for the gallery and button.");
                return; 
            }

            applyCurrentView(); 
            console.log(`AnimeBytes Gallery: Initialized. View: ${isGalleryViewActive ? 'Gallery' : 'Original'}`);
        } else {
            console.log("AnimeBytes Gallery: No items could be added to the gallery.");
        }
    }

    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', initializeGalleryMod);
    } else {
        initializeGalleryMod();
    }
})();
