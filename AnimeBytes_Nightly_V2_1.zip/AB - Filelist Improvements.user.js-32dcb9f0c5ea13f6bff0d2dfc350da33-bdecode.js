
/*
The MIT License (MIT)
=====================

Copyright (c) 2010 Mark Schmale

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
Modified by WeebDataHoarder to work on browser
 */

const INTEGER_START = 0x69 // 'i'
const STRING_DELIM = 0x3A // ':'
const DICTIONARY_START = 0x64 // 'd'
const LIST_START = 0x6C // 'l'
const END_OF_TYPE = 0x65 // 'e'

/**
 * replaces parseInt(buffer.toString('ascii', start, end)).
 * For strings with less then ~30 charachters, this is actually a lot faster.
 *
 * @param {Uint8Array} data
 * @param {Number} start
 * @param {Number} end
 * @return {Number} calculated number
 */
function getIntFromBuffer (data, start, end) {
    let sum = 0
    let sign = 1

    for (let i = start; i < end; i++) {
        const num = data[i]

        if (num < 58 && num >= 48) {
            sum = sum * 10 + (num - 48)
            continue
        }

        if (i === start && num === 43) { // +
            continue
        }

        if (i === start && num === 45) { // -
            sign = -1
            continue
        }

        if (num === 46) { // .
            // its a float. break here.
            break
        }

        throw new Error('not a number: buffer[' + i + '] = ' + num)
    }

    return sum * sign
}

/**
 * Decodes bencoded data.
 *
 * @param  {Uint8Array} data
 * @param  {Number} start (optional)
 * @param  {Number} end (optional)
 * @return {Object|Array|Uint8Array|String|Number}
 */
function bdecode (data, start, end) {
    if (data == null || data.length === 0) {
        return null
    }

    if (typeof start !== 'number') {
        start = undefined
    }

    if (typeof end !== 'number') {
        end = undefined
    }

    bdecode.position = 0

    bdecode.data = !(data instanceof Uint8Array)
        ? Uint8Array.from(data)
        : data.slice(start, end)

    bdecode.bytes = bdecode.data.length

    return bdecode.next()
}

bdecode.bytes = 0
bdecode.position = 0
bdecode.data = null

bdecode.fields = {
    name: {
        type: "string",
        utf8: true
    },
    path: {
        type: "string",
        utf8: true
    },
    comment: {
        type: "string",
        utf8: true
    },
    source: {
        type: "string",
        utf8: true
    },
    "created by": {
        type: "string",
        utf8: true
    },
    announce: {
        type: "string",
        utf8: true
    },
    info: {
        hash: true
    }
}


bdecode.next = function (key) {
    switch (bdecode.data[bdecode.position]) {
        case DICTIONARY_START:
            const startPosition = bdecode.position;
            const d = bdecode.dictionary();
            if(key in bdecode.fields){
                const f = bdecode.fields[key];
                if("hash" in f && f.hash && "subtle" in crypto){
                    d["__hash"] = crypto.subtle.digest("SHA-1", bdecode.data.slice(startPosition, bdecode.position));
                }
                return d;
            }else{
                return d;
            }
        case LIST_START:
            return bdecode.list(key)
        case INTEGER_START:
            return bdecode.integer()
        default:
            const b = bdecode.buffer();
            if(key in bdecode.fields){
                const f = bdecode.fields[key];
                if(f.type === "string"){
                    return bdecode.valueToString(b, "utf8" in f && f.utf8);
                }
                return b;
            }else{
                return b;
            }
    }
}

/**
 *
 * @param {Number} chr
 * @returns {Number}
 */
bdecode.find = function (chr) {
    let i = bdecode.position
    const c = bdecode.data.length
    const d = bdecode.data

    while (i < c) {
        if (d[i] === chr) return i
        i++
    }

    throw new Error(
        'Invalid data: Missing delimiter "' +
        String.fromCharCode(chr) + '" [0x' +
        chr.toString(16) + ']'
    )
}

bdecode.valueToString = function (data, utf8 = false) {
    if(!utf8){
        return String.fromCharCode.apply(null, data);
    }


    /* utf.js - UTF-8 <=> UTF-16 convertion
     *
     * Copyright (C) 1999 Masanao Izumo <iz@onicos.co.jp>
     * Version: 1.0
     * LastModified: Dec 25 1999
     * This library is free.  You can redistribute it and/or modify it.
     */

    let out, i, len, c;
    let char2, char3;

    out = "";
    len = data.length;
    i = 0;
    while(i < len) {
        c = data[i++];
        switch(c >> 4)
        {
            case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
            // 0xxxxxxx
            out += String.fromCharCode(c);
            break;
            case 12: case 13:
            // 110x xxxx   10xx xxxx
            char2 = data[i++];
            out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
            break;
            case 14:
                // 1110 xxxx  10xx xxxx  10xx xxxx
                char2 = data[i++];
                char3 = data[i++];
                out += String.fromCharCode(((c & 0x0F) << 12) |
                    ((char2 & 0x3F) << 6) |
                    ((char3 & 0x3F) << 0));
                break;
        }
    }

    return out;

}

bdecode.dictionary = function () {
    bdecode.position++

    const dict = {}

    while (bdecode.data[bdecode.position] !== END_OF_TYPE) {
        const key = bdecode.valueToString(bdecode.buffer());
        dict[key] = bdecode.next(key)
    }

    bdecode.position++

    return dict
}

bdecode.list = function (key) {
    bdecode.position++

    const lst = []

    while (bdecode.data[bdecode.position] !== END_OF_TYPE) {
        lst.push(bdecode.next(key))
    }

    bdecode.position++

    return lst
}

bdecode.integer = function () {
    const end = bdecode.find(END_OF_TYPE)
    const number = getIntFromBuffer(bdecode.data, bdecode.position + 1, end)

    bdecode.position += end + 1 - bdecode.position

    return number
}

bdecode.buffer = function () {
    let sep = bdecode.find(STRING_DELIM)
    const length = getIntFromBuffer(bdecode.data, bdecode.position, sep)
    const end = ++sep + length

    bdecode.position = end

    return bdecode.data.slice(sep, end)
}