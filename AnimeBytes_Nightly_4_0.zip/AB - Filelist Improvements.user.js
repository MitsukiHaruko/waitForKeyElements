// ==UserScript==
// @name         AB - Filelist Improvements
// @namespace    AnimeBytes Nightly

// @author       neesrod, WeebDataHoarder, Mitsuki Haruko
// @version      1.0
// @description  Tree-style filelist with root folder, exact sizes on hover, piece info, and Info Hash
// @homepageURL  https://animebytes.tv/forums.php?action=viewthread&threadid=29050
// @homepageURL  https://animebytes.tv/forums.php?action=viewthread&threadid=27561

// @match        https://animebytes.tv/torrents.php?*id=*
// @match        https://animebytes.tv/torrents2.php?*id=*
// @updateURL https://gist.github.com/MitsukiHaruko/67475c9ff136a17b76c4900a238736a8/raw/AB_Filelist-Improvements.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/67475c9ff136a17b76c4900a238736a8/raw/AB_Filelist-Improvements.user.js
// @exclude      https://animebytes.tv/torrents*groupid=*
// @icon         https://animebytes.tv/favicon.ico
// @grant        none
// @run-at       document-end
// ==/UserScript==

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const whitespaceRE = /[ \t\r\n]/g;
const handledTorrentIds = Object.create(null);
let id_count = 6001;
const locale = "xh";

function bdecode(buffer) {
    if (!(buffer instanceof Uint8Array)) {
        if (buffer instanceof ArrayBuffer) buffer = new Uint8Array(buffer);
        else throw new Error("Invalid input");
    }
    let pos = 0;
    const data = buffer;

    function readUntil(byte) {
        const start = pos;
        while (pos < data.length && data[pos] !== byte) pos++;
        if (pos >= data.length) throw new Error("Unexpected EOF");
        return data.slice(start, pos++);
    }

    function decode() {
        if (pos >= data.length) throw new Error("Unexpected EOF");
        const type = data[pos];
        if (type === 105) { // i
            pos++;
            const numBytes = readUntil(101);
            return parseInt(decoder.decode(numBytes), 10);
        }
        if (type === 108) { // l
            pos++;
            const list = [];
            while (data[pos] !== 101) list.push(decode());
            pos++;
            return list;
        }
        if (type === 100) { // d
            pos++;
            const dict = new Map();
            while (data[pos] !== 101) {
                const key = decode();
                const value = decode();
                dict.set(bytesToString(key), value);
            }
            pos++;
            return dict;
        }
        if (type >= 48 && type <= 57) {
            const lenBytes = readUntil(58);
            const len = parseInt(decoder.decode(lenBytes), 10);
            const bytes = data.slice(pos, pos + len);
            pos += len;
            return bytes;
        }
        throw new Error(`Invalid bencode at ${pos}`);
    }
    return decode();
}

function bytesToString(bytes) {
    try { return decoder.decode(bytes); } catch { return Array.from(bytes).join(","); }
}
function safeDecode(bytes) {
    try { return decoder.decode(bytes); } catch { return Array.from(bytes).join(","); }
}

function bencode(obj) {
    if (typeof obj === "number") return encoder.encode(`i${obj}e`);
    if (obj instanceof Uint8Array) {
        const prefix = encoder.encode(obj.length + ":");
        return concat([prefix, obj]);
    }
    if (typeof obj === "string") {
        const bytes = encoder.encode(obj);
        const prefix = encoder.encode(bytes.length + ":");
        return concat([prefix, bytes]);
    }
    if (Array.isArray(obj)) {
        return concat([encoder.encode("l"), ...obj.map(bencode), encoder.encode("e")]);
    }
    if (obj instanceof Map) {
        const entries = [...obj.entries()].sort((a, b) => compareBytes(encoder.encode(a[0]), encoder.encode(b[0])));
        return concat([encoder.encode("d"), ...entries.flatMap(([k, v]) => [bencode(k), bencode(v)]), encoder.encode("e")]);
    }
    return new Uint8Array(0);
}

function concat(arrays) {
    const total = arrays.reduce((s, a) => s + a.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    for (const a of arrays) {
        out.set(a, offset);
        offset += a.length;
    }
    return out;
}

function compareBytes(a, b) {
    const len = Math.min(a.length, b.length);
    for (let i = 0; i < len; i++) if (a[i] !== b[i]) return a[i] - b[i];
    return a.length - b.length;
}

async function sha1(bytes) {
    const hash = await crypto.subtle.digest("SHA-1", bytes);
    return new Uint8Array(hash);
}

function formatBytes(bytes) {
    if (!bytes) return "0 B";
    const units = ["B","KiB","MiB","GiB","TiB","PiB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / 1024**i).toFixed(2) + " " + units[i];
}

function size_in_bytes(text) {
    const size = parseFloat(text.split(" ")[0].replace(/,/g, ""));
    const unit = text.split(" ")[1];
    switch (unit) {
        case "B": return size;
        case "KiB": return size * 1024;
        case "MiB": return size * 1024 ** 2;
        case "GiB": return size * 1024 ** 3;
        case "TiB": return size * 1024 ** 4;
    }
    return 0;
}

function bytes_to_text(size) {
    if (size >= 1024 ** 4) return (Math.round(size * 100 / 1024 ** 4) / 100).toLocaleString(locale) + " TiB";
    if (size >= 1024 ** 3) return (Math.round(size * 100 / 1024 ** 3) / 100).toLocaleString(locale) + " GiB";
    if (size >= 1024 ** 2) return (Math.round(size * 100 / 1024 ** 2) / 100).toLocaleString(locale) + " MiB";
    if (size >= 1024) return (Math.round(size * 100 / 1024) / 100).toLocaleString(locale) + " KiB";
    return size.toLocaleString(locale) + " B";
}

function toggle_expand(start_id, end_id) {
    const toggle = document.getElementById("filetree_toggle_" + start_id);
    if (!toggle) return;
    for (let i = start_id; i <= end_id; i++) {
        const el = document.getElementById("filetree_" + i);
        if (el && el.getAttribute("filetree_status") === toggle.getAttribute("filetree_status")) {
            el.children[0].click();
        }
    }
    const isClosed = toggle.getAttribute("filetree_status") === "closed";
    toggle.setAttribute("filetree_status", isClosed ? "opened" : "closed");
    toggle.textContent = isClosed ? "[-]" : "[+]";
}

function toggle_folder(children, id) {
    const row = document.getElementById("filetree_" + id);
    if (!row) return;
    const newStatus = row.getAttribute("filetree_status") === "closed" ? "opened" : "closed";
    row.setAttribute("filetree_status", newStatus);
    children.forEach(childId => {
        const child = document.getElementById("filetree_" + childId);
        if (child) {
            if (child.getAttribute("filetree_status") === "opened") child.children[0].click();
            child.style.display = child.style.display === "table-row" ? "none" : "table-row";
        }
    });
}

// Inject globals
const gs = document.createElement('script');
gs.textContent = `${toggle_folder.toString()}\n${toggle_expand.toString()}`;
document.head.appendChild(gs);

const eventHandler = async (e) => {
    const tabs = e.target?.closest?.("div.tabs");
    if (!tabs) return;
    const fl = tabs.querySelector("div[id$='_filelist']");
    const m = fl?.id?.match(/^(\d+)_filelist$/);
    if (!m) return;

    const torrentId = Number(m[1]);
    if (handledTorrentIds[torrentId]) return;
    handledTorrentIds[torrentId] = true;

    const dlLink = document.querySelector(`a[href^='/torrent/${torrentId}/download/']`);
    if (!dlLink) return;

    console.log(`[Filelist Improvements]: Processing torrent #${torrentId}`);

    try {
        const res = await fetch(new URL(dlLink.href, location.href), {credentials: "same-origin"});
        const buffer = await res.arrayBuffer();
        const root = bdecode(buffer);
        const info = root.get("info");
        if (!info) throw new Error("No info dict");

        const baseName = safeDecode(info.get("name"));
        const pieceLength = info.get("piece length") || 0;
        const pieces = info.get("pieces");
        const pieceCount = pieces instanceof Uint8Array ? Math.floor(pieces.length / 20) : 0;

        const files = info.get("files");
        const fileMap = new Map();

        if (Array.isArray(files)) {
            files.forEach(entry => {
                const pathArr = entry.get("path").map(safeDecode);
                const fullPath = pathArr.join("/").replace(whitespaceRE, "");
                const noRoot = pathArr.slice(1).join("/").replace(whitespaceRE, "");
                const len = entry.get("length");
                const data = { length: len, sizeText: bytes_to_text(len) };
                fileMap.set(fullPath, data);
                if (noRoot) fileMap.set(noRoot, data);
            });
        } else {
            const name = safeDecode(info.get("name"));
            const len = info.get("length") || 0;
            fileMap.set(name.replace(whitespaceRE, ""), { length: len, sizeText: bytes_to_text(len) });
        }

        const table = document.getElementById(`filelist_${torrentId}`);
        if (!table) return;

        // Info Panel
        const infoEl = document.createElement("p");
        let hasRoot = false;

        if (Array.isArray(files) && files.length > 0) {
            const firstPath = files[0].get("path");
            if (firstPath && firstPath.length > 0) {
                const common = safeDecode(firstPath[0]);
                if (files.every(f => safeDecode(f.get("path")[0]) === common)) {
                    hasRoot = true;
                    infoEl.append(`Root Folder: ${baseName}`, document.createElement("br"));
                }
            }
        }

        infoEl.append(`Piece Count: ${pieceCount.toLocaleString()}`, document.createElement("br"));
        infoEl.append(`Piece Size: ${formatBytes(pieceLength)}`);

        const hashBytes = await sha1(bencode(info));
        const infoHash = Array.from(hashBytes).map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
        infoEl.append(document.createElement("br"));
        infoEl.append(`Info Hash: ${infoHash}`);
        table.before(infoEl);

        // Tree Building
        const rows = Array.from(table.getElementsByTagName("tr"));
        const folders = { ".": {} };
        const top_level = { folders: [], files: [] };

        const titleName = rows[0].children[0];
        const fileCountSpan = document.createElement("span");
        fileCountSpan.style.float = "right";
        fileCountSpan.textContent = Array.isArray(files) ? `${files.length} Files` : "1 File";
        titleName.appendChild(fileCountSpan);

        const titleSize = rows[0].children[1];
        const toggleBtn = document.createElement("span");
        toggleBtn.style.float = "right";
        toggleBtn.style.font = "1.2em monospace";
        toggleBtn.textContent = "[+]";
        toggleBtn.setAttribute("filetree_status", "closed");
        titleSize.appendChild(toggleBtn);

        rows.slice(1).forEach(row => row.remove());

        if (!Array.isArray(files)) {
            const name = safeDecode(info.get("name"));
            folders[name] = {id: id_count, size: info.get("length")||0, name: name, folders: [], files: []};
            folders["."][id_count] = name;
            top_level.files.push(id_count++);
        } else {
            files.forEach(fileEntry => {
                const pathArr = [baseName, ...fileEntry.get("path").map(safeDecode)];
                const fullPath = pathArr.join("/");
                const fileSize = fileEntry.get("length");

                let parent = null;
                for (let i = 1; i < pathArr.length; i++) {
                    const folderPath = pathArr.slice(0, i).join("/");
                    const folderName = "&nbsp;&nbsp;&nbsp;".repeat(i-1) + pathArr[i-1];

                    if (!(folderPath in folders)) {
                        id_count++;
                        folders[folderPath] = {id: id_count, size: 0, name: folderName, folders: [], files: []};
                        folders["."][id_count] = folderPath;
                        (parent ? folders[parent].folders : top_level.folders).push(id_count);
                    }
                    folders[folderPath].size += fileSize;
                    parent = folderPath;
                }

                const fileName = "&nbsp;&nbsp;&nbsp;".repeat(pathArr.length-1) + pathArr.at(-1);
                id_count++;
                folders[fullPath] = {id: id_count, size: fileSize, name: fileName, folders: [], files: []};
                folders["."][id_count] = fullPath;
                (parent ? folders[parent].files : top_level.files).push(id_count);
            });
        }

        if (top_level.folders.length) {
            toggleBtn.id = `filetree_toggle_${top_level.folders[0]}`;
            toggleBtn.onclick = () => toggle_expand(top_level.folders[0], id_count);
        } else toggleBtn.remove();

        function createTree(key, foldersObj, tbody) {
            const data = foldersObj[key];
            const row = document.createElement("tr");
            row.id = `filetree_${data.id}`;
            row.style.display = "none";

            const nameTd = document.createElement("td");
            const sizeTd = document.createElement("td");

            const entry = fileMap.get(key.replace(whitespaceRE, ""));
            if (entry) sizeTd.title = entry.length.toLocaleString() + " bytes";

            if (data.folders.length + data.files.length === 0) {
                nameTd.innerHTML = `<code style="font-family:monospace;font-size:1.2em">${data.name}</code>`;
                sizeTd.innerHTML = `<span>${bytes_to_text(data.size)}</span>`;
            } else {
                row.setAttribute("filetree_status", "closed");
                nameTd.onclick = () => toggle_folder(data.folders.concat(data.files), data.id);
                nameTd.innerHTML = `<code style="font-family:monospace;font-size:1.2em;font-weight:bold">${data.name}</code>`;
                sizeTd.innerHTML = `<span style="opacity:60%">[${bytes_to_text(data.size)}]</span>`;
            }

            row.append(nameTd, sizeTd);
            tbody.appendChild(row);

            data.folders.concat(data.files).forEach(id => createTree(foldersObj["."][id], foldersObj, tbody));
        }

        const tbody = rows[0].parentElement;
        top_level.folders.concat(top_level.files).forEach(id => {
            createTree(folders["."][id], folders, tbody);
            document.getElementById(`filetree_${id}`).style.display = "table-row";
        });

        if (top_level.folders.length) {
            setTimeout(() => {
                const root = document.getElementById(`filetree_${top_level.folders[0]}`);
                if (root) root.children[0].click();
            }, 150);
        }

    } catch (err) {
        console.error("[Filelist Improvements]:", err);
    }
};

// Attach
document.querySelectorAll("a[href$='filelist']").forEach(link => {
    const m = link.getAttribute("href").match(/^#(\d+)[_/]filelist$/);
    if (!m) return;
    const tid = Number(m[1]);
    if (location.hash.includes(tid)) eventHandler({target: link});
    else {
        link.addEventListener("click", eventHandler, {once: true, capture: true});
        link.addEventListener("mouseover", eventHandler, {once: true, capture: true});
    }
});