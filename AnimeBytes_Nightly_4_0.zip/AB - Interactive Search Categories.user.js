// ==UserScript==
// @name          AB - Interactive Search Categories

// @namespace     AnimeBytes Nightly
// @version       1.4.0
// @author        TalkingJello
// @description   Highlights the current categories. Preserves your search and filters when switching between Anime/Music and their subcategories.

// @match         *://animebytes.tv/torrents.php*
// @match         *://animebytes.tv/torrents2.php*
// @match         *://animebytes.tv/user.php?action=edit*
// @downloadURL https://gist.github.com/MitsukiHaruko/dfba06068659dd039dda4166dfb43438/raw/AB_Interactive-Search-Categories.user.jshttps://gist.github.com/MitsukiHaruko/dfba06068659dd039dda4166dfb43438/raw/AB_Interactive-Search-Categories.user.js
// @updateURL https://gist.github.com/MitsukiHaruko/dfba06068659dd039dda4166dfb43438/raw/AB_Interactive-Search-Categories.user.jshttps://gist.github.com/MitsukiHaruko/dfba06068659dd039dda4166dfb43438/raw/AB_Interactive-Search-Categories.user.js
// @grant         GM_getValue
// @grant         GM_setValue
// @require       https://greasyfork.org/scripts/456220-delicious-userscript-library/code/Delicious%20Userscript%20Library.js?version=1125927
// @license       MIT
// @icon          http://animebytes.tv/favicon.ico
// ==/UserScript==

function categoryKeyFromLink(link) {
    for (const key of [...(new URL(link).searchParams.keys())]) {
        if (key.startsWith('filter_cat[')) {
            return key;
        }
    }
    return '';
}

(function() {
    'use strict';

    if (window.location.pathname === "/user.php") return;

    const currentCategory = categoryKeyFromLink(window.location.href);

    // === Subcategory links ===
    $('#categories > li > a').each(function () {
        const $link = $(this);
        const thisLinkCategory = categoryKeyFromLink($link.prop('href'));

        // Add classes for external CSS styling
        $link.addClass('ab-subcategory-link');

        // Make url without current category filter
        const targetUrl = new URL(window.location.href);
        if (currentCategory) {
            targetUrl.searchParams.delete(currentCategory);
        }

        if (thisLinkCategory === currentCategory) {
            $link.addClass('ab-subcategory-link-on');
            $link.prop('href', targetUrl.toString());
            return;
        }

        // Add the new category filter
        if (targetUrl.search) {
            targetUrl.search += `&${thisLinkCategory}=1`;
        } else {
            targetUrl.search = `?${thisLinkCategory}=1`;
        }
        $link.prop('href', targetUrl.toString());
    });

    // === Anime <-> Music main links ===
    const animeLink = $('#browse_nav_sections > h2 > a[href="/torrents.php"]');
    const musicLink = $('#browse_nav_sections > h2 > a[href="/torrents2.php"]');

    const isMusic = window.location.pathname.startsWith('/torrents2.php');
    const activeLink = isMusic ? musicLink : animeLink;

    activeLink.addClass('ab-active-section-link');
    activeLink.attr('href', 'javascript:void(0);');

    // Hide non-relevant category accordions
    const categoryNumber = parseInt(currentCategory.slice(11, -1));
    if (!isMusic && categoryNumber) {
        $(`#accordion > h3:not(#ui-id-${categoryNumber*2+1}):not(#ui-id-1)`).hide();
    }

    // Preserve search params when switching between Anime <-> Music
    const ANIME_MUSIC_SHARED_PARAMS = ['year', 'year2', 'tags', 'sort', 'way', 'showhidden', 'freeleech'];
    const params = new URL(window.location.href).searchParams;

    for (const [key, value] of [...params.entries()]) {
        if (isMusic && key === 'groupname') params.set('searchstr', value);
        if (!isMusic && key === 'searchstr') params.set('groupname', value);

        if (!ANIME_MUSIC_SHARED_PARAMS.includes(key)) {
            params.delete(key);
        }
    }

    if (isMusic) {
        animeLink.attr('href', `/torrents.php?${params.toString()}`);
    } else {
        musicLink.attr('href', `/torrents2.php?${params.toString()}`);
    }
})();// ==UserScript==
// @name          AB - Interactive Search Categories

// @namespace     AnimeBytes Nightly
// @version       1.4.0
// @author        TalkingJello
// @description   Highlights the current categories. Preserves your search and filters when switching between Anime/Music and their subcategories.

// @match         *://animebytes.tv/torrents.php*
// @match         *://animebytes.tv/torrents2.php*
// @match         *://animebytes.tv/user.php?action=edit*
// @downloadURL https://update.greasyfork.org/scripts/455876/AB%20-%20Interactive%20Search%20Categories.user.js
// @updateURL https://update.greasyfork.org/scripts/455876/AB%20-%20Interactive%20Search%20Categories.meta.js
// @grant         GM_getValue
// @grant         GM_setValue
// @require       https://greasyfork.org/scripts/456220-delicious-userscript-library/code/Delicious%20Userscript%20Library.js?version=1125927
// @license       MIT
// @icon          http://animebytes.tv/favicon.ico
// ==/UserScript==

function categoryKeyFromLink(link) {
    for (const key of [...(new URL(link).searchParams.keys())]) {
        if (key.startsWith('filter_cat[')) {
            return key;
        }
    }
    return '';
}

(function() {
    'use strict';

    if (window.location.pathname === "/user.php") return;

    const currentCategory = categoryKeyFromLink(window.location.href);

    // === Subcategory links ===
    $('#categories > li > a').each(function () {
        const $link = $(this);
        const thisLinkCategory = categoryKeyFromLink($link.prop('href'));

        // Add classes for external CSS styling
        $link.addClass('ab-subcategory-link');

        // Make url without current category filter
        const targetUrl = new URL(window.location.href);
        if (currentCategory) {
            targetUrl.searchParams.delete(currentCategory);
        }

        if (thisLinkCategory === currentCategory) {
            $link.addClass('ab-subcategory-link-on');
            $link.prop('href', targetUrl.toString());
            return;
        }

        // Add the new category filter
        if (targetUrl.search) {
            targetUrl.search += `&${thisLinkCategory}=1`;
        } else {
            targetUrl.search = `?${thisLinkCategory}=1`;
        }
        $link.prop('href', targetUrl.toString());
    });

    // === Anime <-> Music main links ===
    const animeLink = $('#browse_nav_sections > h2 > a[href="/torrents.php"]');
    const musicLink = $('#browse_nav_sections > h2 > a[href="/torrents2.php"]');

    const isMusic = window.location.pathname.startsWith('/torrents2.php');
    const activeLink = isMusic ? musicLink : animeLink;

    activeLink.addClass('ab-active-section-link');
    activeLink.attr('href', 'javascript:void(0);');

    // Hide non-relevant category accordions
    const categoryNumber = parseInt(currentCategory.slice(11, -1));
    if (!isMusic && categoryNumber) {
        $(`#accordion > h3:not(#ui-id-${categoryNumber*2+1}):not(#ui-id-1)`).hide();
    }

    // Preserve search params when switching between Anime <-> Music
    const ANIME_MUSIC_SHARED_PARAMS = ['year', 'year2', 'tags', 'sort', 'way', 'showhidden', 'freeleech'];
    const params = new URL(window.location.href).searchParams;

    for (const [key, value] of [...params.entries()]) {
        if (isMusic && key === 'groupname') params.set('searchstr', value);
        if (!isMusic && key === 'searchstr') params.set('groupname', value);

        if (!ANIME_MUSIC_SHARED_PARAMS.includes(key)) {
            params.delete(key);
        }
    }

    if (isMusic) {
        animeLink.attr('href', `/torrents.php?${params.toString()}`);
    } else {
        musicLink.attr('href', `/torrents2.php?${params.toString()}`);
    }
})();