// ==UserScript==
// @name         AB - Parental Guide
// @namespace    AnimeBytes Nightly

// @author       Mitsuki Haruko, KatSu
// @version      2.2.0
// @description  Relies on another script adding the IMDb link to the page. Original script (written for unit3d by KatSu) was yanked from Aither
// @homepageURL https://aither.cc/forums/topics/6048?page=1#post-52653

// @match        *://animebytes.tv/torrents.php?*
// @match        *://animebytes.tv/user.php?action=edit*
// @updateURL https://gist.github.com/MitsukiHaruko/df4b29e2542507ed19420b68985a7120/raw/AB_IMDb-Parental-Guide.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/df4b29e2542507ed19420b68985a7120/raw/AB_IMDb-Parental-Guide.user.js
// @grant        GM_xmlhttpRequest
// @connect      api.graphql.imdb.com
// @connect      www.imdb.com
// @connect      imdb.com
// @license      MIT
// @icon         https://animebytes.tv/favicon.ico
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';
    let imdbAnchor = null;

    function createGuideContainer() {
        let container = document.getElementById("ab-imdb-parental-guide");
        if (container) return container;

        const torrentTable = document.querySelector(".torrent_table");
        if (!torrentTable) {
            console.warn("[Parental Guide] .torrent_table not found.");
            return null;
        }

        const style = document.createElement("style");
        style.textContent = `
            .pg-list {
                display: none;
                margin-top: 8px;
            }
            .pg-list.expanded {
                display: block;
            }
            .pg-header {
                user-select: none;
                cursor: pointer;
            }
        `;
        document.head.appendChild(style);

        container = document.createElement("div");
        container.id = "ab-imdb-parental-guide";
        container.innerHTML = `
            <div class="head"><strong>Parental Guide</strong></div>
            <div class="body" style="padding:12px;"></div>
        `;

        torrentTable.insertAdjacentElement("afterend", container);
        return container;
    }

    function renderGuide(data) {
        const container = createGuideContainer();
        if (!container) return;

        const body = container.querySelector(".body");
        body.innerHTML = '';

        const colorMap = {
            None: '#F2DB83',
            Mild: '#c5e197',
            Moderate: '#fbca8c',
            Severe: '#ffb3ad'
        };

        data.categories.forEach(cat => {
            const severity = cat.severity?.text || "Unknown";
            const section = document.createElement("div");
            section.className = "pg-section";

            const header = document.createElement("div");
            header.className = "pg-header";
            header.style.color = colorMap[severity] || '#ccc';

            const count = cat.guideItems.edges.length;
            header.textContent = `${cat.category.text} - ${severity} (${count})`;

            const list = document.createElement("ul");
            list.className = "pg-list";

            cat.guideItems.edges.forEach(edge => {
                const li = document.createElement("li");
                const text = document.createElement("span");
                text.textContent = edge.node.text.plainText;

                if (edge.node.isSpoiler) {
                    text.className = "imdb-spoiler";
                    text.textContent += " [Spoiler]";
                }

                li.appendChild(text);
                list.appendChild(li);
            });

            header.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopImmediatePropagation();
                const scrollY = window.scrollY;
                list.classList.toggle("expanded");
                requestAnimationFrame(() => {
                    window.scrollTo({ top: scrollY, behavior: "instant" });
                });
            }, true);

            section.appendChild(header);
            section.appendChild(list);
            body.appendChild(section);
        });
    }

    function showMessage(message) {
        const container = createGuideContainer();
        if (!container) return;
        const body = container.querySelector(".body");
        // Plain text, no extra styling or background
        body.innerHTML = `<div>${message}</div>`;
    }

    function findImdbLink() {
        return document.querySelector('a[href*="imdb.com/title/tt"]') ||
               document.querySelector('[href*="imdb.com/title/tt"]');
    }

    function handleImdbLink(link) {
        if (!link || imdbAnchor) return;
        imdbAnchor = link;

        console.log("[Parental Guide] IMDb link found:", link.href);

        const match = link.href.match(/tt\d+/);
        const imdbId = match ? match[0] : null;

        if (!imdbId) {
            showMessage("Could not determine IMDb ID.");
            return;
        }

        startFetch(imdbId);
    }

    function startFetch(imdbId) {
        createGuideContainer();

        const graphQlReq = {
            query: `query {
                title(id: "${imdbId}") {
                    parentsGuide {
                        categories {
                            category { text }
                            severity { text }
                            guideItems(first: 100) {
                                edges {
                                    node {
                                        ... on ParentsGuideItem {
                                            isSpoiler
                                            text { plainText }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }`
        };
GM_xmlhttpRequest({
    method: "POST",
    url: "https://api.graphql.imdb.com/",
    headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": navigator.userAgent,
        "Origin": "https://www.imdb.com",
        "Referer": "https://www.imdb.com/",
        "x-imdb-client-name": "imdb-web-next"
    },
    data: JSON.stringify(graphQlReq),
            onload(response) {
                try {
                    const body = JSON.parse(response.responseText);
                    const data = body?.data?.title?.parentsGuide;

                    if (!data?.categories?.length) {
                        showMessage("No parental guide information available.");
                        return;
                    }

                    renderGuide(data);
                } catch (e) {
                    console.error("[Parental Guide] Parse error:", e);
                    showMessage("Failed to parse IMDb response.");
                }
            },
            onerror(err) {
                console.error("[Parental Guide] Request failed:", err);
                showMessage("Failed to retrieve IMDb parental guide.");
            }
        });
    }

    handleImdbLink(findImdbLink());

    let attempts = 0;
    const maxAttempts = 50;
    const poll = setInterval(() => {
        attempts++;
        const link = findImdbLink();
        if (link) {
            clearInterval(poll);
            handleImdbLink(link);
        } else if (attempts >= maxAttempts) {
            clearInterval(poll);
            console.warn("[Parental Guide] Stopped looking for IMDb link.");
        }
    }, 100);

})();