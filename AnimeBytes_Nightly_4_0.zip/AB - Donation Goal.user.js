// ==UserScript==
// @name         AB - Donation Goal

// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.0

// @match        *://animebytes.tv/*
// @updateURL    https://gist.github.com/MitsukiHaruko/26c4ddd2c547b01b69dc6348f1a6dc1c/raw/AB_Donation-Goal.user.js
// @downloadURL  https://gist.github.com/MitsukiHaruko/26c4ddd2c547b01b69dc6348f1a6dc1c/raw/AB_Donation-Goal.user.js
// @icon         https://animebytes.tv/favicon.ico
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    const tryInsertNumber = () => {
        const donateLink = document.querySelector('#nav_donate a');
        if (!donateLink) return false;

        const match = donateLink.textContent.match(/\d+/);
        let progressPercent = match ? parseInt(match[0]) : 0;

        const container = document.createElement('div');
        container.className = 'ab-donation-container';

        const numberDisplay = document.createElement('div');
        numberDisplay.className = 'ab-donation-number';
        numberDisplay.textContent = `${progressPercent}%`;

        // Function to calculate and set width dynamically
        const setWidth = (percent) => {
            // Responsive min/max
            const maxWidth = Math.max(120, Math.min(window.innerWidth * 0.35, 500));
            const minWidth = Math.max(50, Math.min(window.innerWidth * 0.15, 60));
            const widthPx = maxWidth - ((maxWidth - minWidth) * percent / 100);
            numberDisplay.style.width = widthPx + 'px';
        };

        setWidth(progressPercent);

        container.appendChild(numberDisplay);

        numberDisplay.addEventListener('click', () => {
            window.location.href = donateLink.href;
        });

        document.body.insertBefore(container, document.body.firstChild);

        // Update loop
        setInterval(() => {
            const newPercent = parseInt(donateLink.textContent.match(/\d+/)?.[0] || 0);
            if (newPercent !== progressPercent) {
                progressPercent = newPercent;
                numberDisplay.textContent = `${progressPercent}%`;
                setWidth(progressPercent);
            }
        }, 1000);

        // Update on resize for responsiveness
        window.addEventListener('resize', () => setWidth(progressPercent));

        return true;
    };

    // Wait until DOM is ready, then insert number display
    const waitForBody = setInterval(() => {
        if (document.body) {
            clearInterval(waitForBody);
            const waitForDonate = setInterval(() => {
                if (tryInsertNumber()) clearInterval(waitForDonate);
            }, 100);
        }
    }, 10);
})();
