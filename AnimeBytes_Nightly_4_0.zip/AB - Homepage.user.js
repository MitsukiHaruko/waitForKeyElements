// ==UserScript==
// @name         AB - Homepage

// @namespace    AnimeBytes Nightly
// @author       Mitsuki Haruko
// @version      1.0
// @description  Home page enjoyings. Dependency for Collages & Companies. Auto-focuses search bar on homepage.

// @match        https://animebytes.tv/
// @match        https://animebytes.tv/collage.php?*
// @match        https://animebytes.tv/company.php?*
// @match        *://animebytes.tv/user.php?action=edit*
// @updateURL    https://gist.github.com/MitsukiHaruko/8f8a0a04da67ccef3ad8c3fcba6cc1fd/raw/AB_Homepage.user.js
// @downloadURL  https://gist.github.com/MitsukiHaruko/8f8a0a04da67ccef3ad8c3fcba6cc1fd/raw/AB_Homepage.user.js
// @require      https://raw.githubusercontent.com/momentary0/AB-Userscripts/b1e7aac27e1f49391147cf068326f278bb40e20d/delicious-library/src/ab_delicious_library.js
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-end
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

(function () {
    'use strict';

    // ==================== CSS ====================
    GM_addStyle(`
        #COLLAGE_TABLE img, #collage_table img {
            width: 138px !important;
            height: 209px !important;
            filter: brightness(80%) !important;
            display: block;
        }
        /* Poster link container */
        #COLLAGE_TABLE a, #collage_table a {
            position: relative;
            display: inline-block;
            vertical-align: top;
            overflow: hidden;
            line-height: 0;
        }
        /* Slide-up title */
        .ab-home-title {
            position: absolute;
            bottom: -1px;
            left: 0;
            right: 0;
            background: #343f4a;
            color: #ddd !important;
            font-size: 11px;
            line-height: 1.35;
            text-align: center;
            padding: 8px 5px 7px;
            transform: translateY(100%);
            transition: transform 0.35s ease;
            opacity: 0;
            visibility: hidden;
            z-index: 2;
            word-wrap: break-word;
            word-break: break-word;
            max-height: 82px;
            border-radius: 5px 5px 5px 5px;
        }
        /* Hover effect */
        a:hover .ab-home-title {
            transform: translateY(0);
            opacity: 1;
            visibility: visible;
        }
        .ab-home-title,
        .ab-home-title:hover {
            color: #ddd !important;
            text-decoration: none !important;
            text-shadow: none !important;
            cursor: default;
        }
        a:hover img {
            filter: brightness(65%) !important;
        }
        /* Toggle: show all titles permanently */
        body.titles-toggled .ab-home-title,
        body.titles-toggled a:hover .ab-home-title {
            transform: translateY(0) !important;
            opacity: 1 !important;
            visibility: visible !important;
        }
        #rutCarousel { display: block !important; width: 840px; }
        .next, .prev { scale: 70% !important; }
        #cover-slider { width: 800px !important; }
        #cover-slider .slider { width: 700px !important; }
        #rutCarousel.hide-by-userscript { display: none !important; }
    `);

    // ==================== Variables ====================
    const isPosterPage = window.location.pathname.includes('/collage.php') ||
                        window.location.pathname.includes('/company.php');

    // ==================== Functions ====================
    // Hide native titles under collages
    document.querySelectorAll('#collage_table > tbody > tr > td > a > div:nth-child(2)').forEach(el => {
        el.style.display = 'none';
    });

    function insertCollageTitles() {
        const tables = document.querySelectorAll('#COLLAGE_TABLE, #collage_table');
        let added = 0;
        tables.forEach(table => {
            table.querySelectorAll('a').forEach(anchor => {
                if (anchor.querySelector('.ab-home-title')) return;
                const img = anchor.querySelector('img');
                if (!img || !img.title?.trim()) return;
                const titleText = img.title.trim();
                const titleDiv = document.createElement('div');
                titleDiv.className = 'ab-home-title';
                titleDiv.textContent = titleText;
                anchor.appendChild(titleDiv);
                img.title = ''; // Disable native browser tooltip
                added++;
            });
        });
        if (added > 0) {
            console.log(`[AB Home] Added ${added} slide-up titles`);
        }
    }

    function toggleTitles() {
        document.body.classList.toggle('titles-toggled');
    }

    function addToggleLink() {
        if (!isPosterPage) return;

        const linkbox = document.querySelector('.linkbox');
        if (!linkbox || document.getElementById('toggle-titles-link')) return;

        const link = document.createElement('a');
        link.id = 'toggle-titles-link';
        link.href = '#';
        link.textContent = '[toggle titles]';
        link.style.marginLeft = '8px';
        link.addEventListener('click', function(e) {
            e.preventDefault();
            toggleTitles();
        });
        linkbox.appendChild(link);
    }

    function manageNewsStyles(enabled) {
        const styleId = 'news-replacement-styles';
        let style = document.getElementById(styleId);
        if (enabled) {
            if (!style) {
                style = document.createElement('style');
                style.id = styleId;
                style.textContent = `.fpright { margin-right: -100px; } .news_entry { margin-left: -100px; }`;
                document.head.appendChild(style);
            }
        } else if (style) {
            style.remove();
        }
    }

    function manageElementVisibility() {
        document.querySelector('#aotw')?.style.setProperty('display', JSON.parse(GM_getValue('aotwEnabled', 'false')) ? 'none' : '');
        document.querySelector('#aotf')?.style.setProperty('display', JSON.parse(GM_getValue('aotfEnabled', 'false')) ? 'none' : '');
        const carousel = document.querySelector('#rutCarousel');
        if (carousel) {
            carousel.classList.toggle('hide-by-userscript', JSON.parse(GM_getValue('lastUploadsEnabled', 'false')));
            carousel.dataset.visibilityApplied = 'true';
        }
    }

    function observeCollageTable() {
        const observer = new MutationObserver(() => {
            if (document.querySelector('#COLLAGE_TABLE, #collage_table')) {
                insertCollageTitles();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });

        setTimeout(() => {
            insertCollageTitles();
            addToggleLink();
        }, 600);
    }

    function observeRutCarousel() {
        const observer = new MutationObserver(() => {
            const carousel = document.querySelector('#rutCarousel');
            if (carousel && !carousel.dataset.visibilityApplied) manageElementVisibility();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    async function replaceNewsEntry() {
        try {
            const res = await fetch('https://animebytes.tv/airing', { credentials: 'include' });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const content = doc.querySelector('div.thin:nth-child(3)');
            const target = document.querySelector('.news_entry');
            if (content && target) target.innerHTML = content.innerHTML;
        } catch (e) {
            console.error('News replacement failed:', e);
        }
    }

    function insertSettingsUi() {
        if (!delicious?.settings?.ensureSettingsInserted?.()) return;
        const section = delicious.settings.createCollapsibleSection('Home Page');
        const body = section.querySelector('.settings_section_body');
        delicious.settings.init('newsReplacementEnabled', true);
        body.appendChild(delicious.settings.createCheckbox('newsReplacementEnabled', 'News Replacement', 'Replace news with airing anime images'));
        delicious.settings.init('aotwEnabled', false);
        body.appendChild(delicious.settings.createCheckbox('aotwEnabled', 'Hide AotW', 'Hide Anime of the Week'));
        delicious.settings.init('aotfEnabled', false);
        body.appendChild(delicious.settings.createCheckbox('aotfEnabled', 'Hide AotF', 'Hide Anime of the Fortnight'));
        delicious.settings.init('lastUploadsEnabled', false);
        body.appendChild(delicious.settings.createCheckbox('lastUploadsEnabled', 'Hide Last Uploads', 'Hide Last Uploads carousel'));
        delicious.settings.insertSection(section);
    }

    // ==================== Auto Focus Search Bar ====================
    function focusSearchBar() {
        // Only run on home page
        if (window.location.pathname !== '/') return;

        const selectors = [
            'input.quicksearch.series_search',
            '#series_name_anime',
            'input[name="seriesname"]'
        ];

        let retries = 0;
        const maxRetries = 50; // 5 seconds (50 * 100ms)

        const attemptFocus = () => {
            let searchInput = null;
            for (const selector of selectors) {
                searchInput = document.querySelector(selector);
                if (searchInput) break;
            }

            if (searchInput) {
                searchInput.focus();
                console.log(`[AB Home] Focused search bar using selector: ${searchInput.tagName}${searchInput.id ? '#' + searchInput.id : ''}${searchInput.className ? '.' + searchInput.className : ''}`);
            } else if (retries < maxRetries) {
                retries++;
                console.warn(`[AB Home] Search bar not found (retry ${retries}/${maxRetries}), trying again...`);
                setTimeout(attemptFocus, 100);
            } else {
                console.error('[AB Home] Failed to find search bar after max retries');
            }
        };

        // Set up mutation observer to detect search bar addition
        const observer = new MutationObserver(() => {
            let searchInput = null;
            for (const selector of selectors) {
                searchInput = document.querySelector(selector);
                if (searchInput) {
                    searchInput.focus();
                    observer.disconnect();
                    return;
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Initial attempt after a slight delay to account for themes script
        setTimeout(attemptFocus, 100);

        // Stop observer after 5 seconds if not found
        setTimeout(() => {
            observer.disconnect();
        }, 5000);
    }

    // ==================== Main ====================
    function main() {
        observeCollageTable();
        observeRutCarousel();
        manageElementVisibility();
        focusSearchBar();

        if (window.location.pathname === '/user.php' && new URLSearchParams(window.location.search).get('action') === 'edit') {
            insertSettingsUi();
            return;
        }

        const newsEnabled = JSON.parse(GM_getValue('newsReplacementEnabled', 'true'));
        manageNewsStyles(newsEnabled);
        if (newsEnabled) replaceNewsEntry();
    }

    main();
})();