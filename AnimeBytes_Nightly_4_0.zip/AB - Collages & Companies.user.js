// ==UserScript==
// @name         AB - Collages & Companies
// @namespace    AnimeBytes Nightly

// @author       sabs, Mitsuki Haruko
// @version      1.0
// @description  Bookmarkable collages & companies with a cleaner simple design (relies on the Homepage script!)
// @homepageURL  https://animebytes.tv/forums.php?action=viewthread&threadid=26497

// @match        https://animebytes.tv/collage.php*
// @match        https://animebytes.tv/bookmarks.php*
// @match        https://animebytes.tv/company.php*
// @updateURL    https://gist.github.com/MitsukiHaruko/27db459d01d99549c9e689d659e84e00/raw/AB_Collages-&-Companies.user.js
// @downloadURL  https://gist.github.com/MitsukiHaruko/27db459d01d99549c9e689d659e84e00/raw/AB_Collages-&-Companies.user.js
// @icon https://animebytes.tv/favicon.ico
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    // ==================== BOOKMARKS FEATURE ====================

    unsafeWindow.abcb = {
        bookmarks: JSON.parse(GM_getValue("abcb", "{}"))
    };

    var bookmarks, header, text, a, linkbox, container;

    function fetchPageForId(id, callback) {
        let url;
        if (id.match(/C.*/)) {
            id = id.substring(1);
            url = "https://animebytes.tv/company.php?id=" + id;
        } else {
            url = "https://animebytes.tv/collage.php?id=" + id;
        }
        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            onload: function (response) {
                const container = document.implementation.createHTMLDocument().documentElement;
                container.innerHTML = response.responseText;
                callback(container);
            }
        });
    }

    function buildBookmarkTab() {
        bookmarks = document.createElement("div");
        bookmarks.className = "thin";
        bookmarks.id = "bookmarks";
        header = document.createElement("h2");
        header.className = "center";
        text = document.createTextNode("Bookmarks");
        header.appendChild(text);
        bookmarks.appendChild(header);
        return bookmarks;
    }

    function buildBookmarkTableAndSaveData() {
        let ret = {};
        let data = [];
        let table, body, row, td;

        table = document.createElement("table");
        table.width = "100%";
        body = table.createTBody();
        row = body.insertRow();
        row.className = "colhead";

        for (const header of ["Collage", "Torrents when Last Checked"]) {
            td = document.createElement("td");
            td.appendChild(document.createTextNode(header));
            row.appendChild(td);
        }

        let next = "rowa";
        for (const [key, value] of Object.entries(unsafeWindow.abcb.bookmarks)) {
            row = body.insertRow();
            row.className = next;
            next = next === "rowa" ? "rowb" : "rowa";

            td = document.createElement("td");
            a = document.createElement("a");
            if (key.match(/C.*/)) {
                a.href = "/company.php?id=" + key.substring(1);
            } else {
                a.href = "/collage.php?id=" + key;
            }
            a.appendChild(document.createTextNode(value.title));
            td.appendChild(a);
            row.appendChild(td);

            td = document.createElement("td");
            td.appendChild(document.createTextNode(value.groups));
            row.appendChild(td);

            data[key] = {
                id: key,
                groups: value.groups,
                td: td,
            };
        }

        ret.table = table;
        ret.data = data;
        return ret;
    }

    function addBookmark(id, data) {
        unsafeWindow.abcb.bookmarks = JSON.parse(GM_getValue("abcb", "{}"));
        unsafeWindow.abcb.bookmarks[id] = data;
        GM_setValue("abcb", JSON.stringify(unsafeWindow.abcb.bookmarks));
    }

    function deleteBookmark(id) {
        unsafeWindow.abcb.bookmarks = JSON.parse(GM_getValue("abcb", "{}"));
        delete unsafeWindow.abcb.bookmarks[id];
        GM_setValue("abcb", JSON.stringify(unsafeWindow.abcb.bookmarks));
    }

    function deleteAllBookmarks() {
        if (confirm('Click "OK" to permanently delete all your bookmarked collages.')) {
            unsafeWindow.abcb.bookmarks = {};
            GM_setValue("abcb", JSON.stringify(unsafeWindow.abcb.bookmarks));
            location.reload();
        }
    }

    function is404(doc) {
        return doc.querySelector("#content .thin h2").innerText === "Error 404 - Not Found";
    }

    const NO_ERROR = null;
    const PAGE_NOT_FOUND = 2;

    function getBookmarkDataFromDocument(doc) {
        if (is404(doc)) {
            return { error: PAGE_NOT_FOUND };
        }
        return {
            error: NO_ERROR,
            title: doc.querySelector("#content .thin h2").innerText,
            groups: doc.querySelector(".sidebar .stats.nobullet").firstElementChild.textContent.replace("Groups: ", "")
        };
    }

    function hideCollagesTab(add_history = true) {
        unsafeWindow.abcb.tab_bookmarks.style.display = "none";
        unsafeWindow.abcb.tab_collages.style.display = "block";
        if (add_history) history.pushState("", document.title, window.location.pathname + window.location.search);
    }

    function showCollagesTab(add_history = true) {
        unsafeWindow.abcb.tab_bookmarks.style.display = "block";
        unsafeWindow.abcb.tab_collages.style.display = "none";
        if (add_history) history.pushState("", document.title, window.location.pathname + window.location.search + "#collages");
    }

    function toggleCollagesTab() {
        isOnCollagesTab() ? hideCollagesTab() : showCollagesTab();
    }

    function refreshBookmarkTable() {
        let i = 0;
        for (let d of Object.values(unsafeWindow.abcb.table_data)) {
            d.td.innerHTML = "Checking...";
            setTimeout(() => {
                fetchPageForId(d.id, (doc) => {
                    const b = getBookmarkDataFromDocument(doc);
                    if (b.error === PAGE_NOT_FOUND) {
                        d.td.innerHTML = "";
                        const link = createLinkboxLink("Collage no longer exists. Click to forget.", () => {
                            d.td.parentNode.remove();
                            deleteBookmark(d.id);
                        });
                        d.td.appendChild(link);
                    } else if (b.groups !== d.groups) {
                        d.td.innerHTML = d.groups + " → " + b.groups;
                        deleteBookmark(d.id);
                        addBookmark(d.id, b);
                        d.groups = b.groups;
                    } else {
                        d.td.innerHTML = d.groups;
                    }
                });
            }, i * 1000);
            i++;
        }
    }

    function getCollageId() {
        const id = new URLSearchParams(document.location.search).get('id');
        return document.location.pathname === '/company.php' ? "C" + id : id;
    }

    function isViewingCollage() {
        return getCollageId() !== null;
    }

    function isViewingBookmarks() {
        return document.location.pathname === "/bookmarks.php";
    }

    function setupAndGetCollageTab() {
        container = document.querySelector("#content .thin");
        container.id = "nonCollages";
        return container;
    }

    function createLinkboxLink(text, callback) {
        a = document.createElement("a");
        a.addEventListener("click", callback, false);
        a.style.cursor = "pointer";
        a.appendChild(document.createTextNode(text));
        return a;
    }

    function getLinkbox() {
        return document.querySelectorAll("#content .thin .linkbox")[0];
    }

    function createLinkbox() {
        linkbox = document.createElement("div");
        linkbox.className = "linkbox";
        return linkbox;
    }

    function idIsBookmarked(id) {
        unsafeWindow.abcb.bookmarks = JSON.parse(GM_getValue("abcb", "{}"));
        return unsafeWindow.abcb.bookmarks.hasOwnProperty(id);
    }

    function isOnCollagesTab() {
        return document.location.hash === "#collages";
    }

    function hasAnyBookmarks() {
        return Object.keys(unsafeWindow.abcb.bookmarks).length !== 0;
    }

    // ==================== COMFY COLLAGES FEATURE ====================

    function initComfyCollages() {
        const css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = `
            #collage_table td a[href^="#group_"] img {
                cursor: pointer;
                transition: box-shadow 0.2s;
            }
            #collage_table td a[href^="#group_"] img:hover {
                box-shadow: 0 0 0 4px #f00c;
            }
            #collage_table { margin-bottom: 20px !important; }
        `;
        document.head.appendChild(css);

        function makeDirectLinks() {
            document.querySelectorAll('#collage_table a[href^="#group_"]').forEach(link => {
                const groupIdSelector = link.hash;
                const groupLink = document.querySelector(groupIdSelector + ' a[title="View Torrent"]');

                if (groupLink && groupLink.href) {
                    link.href = groupLink.href;
                    link.children[0].setAttribute('data-original-hash', link.hash.replace('#', ''));

                    const newLink = link.cloneNode(true);
                    link.parentNode.replaceChild(newLink, link);
                }
            });

            // Hide clutter
            const garbageSelectors = [
                ".torrent_table",
                ".torrent_filter_box",
                "#collage_table + * ~ *:not([class='box']):not(br):not(#collage_comment_div)",
                "table + [class='box']:not(:last-child)",
                "#collage_table + br"
            ];

            garbageSelectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => el.style.display = "none");
            });
        }

        makeDirectLinks();

        // Re-run for dynamically loaded bookmark collages
        if (document.getElementById("bookmarks_collage")) {
            new MutationObserver(makeDirectLinks).observe(document.getElementById("bookmarks_collage"), {
                childList: true,
                subtree: true
            });
        }
    }

    // ==================== MAIN EXECUTION ====================

    if (isViewingCollage()) {
        // Bookmark button on collage/company page
        linkbox = getLinkbox();
        const id = getCollageId();

        a = createLinkboxLink(idIsBookmarked(id) ? "[Bookmarked]" : "[Bookmark]", function (e) {
            if (idIsBookmarked(id)) {
                deleteBookmark(id);
                a.innerHTML = "[Bookmark]";
            } else {
                if (document.readyState === "complete") {
                    const data = getBookmarkDataFromDocument(document);
                    addBookmark(id, data);
                    a.innerHTML = "[Bookmarked]";
                } else {
                    a.innerHTML = "[Bookmarking...]";
                    document.onreadystatechange = function () {
                        if (document.readyState === 'complete') {
                            const data = getBookmarkDataFromDocument(document);
                            addBookmark(id, data);
                            a.innerHTML = "[Bookmarked]";
                        }
                    };
                }
            }
        });

        linkbox.append(" ", a);

    } else if (isViewingBookmarks()) {
        // Bookmarks tab system
        unsafeWindow.abcb.tab_bookmarks = buildBookmarkTab();
        unsafeWindow.abcb.tab_collages = setupAndGetCollageTab();

        // Clone linkbox
        const clone_linkbox = getLinkbox().cloneNode(true);
        clone_linkbox.style.marginBottom = "0";
        clone_linkbox.innerHTML = '[<a href="/bookmarks.php"></a><a href="/bookmarks.php">Torrents</a>: <a href="/bookmarks.php?type=1">Anime</a> | <a href="/bookmarks.php?type=2">Music</a>] [<a href="/bookmarks.php?type=3">Threads</a>] [Collages & Companies]';
        unsafeWindow.abcb.tab_bookmarks.appendChild(clone_linkbox);

        // Main linkbox
        linkbox = getLinkbox();
        a = createLinkboxLink("Collages & Companies", () => {});
        a.href = "#collages";
        linkbox.append("[", a, "]");

        if (hasAnyBookmarks()) {
            linkbox = createLinkbox();
            linkbox.style.marginTop = "0";

            a = createLinkboxLink("[Delete all]", deleteAllBookmarks);
            linkbox.prepend(" ", a);

            a = createLinkboxLink("[Refresh torrent count]", refreshBookmarkTable);
            linkbox.prepend(" ", a);

            unsafeWindow.abcb.tab_bookmarks.appendChild(linkbox);

            const tableData = buildBookmarkTableAndSaveData();
            unsafeWindow.abcb.table_data = tableData.data;
            unsafeWindow.abcb.tab_bookmarks.appendChild(tableData.table);
        } else {
            const p = document.createElement("p");
            p.className = "center";
            p.appendChild(document.createTextNode("You don't have any collages bookmarked!"));
            unsafeWindow.abcb.tab_bookmarks.appendChild(p);
        }

        unsafeWindow.abcb.tab_collages.insertAdjacentElement("beforebegin", unsafeWindow.abcb.tab_bookmarks);

        if (isOnCollagesTab()) {
            showCollagesTab(false);
        } else {
            hideCollagesTab(false);
        }

        window.onhashchange = () => {
            isOnCollagesTab() ? showCollagesTab(false) : hideCollagesTab(false);
        };
    }

    // Always run comfy collages on collage/company pages
    if (document.location.pathname.includes('/collage.php') || document.location.pathname.includes('/company.php')) {
        initComfyCollages();
    }

})();