// ==UserScript==
// @name         AB - Highlight Non-Zero Leeches

// @namespace    AnimeBytes Nightly
// @author       Mitsuki Haruko
// @version      1.0
// @description  Highlight non-zero seeders in red

// @match        *://animebytes.tv/torrents*
// @updateURL https://gist.github.com/MitsukiHaruko/d90fcc5b1e223824156bf6762bc27881/raw/AB_Leeches.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/d90fcc5b1e223824156bf6762bc27881/raw/AB_Leeches.user.js
// @grant        none
// @run-at       document-idle
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

(function () {
  // 1. Inject CSS
  const style = document.createElement('style');
  style.textContent = `
    tr.group_torrent td.non-zero-cell {
      color: #b82625 !important;
    }
  `;
  document.head.appendChild(style);

  // 2. Wait for the DOM and check cells
  function highlightNonZeroCells() {
    document.querySelectorAll('tr.group_torrent').forEach(row => {
      const cell = row.querySelector('td:nth-child(5)');
      if (cell && cell.textContent.trim() !== '0') {
        cell.classList.add('non-zero-cell');
      }
    });
  }

  // Run immediately if DOM is ready, or wait for load
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    highlightNonZeroCells();
  } else {
    document.addEventListener('DOMContentLoaded', highlightNonZeroCells);
  }
})();
