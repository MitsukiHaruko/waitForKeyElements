// ==UserScript==
// @name AB - AniList Integration

// @namespace AnimeBytes Nightly
// @author Mitsuki Haruko
// @version 1.0
// @description Adds direct AniList link, next episode/chapter countdown, YouTube trailer embed, personal watchlist widget and AniList banners (fast + reliable matching)

// @grant GM_xmlhttpRequest
// @grant GM_getValue
// @grant GM_setValue
// @match https://animebytes.tv/torrents.php?id*
// @match https://animebytes.tv/
// @match *://animebytes.tv/user.php?action=edit*
// @updateURL https://gist.github.com/MitsukiHaruko/d30afaf5fe9a09fc719cb2ddd252f7d8/raw/AB_AniList-Integration.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/d30afaf5fe9a09fc719cb2ddd252f7d8/raw/AB_AniList-Integration.user.js
// @icon https://animebytes.tv/favicon.ico
// @require https://github.com/momentary0/AB-Userscripts/raw/master/delicious-library/src/ab_delicious_library.js
// @run-at document-end
// ==/UserScript==

(function () {
    'use strict';

    const LOG_PREFIX = '[AniList Integration]';
    function log(message, style = '') {
        if (style) console.log(`%c${LOG_PREFIX} ${message}`, style);
        else console.log(`${LOG_PREFIX} ${message}`);
    }
    function logError(message, error) {
        console.error(`${LOG_PREFIX} ${message}`, error || '');
    }

    const favicons = {
        "AniList": "https://mei.kuudere.pw/ncihtSl6Awu.png",
    };

    function normalizeLinkName(txt) {
        if (!txt) return null;
        const t = txt.toLowerCase().trim().replace(/[\s|•…‥.]+/g, '');
        return t.includes('anilist') ? 'AniList' : null;
    }

    function replaceLinkWithIcon(a) {
        const text = a.textContent.trim();
        const key = normalizeLinkName(text);
        if (!key || !favicons[key]) return;
        const img = document.createElement('img');
        img.src = favicons[key];
        img.alt = text || key;
        img.title = text || key;
        img.className = 'favicon-icon';
        a.textContent = '';
        a.appendChild(img);
    }

    // ==================== SETTINGS ====================
    if (delicious?.settings?.ensureSettingsInserted?.()) {
        const section = delicious.settings.createCollapsibleSection('Anilist Integration (Trailers, Watchlist, Banners)');
        const body = section.querySelector('.settings_section_body');
        delicious.settings.init('ABAniListEnableTrailers', true);
        body.appendChild(delicious.settings.createCheckbox('ABAniListEnableTrailers', 'Embed YouTube trailers', 'Shows the official trailer (if available).'));
        delicious.settings.init('ABAniListTrailerAtTop', false);
        body.appendChild(delicious.settings.createCheckbox('ABAniListTrailerAtTop', 'Trailer at the Top', 'Inserts trailer at the very top of the main column'));
        delicious.settings.init('ABAniListTrailerAutoplay', false);
        body.appendChild(delicious.settings.createCheckbox('ABAniListTrailerAutoplay', 'Autoplay trailer (muted)', 'Trailer starts playing automatically (muted)'));
        delicious.settings.init('ABAniListEnableBanners', true);
        body.appendChild(delicious.settings.createCheckbox('ABAniListEnableBanners', 'Show AniList banners', 'Displays the large AniList banner image'));
        delicious.settings.insertSection(section);
        log('Settings UI inserted successfully');
    }

    const enableTrailers = JSON.parse(GM_getValue('ABAniListEnableTrailers', 'true'));
    const trailerAtTop = JSON.parse(GM_getValue('ABAniListTrailerAtTop', 'false'));
    const autoplayTrailer = JSON.parse(GM_getValue('ABAniListTrailerAutoplay', 'false'));
    const enableBanners = JSON.parse(GM_getValue('ABAniListEnableBanners', 'true'));
    log(`Settings loaded | Trailers: ${enableTrailers}, Top: ${trailerAtTop}, Autoplay: ${autoplayTrailer}, Banners: ${enableBanners}`);

    // ==================== STYLES ====================
    const bannerStyle = document.createElement('style');
    bannerStyle.textContent = `
        #ab-anilist-banner {
            width: 100%; height: 200px; background-size: cover; background-position: center 25%;
            background-repeat: no-repeat; position: relative; margin: 10px 0 18px 0;
            border-radius: 6px; box-shadow: 0 3px 10px rgba(0,0,0,0.35); overflow: hidden;
        }
        #ab-anilist-banner::after {
            content: ''; position: absolute; inset: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.05), rgba(0,0,0,0.35));
        }
        .weekday-header { margin: 12px 0 6px 0; padding: 4px 10px; border-radius: 4px; font-weight: bold; font-size: 1.05em; }
        .weekday-separator { border: 0; height: 1px; background: #444; margin: 10px 0; }
        .next-ep-item { margin-bottom: 10px; }
        .next-ep-remove { float: right; background: none; border: none; color: #ff5555; font-size: 1.4em; cursor: pointer; padding: 0 4px; }
        .favicon-icon {
            height: 2.15em; width: auto; vertical-align: middle; margin: 0 5px 1px 2px;
            border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.25);
            display: inline-block; transition: transform 0.13s ease;
        }
        .favicon-icon:hover { transform: scale(1.18) !important; }
        .ab-next-ep-timer { font-weight:900; font-size:15px; margin-left:8px; }
        .ab-clear-cache-btn {
            margin-left: 10px;
            font-size: 12px;
            padding: 1px 7px;
            cursor: pointer;
            background: #444;
            color: #ffcc80;
            border: 1px solid #666;
            border-radius: 3px;
            vertical-align: middle;
        }
        .ab-clear-cache-btn:hover {
            background: #555;
            color: #ffe0b2;
        }
        #content div.thin h3, #content div.thin h3 * {
            -webkit-user-select: none !important;
            -moz-user-select: none !important;
            -ms-user-select: none !important;
            user-select: none !important;
        }
    `;
    document.head.appendChild(bannerStyle);

    // ==================== CACHING ====================
    const CORE_CACHE_TTL = 1000 * 60 * 60 * 24 * 120; // 120 days
    const MEDIA_CACHE_TTL = 1000 * 60 * 60 * 24 * 60; // 60 days

    function getCacheKey(title, mediaType, pageTitle = '') {
        // Improved key to prevent TV/OVA collisions on the same name
        const normTitle = title.toLowerCase().replace(/[^a-z0-9]/g, '');
        const pageCtx = pageTitle
            ? pageTitle.toLowerCase().trim().replace(/[^a-z0-9]/g, '')
            : '';
        const ctx = pageCtx ? `_${pageCtx}` : '';
        return `ab_anilist_${mediaType}_${normTitle}${ctx}`;
    }

    function getCachedData(title, mediaType, pageTitleForCache = '') {
        try {
            const key = getCacheKey(title, mediaType, pageTitleForCache);
            const cached = GM_getValue(key);
            if (!cached) return null;
            const data = JSON.parse(cached);
            const age = Date.now() - data.timestamp;
            if (!data.media?.id || age >= CORE_CACHE_TTL) return null;
            const media = data.media;
            const na = media.nextAiringEpisode;
            const now = Math.floor(Date.now() / 1000);
            if (na?.airingAt && na.airingAt < now - 86400) {
                log(`CACHE INVALIDATED: ${media.title.romaji} (old airing time)`, 'color:orange;font-weight:bold');
                return null;
            }
            const hasBanner = !!media.bannerImage;
            const hasTrailer = !!media.trailer?.id;
            if (!hasBanner || !hasTrailer || age > MEDIA_CACHE_TTL) {
                const core = { ...media };
                delete core.bannerImage;
                if (core.trailer) delete core.trailer;
                return { ...core, _needsMediaRefresh: true };
            }
            return media;
        } catch (e) {
            logError('Failed to read cache', e);
            return null;
        }
    }

    function cacheData(title, mediaType, media, pageTitleForCache = '') {
        try {
            const key = getCacheKey(title, mediaType, pageTitleForCache);
            GM_setValue(key, JSON.stringify({ media, timestamp: Date.now() }));
            log(`Cached data for ${media.title?.romaji || title}`);
        } catch (e) {
            logError('Failed to cache data', e);
        }
    }

    function clearEntryCache(title, mediaType, pageTitleForCache = '') {
        try {
            const key = getCacheKey(title, mediaType, pageTitleForCache);
            if (typeof GM_deleteValue === 'function') {
                GM_deleteValue(key);
            } else {
                GM_setValue(key, '');
            }
            log(`Cleared cache for "${title}" (${mediaType})`, 'color:#ff9800;font-weight:bold');
        } catch (e) {
            logError('Failed to clear cache', e);
        }
    }

    function getWatchlistCache(id) {
        try {
            const data = GM_getValue(`ab_watchlist_${id}`);
            if (!data) return null;
            const parsed = JSON.parse(data);
            const na = parsed.data?.nextAiringEpisode;
            if (na?.airingAt) {
                const now = Math.floor(Date.now() / 1000);
                if (na.airingAt < now - 3600) return null;
            }
            return parsed.data;
        } catch (e) {
            logError(`Failed to read watchlist cache for ID ${id}`, e);
            return null;
        }
    }

    function setWatchlistCache(id, data) {
        try {
            GM_setValue(`ab_watchlist_${id}`, JSON.stringify({ data, timestamp: Date.now() }));
        } catch (e) {
            logError(`Failed to set watchlist cache for ID ${id}`, e);
        }
    }

    function getStoredList() {
        try { return JSON.parse(GM_getValue('AB_NextEp_WatchList', '[]')) || []; }
        catch { return []; }
    }

    function saveList(arr) {
        try {
            GM_setValue('AB_NextEp_WatchList', JSON.stringify(arr));
            log(`Watchlist saved (${arr.length} items)`);
        } catch (e) {
            logError('Failed to save watchlist', e);
        }
    }

    // ==================== HELPERS ====================
    function formatTimeUntil(seconds, isAiring = false, mediaType = 'ANIME') {
        if (seconds == null || seconds < 0) return "<span class='countdown-prefix'>—</span>";
        const diff = seconds * 1000;
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const parts = [];
        if (d > 0) parts.push(`${d}d`);
        if (h > 0) parts.push(`${h}h`);
        if (m > 0 || parts.length === 0) parts.push(`${m}m`);
        const timeStr = parts.join(' ');
        const prefix = isAiring ? 'Airing in ' : (mediaType === 'ANIME' ? 'Next ep in ' : 'Next ch in ');
        return `<span class="countdown-prefix">${prefix}</span><span class="countdown-time">${timeStr}</span>`;
    }

    function getStatusBadge(status) {
        const badges = {
            FINISHED: { text: 'Finished', color: '#2196F3' },
            CANCELLED: { text: 'Cancelled', color: '#F44336' },
            HIATUS: { text: 'Hiatus', color: '#9C27B0' },
            NOT_YET_RELEASED: { text: 'Upcoming', color: '#FF9800' }
        };
        const style = badges[status] || { text: status || 'Unknown', color: '#757575' };
        return `<span class="status-badge" style="background:${style.color}; color:white; padding:2px 6px; border-radius:3px; font-size:0.85em; margin-left:8px;">${style.text}</span>`;
    }

    function getWeekdayName(timestamp) {
        if (!timestamp) return "No Date";
        return new Date(timestamp * 1000).toLocaleDateString('en-US', { weekday: 'long' });
    }

    function normalizeTitle(t) {
        if (!t) return '';
        return t.toLowerCase()
            .replace(/[^a-z0-9\s:]/g, '')
            .replace(/\b(ii|iii|iv|v|vi|vii|viii|ix|x|xi)\b/g, m =>
                ({ii:2,iii:3,iv:4,v:5,vi:6,vii:7,viii:8,ix:9,x:10,xi:11}[m] || m))
            .replace(/\b(season|part|cour|arc)\s*(\d+)/gi, '$2')
            .trim();
    }

    function calculateScore(media, searchTerm, preferredYear, preferredFormat) {
        let score = 0;
        const nSearch = normalizeTitle(searchTerm);
        if (media.title.romaji && normalizeTitle(media.title.romaji) === nSearch) score += 100;
        else if (media.title.romaji && normalizeTitle(media.title.romaji).includes(nSearch)) score += 55;
        if (media.title.english && normalizeTitle(media.title.english) === nSearch) score += 90;
        else if (media.title.english && normalizeTitle(media.title.english).includes(nSearch)) score += 50;
        // Strong format preference
        if (preferredFormat) {
            if (media.format === preferredFormat) score += 280;
            else if (media.format) score -= 180;
        }
        if (preferredYear && media.startDate?.year === preferredYear) score += 95;
        return score;
    }

    function computeTimeUntilAiring(na) {
        if (!na?.airingAt) return null;
        return na.airingAt - Math.floor(Date.now() / 1000);
    }

    function getRomajiTitleFromPage() {
        const stats = document.querySelector("ul.stats.nobullet");
        if (!stats) return null;
        const item = [...stats.querySelectorAll("li")].find(li =>
            li.textContent.trim().startsWith("Romaji Title:")
        );
        if (!item) return null;
        return item.textContent.replace(/^Romaji Title:\s*/i, "").trim();
    }

    // Clean previously injected UI so a re-fetch starts clean
    function cleanInjectedUI(h2, h3) {
        document.getElementById('ab-anilist-banner')?.remove();
        document.querySelector('.trailer-box')?.remove();
        h2?.querySelectorAll('.ab-next-ep-timer, .ab-clear-cache-btn').forEach(el => el.remove());
        if (h3) {
            const links = [...h3.querySelectorAll('a')];
            const anilistLink = links.find(a => a.href.includes('anilist.co'));
            if (anilistLink) {
                const prev = anilistLink.previousSibling;
                if (prev && prev.nodeType === Node.ELEMENT_NODE && prev.textContent.trim() === '•') {
                    prev.remove();
                } else if (prev && prev.nodeType === Node.TEXT_NODE && prev.textContent.includes('•')) {
                    prev.textContent = prev.textContent.replace(/\s*•\s*$/, '');
                }
                anilistLink.remove();
            }
        }
    }

    // ==================== API ====================
    function makeGraphQLRequest(query, variables) {
        return new Promise((resolve) => {
            GM_xmlhttpRequest({
                method: 'POST',
                url: 'https://graphql.anilist.co',
                headers: { 'Content-Type': 'application/json' },
                data: JSON.stringify({ query, variables }),
                onload: r => {
                    try {
                        if (r.status === 200) {
                            resolve(JSON.parse(r.responseText).data);
                        } else {
                            log(`GraphQL request failed with status ${r.status}`, 'color:orange');
                            resolve(null);
                        }
                    } catch (e) {
                        logError('Failed to parse GraphQL response', e);
                        resolve(null);
                    }
                },
                onerror: (err) => {
                    logError('GraphQL request network error', err);
                    resolve(null);
                }
            });
        });
    }

    // ==================== DETAIL PAGE ====================
    async function fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, forceMediaRefresh = false, romajiTitle = null, pageTitleForCache = '') {
        log(`Fetching AniList data for: ${title}`);
        // ---------- improved term generation ----------
        const clean = (t) => t ? t.trim()
            .replace(/\b(II|III|IV|V|VI|VII|VIII|IX|X|XI)\b/gi, m =>
                ({II:2,III:3,IV:4,V:5,VI:6,VII:7,VIII:8,IX:9,X:10,XI:11}[m.toUpperCase()] || m))
            .replace(/\b(?:Season|Part|Cour|Arc)\s*(\d+)/gi, ' $1')
            .replace(/\s+/g, ' ').trim() : '';
        const stripSeason = (t) => t
            .replace(/\s+(?:\d+|ii|iii|iv|v|vi|vii|viii|ix|x)$/i, '')
            .replace(/\s+(?:season|part|cour|arc)\s*\d+/gi, '')
            .replace(/\s+/g, ' ')
            .trim();
        const terms = new Set();
        const full = clean(title);
        const short = clean(shortTitle);
        const romaji = romajiTitle ? clean(romajiTitle) : null;
        if (full) terms.add(full);
        if (short) terms.add(short);
        if (romaji) terms.add(romaji); // ← real Romaji title from page
        // always try the version without the trailing season number
        [full, short, romaji].forEach(t => {
            if (!t) return;
            const stripped = stripSeason(t);
            if (stripped && stripped !== t) terms.add(stripped);
        });
        const searchTerms = [...terms].filter(Boolean);
        if (!searchTerms.length) {
            fallback(h3, shortTitle, mediaType);
            return;
        }
        log(`Search terms: ${searchTerms.map(t => `"${t}"`).join(', ')}`);

        // ----- Cache check -----
        let cached = getCachedData(title, mediaType, pageTitleForCache);
        if (cached && !forceMediaRefresh) {
            const needsRefresh = !!cached._needsMediaRefresh;
            delete cached._needsMediaRefresh;
            log(`CACHE HIT for "${title}"${needsRefresh ? ' (rich media refresh needed)' : ''}`,
                needsRefresh ? 'color:orange;font-weight:bold' : 'color:lime;font-weight:bold');
            useResult(cached, h2, h3, mediaType, 999, true, title);
            if (needsRefresh) {
                fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, true, romajiTitle, pageTitleForCache).catch(() => {});
            }
            return;
        }
        if (forceMediaRefresh) log(`FORCED RICH MEDIA REFRESH for "${title}"`, 'color:#ff9800');
        else log(`CACHE MISS → FULL FETCH for "${title}"`, 'color:#ff9800');

        const query = `query ($search: String, $type: MediaType, $format: MediaFormat) {
            Page(perPage: 15) {
                media(search: $search, type: $type, format: $format) {
                    id title { romaji english native }
                    startDate { year } format status
                    bannerImage
                    nextAiringEpisode { airingAt timeUntilAiring episode }
                    trailer { id site }
                }
            }
        }`;

        async function search(terms, useFormat) {
            let bestMedia = null;
            let bestScore = -1;
            const passLabel = useFormat && format ? `format=${format}` : 'no-format-filter';
            log(`Search pass (${passLabel}) for terms: ${terms.map(t => `"${t}"`).join(', ')}`);
            const promises = terms.map(term => {
                const vars = { search: term, type: mediaType };
                if (useFormat && format) vars.format = format;
                return makeGraphQLRequest(query, vars);
            });
            const resultsArray = await Promise.all(promises);
            resultsArray.forEach((data, idx) => {
                const term = terms[idx];
                const results = data?.Page?.media || [];
                if (!results.length) {
                    log(` No results for term "${term}"`);
                    return;
                }
                for (const m of results) {
                    const score = calculateScore(m, term, year, format);
                    log(` Score ${String(score).padStart(4)} → ${m.title.romaji} ` +
                        `(${m.format || '?'}/${m.startDate?.year || '?'}) [term: "${term}"]`);
                    if (score > bestScore) {
                        bestScore = score;
                        bestMedia = m;
                    }
                }
            });
            return { bestMedia, bestScore };
        }

        // 1. Prefer format-filtered search
        let { bestMedia, bestScore } = await search(searchTerms, true);
        // 2. Fallback to unfiltered only if needed
        if (!bestMedia || bestScore < 70) {
            log('Format-filtered search weak → trying unfiltered', 'color:orange');
            const unfiltered = await search(searchTerms, false);
            if (unfiltered.bestScore > bestScore) {
                bestMedia = unfiltered.bestMedia;
                bestScore = unfiltered.bestScore;
            }
        }

        if (bestMedia && bestScore >= 55) {
            cacheData(title, mediaType, bestMedia, pageTitleForCache);
            useResult(bestMedia, h2, h3, mediaType, bestScore, false, title);
        } else {
            log(`No good match found for "${title}" (best score: ${bestScore})`);
            fallback(h3, shortTitle, mediaType);
        }
    }

    // ==================== UI FUNCTIONS ====================
    function insertAniListBanner(bannerUrl) {
        if (!enableBanners || document.getElementById('ab-anilist-banner') || !bannerUrl) return;
        GM_xmlhttpRequest({
            method: 'GET', url: bannerUrl, responseType: 'blob',
            onload: r => {
                if (r.status === 200 && r.response) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                        const banner = document.createElement('div');
                        banner.id = 'ab-anilist-banner';
                        banner.style.backgroundImage = `url(${reader.result})`;
                        document.querySelector('#content .main_column')?.prepend(banner);
                        log('Banner inserted successfully');
                    };
                    reader.readAsDataURL(r.response);
                }
            }
        });
    }

    function embedTrailer(src, atTop = false) {
        if (document.querySelector('.trailer-box')) return;
        log(`Embedding trailer (${atTop ? 'top' : 'after synopsis'})`);
        const ts = document.createElement('div');
        ts.className = 'box trailer-box';
        ts.innerHTML = `
            <div class="head"><strong>Trailer</strong></div>
            <div class="body" style="padding:0 12px 12px 12px;">
                <div style="position:relative;width:100%;padding-bottom:56.25%;height:0">
                    <iframe style="position:absolute;top:0;left:0;width:100%;height:100%;border:none;"
                            src="${src}" allowfullscreen loading="lazy"></iframe>
                </div>
            </div>`;
        const main = document.querySelector('#content .main_column');
        if (!main) return;
        if (atTop) {
            main.prepend(ts);
        } else {
            const synopsisHeader = Array.from(document.querySelectorAll('.box .head strong'))
                .find(el => el.textContent.includes('Plot Synopsis') || el.textContent.includes('Synopsis'));
            if (synopsisHeader) {
                const synopsisBox = synopsisHeader.closest('.box');
                if (synopsisBox) {
                    synopsisBox.after(ts);
                    return;
                }
            }
            main.appendChild(ts);
        }
    }

    function useResult(media, h2, h3, mediaType, score, isCached = false, originalTitle = '') {
        if (!h2) return;
        log(`SELECTED: ${media.title.romaji} (${media.format || '?'}) | Score: ${score}${isCached ? ' [CACHED]' : ''}`,
            'color:lime;font-weight:bold');
        h2.querySelectorAll('.ab-next-ep-timer, .ab-clear-cache-btn').forEach(el => el.remove());
        if (media.bannerImage) insertAniListBanner(media.bannerImage);
        const na = media.nextAiringEpisode;
        let airingText = '';
        if ((media.status === 'RELEASING' || media.status === 'NOT_YET_RELEASED') && na?.airingAt) {
            const secondsLeft = computeTimeUntilAiring(na);
            airingText = formatTimeUntil(secondsLeft, media.status === 'NOT_YET_RELEASED', mediaType);
        }
        const span = document.createElement('span');
        span.className = 'ab-next-ep-timer';
        if (airingText) {
            span.innerHTML = ' | ' + airingText;
        }
        // Add-to-watchlist button
        const list = getStoredList();
        const alreadyAdded = list.some(item => item.id === media.id);
        const btn = document.createElement('button');
        btn.className = 'next-ep-add-btn';
        btn.textContent = alreadyAdded ? '[✓]' : '[+]';
        Object.assign(btn.style, {
            marginLeft: '10px', fontSize: '13px', padding: '1px 6px',
            cursor: alreadyAdded ? 'default' : 'pointer'
        });
        btn.disabled = alreadyAdded;
        btn.title = alreadyAdded ? 'Already added to homepage list' : 'Add to Next Episodes list (homepage)';
        btn.onclick = () => {
            if (alreadyAdded) return;
            const newList = [...list, {
                id: media.id,
                title: media.title.romaji || media.title.english || h2.textContent,
                type: mediaType,
                added: Date.now()
            }];
            saveList(newList);
            btn.textContent = '[✓]';
            btn.disabled = true;
            btn.style.cursor = 'default';
            log(`Added "${media.title.romaji}" to watchlist`);
        };
        span.appendChild(btn);
        // Clear Cache button (only when result came from cache)
     /*    if (isCached && originalTitle) {
            const clearBtn = document.createElement('button');
            clearBtn.className = 'ab-clear-cache-btn';
            clearBtn.textContent = 'Clear Cache';
            clearBtn.title = 'Delete cached AniList data for this entry and re-fetch';
            clearBtn.onclick = () => {
                clearEntryCache(originalTitle, mediaType, h2.textContent.trim());
                cleanInjectedUI(h2, h3);
                const shortTitle = originalTitle.split(':')[0].trim();
                let releaseYear = null, format = null, typeText = '';
                const match = h2.innerHTML.match(/>(.*?)<\/a>\s*-\s*(.*?)\s*\[(\d{4})\]/);
                if (match) {
                    typeText = match[2].trim();
                    releaseYear = parseInt(match[3], 10);
                } else {
                    releaseYear = h2.textContent.match(/\[(\d{4})\]/)?.[1] ? parseInt(RegExp.$1) : null;
                }
                const printed = ["Manga","Oneshot","Manhwa","Manhua","Light Novel","Anthology"];
                const animeFmt = {TV:'TV',OVA:'OVA',Movie:'MOVIE',Special:'SPECIAL',ONA:'ONA'};
                let mt = 'ANIME';
                if (printed.includes(typeText)) mt = 'MANGA';
                else if (typeText in animeFmt) format = animeFmt[typeText];
                const romajiTitle = getRomajiTitleFromPage();
                const pageTitleForCache = h2.textContent.trim();
                fetchAniListData(originalTitle, shortTitle, mt, releaseYear, format, h2, h3, true, romajiTitle, pageTitleForCache);
            };
            span.appendChild(clearBtn);
        } */
        if (airingText || isCached) {
            h2.appendChild(span);
        }
        if (media.id) appendAniListLink(media.id, h3, mediaType);
        const tr = media.trailer;
        if (enableTrailers && tr?.id && tr.site?.toLowerCase() === 'youtube') {
            let params = 'rel=0&modestbranding=1';
            if (autoplayTrailer) params += '&autoplay=1&mute=1';
            embedTrailer(`https://www.youtube-nocookie.com/embed/${tr.id}?${params}`, trailerAtTop);
        }
    }

    function appendAniListLink(id, h3, mediaType) {
        if ([...h3.querySelectorAll('a')].some(a => a.href.includes(`anilist.co/${mediaType.toLowerCase()}/${id}`))) return;
        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createElement('span');
        sep.textContent = ' • ';
        sep.style.color = '#888';
        const a = document.createElement('a');
        a.href = `https://anilist.co/${mediaType.toLowerCase()}/${id}`;
        a.textContent = 'AniList';
        a.target = '_blank';
        replaceLinkWithIcon(a);
        if (last) {
            last.parentNode.insertBefore(sep, last.nextSibling);
            last.parentNode.insertBefore(a, sep.nextSibling);
        } else {
            h3.append(sep, a);
        }
        log(`Appended AniList link for ID ${id}`);
    }

    function fallback(h3, shortTitle, mediaType) {
        const clean = encodeURIComponent(shortTitle.toLowerCase());
        const url = `https://anilist.co/search/${mediaType.toLowerCase()}?search=${clean}`;
        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createElement('span'); sep.textContent = ' • '; sep.style.color = '#888';
        const a = document.createElement('a');
        a.href = url; a.textContent = 'AniList Search'; a.target = '_blank';
        replaceLinkWithIcon(a);
        if (last) {
            last.parentNode.insertBefore(sep, last.nextSibling);
            last.parentNode.insertBefore(a, sep.nextSibling);
        } else h3.append(sep, a);
        log('Using fallback AniList search link');
    }

    function handleDetailPage() {
        const start = (h2, h3) => {
            let seriesTitle = '', typeText = '', releaseYear = null;
            const match = h2.innerHTML.match(/>(.*?)<\/a>\s*-\s*(.*?)\s*\[(\d{4})\]/);
            if (match) {
                seriesTitle = match[1].trim();
                typeText = match[2].trim();
                releaseYear = parseInt(match[3], 10);
            } else {
                seriesTitle = h2.querySelector('a')?.textContent.trim() || h2.textContent.trim();
                releaseYear = h2.textContent.match(/\[(\d{4})\]/)?.[1] ? parseInt(RegExp.$1) : null;
            }
            let mediaType = 'ANIME', format = null;
            const printed = ["Manga","Oneshot","Manhwa","Manhua","Light Novel","Anthology"];
            const animeFmt = {TV:'TV',OVA:'OVA',Movie:'MOVIE',Special:'SPECIAL',ONA:'ONA'};
            if (printed.includes(typeText)) mediaType = 'MANGA';
            else if (typeText in animeFmt) format = animeFmt[typeText];
            const shortTitle = seriesTitle.split(':')[0].trim();
            const romajiTitle = getRomajiTitleFromPage();
            if (romajiTitle) {
                log(`Found Romaji title on page: "${romajiTitle}"`);
            }
            const pageTitleForCache = h2.textContent.trim();
            fetchAniListData(seriesTitle, shortTitle, mediaType, releaseYear, format, h2, h3, false, romajiTitle, pageTitleForCache);
        };
        const h2 = document.querySelector('#content div.thin h2');
        const h3 = document.querySelector('#content div.thin h3');
        if (h2 && h3) start(h2, h3);
        else {
            let attempts = 0;
            const iv = setInterval(() => {
                const h2n = document.querySelector('#content div.thin h2');
                const h3n = document.querySelector('#content div.thin h3');
                if (h2n && h3n) {
                    clearInterval(iv);
                    start(h2n, h3n);
                } else if (++attempts > 30) clearInterval(iv);
            }, 80);
        }
    }

    // ==================== HOMEPAGE WIDGET ====================
    function handleHomePage() {
        if (!location.pathname.match(/^\/$/)) return;
        if (document.getElementById('ab-next-ep-widget')) return;
        const fpright = document.querySelector('.fpright');
        if (!fpright) {
            log('Could not find .fpright container');
            return;
        }
        log('Detected homepage');
        const container = document.createElement('div');
        container.id = 'ab-next-ep-widget';
        container.style.marginBottom = '20px';
        container.innerHTML = `
            <div class="head"><strong>Watch List</strong></div>
            <div class="body" id="next-ep-list" style="padding:12px; font-size:0.94em;">Loading...</div>`;
        fpright.insertBefore(container, fpright.firstChild);
        renderNextEpList();
    }

    async function renderNextEpList() {
        const listEl = document.getElementById('next-ep-list');
        if (!listEl) return;
        const watchlist = getStoredList();
        if (!watchlist.length) {
            listEl.textContent = 'No shows tracked yet. Add with → [+] on series pages';
            return;
        }
        listEl.textContent = 'Updating watchlist...';
        log(`Rendering next episodes list (${watchlist.length} items)`);
        const items = [];
        await Promise.all(watchlist.map(async entry => {
            try {
                let data = getWatchlistCache(entry.id);
                if (!data) {
                    data = await fetchAniListEntry(entry.id, entry.type);
                    if (data) setWatchlistCache(entry.id, data);
                }
                if (!data) return;
                const na = data.nextAiringEpisode;
                items.push({
                    ...entry,
                    airingAt: na?.airingAt ?? null,
                    episode: na?.episode ?? null,
                    title: data.title.romaji || data.title.english || entry.title,
                    status: data.status || 'UNKNOWN'
                });
            } catch (e) {
                logError(`Failed to process watchlist item ${entry.id}`, e);
            }
        }));
        items.sort((a, b) => (a.airingAt ?? Infinity) - (b.airingAt ?? Infinity));
        const ul = document.createElement('ul');
        ul.style.cssText = 'list-style:none;padding:0;margin:0;';
        let currentDay = null;
        for (const it of items) {
            const dayName = it.airingAt ? getWeekdayName(it.airingAt) : "No Date";
            if (dayName !== currentDay) {
                if (currentDay) ul.appendChild(Object.assign(document.createElement('hr'), {className:'weekday-separator'}));
                const header = document.createElement('div');
                header.className = 'weekday-header';
                header.textContent = dayName;
                ul.appendChild(header);
                currentDay = dayName;
            }
            const li = document.createElement('li');
            li.className = 'next-ep-item';
            const countdown = (() => {
                if (it.airingAt == null) return '<span class="countdown-prefix">No upcoming episode</span>';
                const now = Math.floor(Date.now() / 1000);
                const secondsLeft = it.airingAt - now;
                if (secondsLeft < -3600) return '<span class="countdown-prefix">Recently aired</span>';
                if (secondsLeft < 0) return '<span class="countdown-prefix">Just aired</span>';
                return formatTimeUntil(secondsLeft, false, it.type);
            })();
            li.innerHTML = `
                <button class="next-ep-remove" title="Remove from list">×</button>
                <div class="next-ep-header">
                    <a href="https://anilist.co/${it.type.toLowerCase()}/${it.id}" target="_blank">${it.title}</a>
                    ${it.status !== 'RELEASING' ? getStatusBadge(it.status) : ''}
                    ${it.episode ? `<span class="ep-badge">Ep ${it.episode}</span>` : ''}
                </div>
                <div class="next-ep-countdown">${countdown}</div>`;
            li.querySelector('.next-ep-remove').onclick = () => {
                saveList(getStoredList().filter(e => e.id !== it.id));
                renderNextEpList();
            };
            ul.appendChild(li);
        }
        listEl.innerHTML = '';
        listEl.appendChild(ul);
        log('Next episodes widget rendered');
    }

    function fetchAniListEntry(id, mediaType) {
        log(`Fetching single entry ID ${id} (watchlist)`);
        return makeGraphQLRequest(
            `query($id:Int,$type:MediaType){Media(id:$id,type:$type){id title{romaji english}status nextAiringEpisode{airingAt timeUntilAiring episode}}}`,
            { id, type: mediaType }
        ).then(data => data?.Media || null);
    }

    // ==================== INIT ====================
    if (location.pathname.includes('/torrents.php')) {
        handleDetailPage();
    } else if (location.pathname === '/' || location.pathname === '') {
        handleHomePage();
    }
})();