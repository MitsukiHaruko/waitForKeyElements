// ==UserScript==
// @name         AB - Gallery View
// @namespace    AnimeBytes Nightly

// @author       Shanzie, Perilune, Mitsuki Haruko
// @version      1.9
// @description  Gallery view (toggleable) with type coloring + 'Read More' for descriptions

// @grant        GM_addStyle
// @match        https://animebytes.tv/torrents.php*
// @match        https://animebytes.tv/torrents2.php*
// @updateURL https://gist.github.com/MitsukiHaruko/106434b1ef5d4d19ebe06edd597e5ef0/raw/AB_Gallery-View.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/106434b1ef5d4d19ebe06edd597e5ef0/raw/AB_Gallery-View.user.js
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

(function () {
    'use strict';

    const LOCALSTORAGE_KEY = 'animebytesGalleryViewActive_v1';

    const styles = `
        .ab-gallery-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            padding: 20px;
            justify-content: center;
            max-width: 100%;
        }
        .gallery-item {
            width: 180px;
            background-color: #282828;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            border-top: 6px solid #555;
        }
        .gallery-item:hover {
            transform: scale(1.03);
            box-shadow: 0 6px 18px rgba(0,0,0,0.6);
        }
        .gallery-item-clickable-area {
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            height: 100%;
            position: relative;
            z-index: 2;
        }
        .gallery-item img.gallery-cover-image {
            width: 100%;
            height: 282px;
            object-fit: cover;
            background-color: #333;
        }
        .gallery-item .title-container {
            padding: 10px 8px;
            text-align: center;
            background-color: rgba(0,0,0,0.6);
            color: #fff;
            font-size: 0.9em;
            min-height: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .gallery-item .title-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.3;
        }
        .gallery-description-on-hover {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(25,25,25,0.97);
            color: #e8e8e8;
            padding: 12px;
            max-height: 75%;
            overflow-y: auto;
            opacity: 0;
            visibility: hidden;
            transform: translateY(100%);
            transition: all 0.25s ease-out;
            z-index: 3;
            font-size: 0.82em;
            line-height: 1.45;
        }
        .gallery-item:hover .gallery-description-on-hover {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .read-more-link {
            color: #66ccff;
            text-decoration: underline;
            cursor: pointer;
        }
        .read-more-link:hover { color: #99ddff; }
        .original-torrent-group-hidden { display: none !important; }

        #gallery-toggle-button {
            display: block;
            margin: 15px auto 20px;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #4a5568;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        #gallery-toggle-button:hover {
            box-shadow: inset 0 0 0 100px rgba(0, 0, 0, 0.25);
            transform: translateY(-1px);
        }
    `;

    const dynamicLayoutStyles = `
        #content.gallery-content-wrapper-active {
            max-width: 1600px !important; width: auto !important;
            margin-left: auto !important; margin-right: auto !important;
        }
        #content.gallery-content-wrapper-active > .thin,
        #content.gallery-content-wrapper-active > div.thin {
            max-width: 100% !important; width: 100% !important;
        }
    `;

    let galleryContainer = null;
    let originalGroups = null;
    let isGalleryActive = true;
    let toggleButton = null;

    function getItemType(title) {
        const t = title.toUpperCase();
        if (t.includes('MANGA') || t.includes('ANTHOLOGY')) return { topClass: 'top-manga', titleClass: 'type-manga' };
        if (t.includes('LIGHT NOVEL')) return { topClass: 'top-lightnovel', titleClass: 'type-lightnovel' };
        if (t.includes('ARTBOOK')) return { topClass: 'top-artbook', titleClass: 'type-artbook' };
        if (t.includes('VISUAL NOVEL') || t.includes('GAME')) return { topClass: 'top-game', titleClass: 'type-game' };
        if (t.includes('TV SERIES') || t.includes('OVA') || t.includes('DVD SPECIAL') || t.includes('MOVIE') ||
            t.includes('TV SPECIAL') || t.includes('ONA') || t.includes('BD SPECIAL'))
            return { topClass: 'top-anime', titleClass: 'type-anime' };
        return { topClass: 'top-default', titleClass: 'type-default' };
    }

    async function getFullDescription(url) {
        try {
            const res = await fetch(url);
            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const target = doc.evaluate("//strong[text()='Plot Synopsis' or text()='Torrent info']",
                                       doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            return target?.parentElement?.nextElementSibling?.innerHTML || null;
        } catch (e) {
            console.error('Fetch description failed:', e);
            return null;
        }
    }

    async function expandDescription(descElement, torrentLink) {
        const full = await getFullDescription(torrentLink);
        if (full) {
            descElement.innerHTML = full;
        } else {
            descElement.innerHTML += '<br><em style="color:#ff6666;">Could not load full description.</em>';
        }
    }

    function addReadMoreToOriginalView() {
        document.querySelectorAll(".torrent_desc").forEach(desc => {
            if (!desc.textContent.trim().endsWith("...") || desc.querySelector('.read-more-link')) return;

            const linkEl = desc.parentElement.parentElement.querySelector(".group_img > span.mainimg a");
            if (!linkEl) return;

            const a = document.createElement("a");
            a.textContent = "Read all";
            a.href = "javascript:void(0);";
            a.className = "read-more-link";
            a.addEventListener("click", () => expandDescription(desc, linkEl.href));

            desc.append(" ", a);
        });
    }

    function buildGalleryItems() {
        galleryContainer.innerHTML = '';
        let count = 0;

        originalGroups.forEach(group => {
            try {
                const img = group.querySelector('img');
                let coverUrl = img ? img.src : null;
                const a = group.querySelector('div.group_img span.mainimg a');
                const torrentUrl = a ? new URL(a.href, location.origin).href : '#';

                let title = img?.alt || img?.title ||
                           group.querySelector('span.group_title strong a')?.textContent?.trim() || 'Untitled';

                const typeInfo = getItemType(title);

                if (!coverUrl || coverUrl.includes('noartwork')) {
                    coverUrl = `https://placehold.co/240x375/282828/555555?text=${encodeURIComponent(title.substring(0,12))}`;
                }

                const descEl = group.querySelector('div.torrent_desc');
                const rawHTML = descEl ? descEl.innerHTML.trim() : 'No description.';
                const isTruncated = descEl && descEl.textContent.trim().endsWith('...');

                const itemHTML = `
                    <a href="${torrentUrl}" class="gallery-item-clickable-area">
                        <img src="${coverUrl}" alt="${title}" class="gallery-cover-image"
                             onerror="this.src='https://placehold.co/240x375/333/777?text=Error';">
                        <div class="title-container ${typeInfo.titleClass}">
                            <span class="title-text">${title}</span>
                        </div>
                    </a>
                    <div class="gallery-description-on-hover">${rawHTML}${isTruncated ? ' <a href="javascript:void(0)" class="read-more-link">Read all</a>' : ''}</div>
                `;

                const item = document.createElement('div');
                item.className = `gallery-item ${typeInfo.topClass}`;
                item.innerHTML = itemHTML;
                galleryContainer.appendChild(item);
                count++;
            } catch (e) {
                console.error(e);
            }
        });
        return count;
    }

    function initGalleryReadMore() {
        if (!galleryContainer) return;

        galleryContainer.addEventListener('click', async (e) => {
            if (e.target.classList.contains('read-more-link')) {
                e.preventDefault();
                e.stopImmediatePropagation();

                const descDiv = e.target.closest('.gallery-description-on-hover');
                const item = e.target.closest('.gallery-item');
                if (!descDiv || !item) return;

                const link = item.querySelector('a.gallery-item-clickable-area');
                if (link) {
                    await expandDescription(descDiv, link.href);
                }
            }
        });
    }

    function applyView() {
        if (!galleryContainer || !toggleButton) return;
        const content = document.getElementById('content');

        if (isGalleryActive) {
            galleryContainer.style.display = 'flex';
            originalGroups.forEach(g => g.classList.add('original-torrent-group-hidden'));
            toggleButton.textContent = 'Show Original View';
            if (content) content.classList.add('gallery-content-wrapper-active');
        } else {
            galleryContainer.style.display = 'none';
            originalGroups.forEach(g => g.classList.remove('original-torrent-group-hidden'));
            toggleButton.textContent = 'Show Gallery View';
            if (content) content.classList.remove('gallery-content-wrapper-active');
        }
    }

    function toggleView() {
        isGalleryActive = !isGalleryActive;
        localStorage.setItem(LOCALSTORAGE_KEY, isGalleryActive);
        applyView();
    }

    function init() {
        const saved = localStorage.getItem(LOCALSTORAGE_KEY);
        if (saved !== null) isGalleryActive = (saved === 'true');

        GM_addStyle(styles + dynamicLayoutStyles);

        originalGroups = document.querySelectorAll('div.group_cont.box');
        if (originalGroups.length === 0) return;

        addReadMoreToOriginalView();

        galleryContainer = document.createElement('div');
        galleryContainer.className = 'ab-gallery-container';

        const count = buildGalleryItems();
        if (count > 0) {
            initGalleryReadMore();   // ← Event delegation

            toggleButton = document.createElement('button');
            toggleButton.id = 'gallery-toggle-button';
            toggleButton.textContent = isGalleryActive ? 'Show Original View' : 'Show Gallery View';
            toggleButton.addEventListener('click', toggleView);

            const first = originalGroups[0];
            const parent = first.parentNode;
            parent.insertBefore(toggleButton, first);
            parent.insertBefore(galleryContainer, first);

            applyView();
        }
    }

    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();