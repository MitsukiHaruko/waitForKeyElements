// ==UserScript==
// @name AB - Yen Log Summarizer
// @namespace AnimeBytes Nightly

// @author sabs (like "sobs"), sabs@sobs.moe, Mitsuki Haruko
// @version 2.0
// @description: Counting to a million before you can say "gotcha!"
// @homepageURL https://animebytes.tv/forums.php?action=viewthread&threadid=28138

// @match https://animebytes.tv/*/yen*
// @updateURL https://gist.github.com/MitsukiHaruko/5527ceb6f3bc84dcd55f9d515ea47265/raw/AB_Yen-Log-Summarizer.user.js
// @downloadURL https://gist.github.com/MitsukiHaruko/5527ceb6f3bc84dcd55f9d515ea47265/raw/AB_Yen-Log-Summarizer.user.js
// @grant GM_xmlhttpRequest
// @grant GM_log
// @icon https://animebytes.tv/favicon.ico
// ==/UserScript==
(function () {
    'use strict';
    const LOG_PREFIX = "[Yen Log Summarizer]";
    function log(...args) { console.log(LOG_PREFIX, ...args); }
    let gain = 0, loss = 0, processed = 0;
    let interval = null, a = null;
    let calculating = false;

    function scanForGainLossNet(q) {
        let g = 0, l = 0, p = 0;
        q.querySelectorAll(".r99").forEach(el => { g += parseInt(el.innerHTML.replaceAll(",", "").replaceAll("¥", ""), 10) || 0; p++; });
        q.querySelectorAll(".r00").forEach(el => { l += parseInt(el.innerHTML.replaceAll(",", "").replaceAll("¥-", ""), 10) || 0; p++; });
        gain += g; loss += l; processed += p;
        log(`Scanned page - Gains: ¥${g.toLocaleString('en-US')}, Losses: ¥${l.toLocaleString('en-US')}, Processed: ${p}`);
    }

    function scanNextPage(next) {
        setTimeout(() => GM_xmlhttpRequest({
            method: "GET",
            url: next.href,
            onerror: (r) => {
                log("Error fetching next page", { status: r.status, url: next.href });
                alert("AB Yen Log Summarizer: ran into an error while counting. Check console (F12).");
                finish();
            },
            onload: (r) => {
                const d = document.implementation.createHTMLDocument().documentElement;
                d.innerHTML = r.responseText;
                scanForGainLossNet(d);
                const n = [...d.querySelectorAll(".next-prev")].find(x => x.textContent.includes("Next"));
                n ? scanNextPage(n) : drawResults();
            }
        }), 1100);
    }

    function finish() {
        calculating = false;
        clearInterval(interval);
        if (a) a.textContent = "Calculate Yen Stats (starting from this page)";
    }

    function drawResults() {
        const net = gain - loss;
        const div = document.createElement("span");
        div.id = "computed_results";
        div.style.marginLeft = "1.33em";
        div.innerHTML = `<b>Total Yen Stats:</b> ¥${gain.toLocaleString('en-US')} gain - ¥${loss.toLocaleString('en-US')} loss = <span class="${net > 0 ? "r99" : "r00"}">¥${net.toLocaleString('en-US')} net</span>`;
        if (a && a.parentNode) a.parentNode.append(div);
        finish();
        log(`Final - Gain: ¥${gain.toLocaleString('en-US')}, Loss: ¥${loss.toLocaleString('en-US')}, Net: ¥${net.toLocaleString('en-US')}`);
    }

    function startScan() {
        gain = loss = processed = 0;
        document.querySelectorAll("#computed_results").forEach(e => e.remove());
        scanForGainLossNet(document);
        const next = [...document.querySelectorAll(".next-prev")].find(x => x.textContent.includes("Next"));
        next ? scanNextPage(next) : drawResults();
    }

    if (document.querySelectorAll(".box.pad.center").length) return;
    a = document.createElement("a");
    a.className = "btn-sub";
    a.textContent = "Calculate Yen Stats (starting from this page)";
    a.addEventListener("click", () => {
        if (calculating) return;
        calculating = true;
        let n_dots = 1;
        interval = setInterval(() => {
            a.textContent = `Calculating... ${processed} done so far ${"|/-\\"[n_dots++ % 4]}`;
        }, 100);
        startScan();
    });
    const parent = document.querySelector("input[value='Filter']")?.parentNode;
    if (parent) parent.append(a);
})();