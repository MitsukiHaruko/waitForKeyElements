// ==UserScript==
// @name         AB - Peer Tools
// @namespace    AnimeBytes Nightly
// @version      1.0
// @description  Checks peer lists of snatched torrents to check whether you are seeding (with limiter)
// @match        https://animebytes.tv/torrents.php*
// @grant        none
// @icon         https://animebytes.tv/favicon.ico
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    const TARGET_CLASS = 'snatched-by-you';

    let YOUR_USERNAME_LINK_PART = '/user/profile/unknown';

    const profileLink =
        document.querySelector('#username_menu a[href*="/user/profile/"]') ||
        document.querySelector('a.username[href*="/user/profile/"]') ||
        document.querySelector('a[href*="/user/profile/"][class*="username"]') ||
        document.querySelector('#header a[href*="/user/profile/"]') ||
        document.querySelector('a[href*="/user/profile/"]');

    if (profileLink) {
        const href = profileLink.getAttribute('href');
        const match = href.match(/\/user\/profile\/([^\/?#]+)/);
        if (match && match[1] && match[1].length > 1) {
            YOUR_USERNAME_LINK_PART = '/user/profile/' + match[1];
            console.log('[AB Peer Tools] Detected username:', match[1]);
        }
    }

    // limiter
    const MAX_SAFE_TORRENTS = 5;

    async function openPeerList(link) {
        link.click();

        const onclick = link.getAttribute('onclick');
        if (!onclick) return;

        const match = onclick.match(/'(\d+)'/);
        if (!match) return;

        const id = match[1];

        for (let i = 0; i < 50; i++) {
            const tab = document.querySelector(`a[href="#${id}/peerlist"]`);
            if (tab) {
                tab.click();
                return;
            }
            await Promise.resolve();
        }
    }

    async function openAll() {
        const links = Array.from(document.querySelectorAll('a.snatched-torrent'));
        if (!links.length) return;

        for (const link of links) {
            await openPeerList(link);
        }

        for (const link of links) {
            link.click();
        }
    }

    function addButton() {
        const snatchedLinks = document.querySelectorAll('a.snatched-torrent');

        if (snatchedLinks.length > MAX_SAFE_TORRENTS) {
            console.log('[AB Peer Tools] Button hidden: too many snatched torrents (' + snatchedLinks.length + ' > ' + MAX_SAFE_TORRENTS + ')');
            return;
        }

        const link = document.createElement('a');
        link.textContent = 'Check Seeding';
        link.href = '#';
        link.style.cursor = 'pointer';

        link.addEventListener('click', (e) => {
            e.preventDefault();
            openAll();
        });

        const wrapper = document.createElement('span');
        wrapper.appendChild(document.createTextNode('['));
        wrapper.appendChild(link);
        wrapper.appendChild(document.createTextNode(']'));

        const target =
            document.querySelector('.linkbox') ||
            document.querySelector('#content') ||
            document.body;

        target.prepend(wrapper);
    }

    function getTorrentId(row) {
        if (row.id && row.id.startsWith('torrent_')) {
            return row.id.replace('torrent_', '');
        }

        const link = row.querySelector('a[href*="torrentid="]');
        if (link) {
            const m = link.href.match(/torrentid=(\d+)/);
            if (m) return m[1];
        }

        return null;
    }

    function isYouInPeerList(torrentId) {
        if (!torrentId) return false;

        const peerDiv = document.getElementById(torrentId + '_peerlist');
        if (!peerDiv) return false;

        const peerTable = peerDiv.querySelector('table#peers_' + torrentId);
        if (!peerTable) return false;

        return !!peerTable.querySelector(`a[href*="${YOUR_USERNAME_LINK_PART}"]`);
    }

    function markSnatchedCells() {
        const indicators = document.querySelectorAll(
            'span.userscript-highlight[data-field="Snatched"], ' +
            'span.userscript-highlight[data-snatched], ' +
            'span[data-field="Snatched"]'
        );

        indicators.forEach(indicator => {
            let row = indicator.closest('tr');

            while (row && !row.matches('tr[id^="torrent_"], tr.group_torrent, tr[data-torrentid]')) {
                row = row.parentElement?.closest('tr');
            }

            if (!row) return;

            const torrentId = getTorrentId(row);
            if (!torrentId) return;

            if (isYouInPeerList(torrentId)) {
                const td = row.querySelector('td:nth-child(4)');
                if (td) td.classList.add(TARGET_CLASS);
            }
        });

        if (indicators.length === 0) {
            document.querySelectorAll('a[href*="&torrentid="]').forEach(link => {
                if (link.textContent.includes(' - Snatched')) {
                    const row = link.closest('tr');
                    if (!row) return;

                    const torrentId = getTorrentId(row);
                    if (!torrentId) return;

                    if (isYouInPeerList(torrentId)) {
                        const td = row.querySelector('td:nth-child(4)');
                        if (td) td.classList.add(TARGET_CLASS);
                    }
                }
            });
        }
    }

    addButton();

    markSnatchedCells();
    setTimeout(markSnatchedCells, 1200);
    setTimeout(markSnatchedCells, 3000);
    setTimeout(markSnatchedCells, 6000);

    const observer = new MutationObserver(markSnatchedCells);
    observer.observe(document.body, { childList: true, subtree: true });
})();