// ==UserScript==
// @name         AB - Filelist Improvements
// @namespace    AnimeBytes Nightly
// @version      1.3
// @description  Filelist improvements with bencode handling
// @match        https://animebytes.tv/torrents.php?*id=*
// @match        https://animebytes.tv/torrents2.php?*id=*
// @exclude      https://animebytes.tv/torrents*groupid=*
// @icon         https://animebytes.tv/favicon.ico
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const whitespaceRE = /[ \t\r\n]/g;
const handledTorrentIds = Object.create(null);

function bdecode(buffer) {
    if (!(buffer instanceof Uint8Array)) {
        if (buffer instanceof ArrayBuffer) buffer = new Uint8Array(buffer);
        else throw new Error("Invalid input");
    }

    let pos = 0;
    const data = buffer;

    function readUntil(byte) {
        const start = pos;
        while (pos < data.length && data[pos] !== byte) pos++;
        if (pos >= data.length) throw new Error("Unexpected EOF");
        return data.slice(start, pos++);
    }

    function decode() {
        if (pos >= data.length) throw new Error("Unexpected EOF");

        const type = data[pos];

        if (type === 105) {
            pos++;
            const numBytes = readUntil(101);
            return parseInt(decoder.decode(numBytes), 10);
        }

        if (type === 108) {
            pos++;
            const list = [];
            while (data[pos] !== 101) list.push(decode());
            pos++;
            return list;
        }

        if (type === 100) {
            pos++;
            const dict = new Map();
            while (data[pos] !== 101) {
                const key = decode();
                const value = decode();
                dict.set(bytesToString(key), value);
            }
            pos++;
            return dict;
        }

        if (type >= 48 && type <= 57) {
            const lenBytes = readUntil(58);
            const len = parseInt(decoder.decode(lenBytes), 10);
            const bytes = data.slice(pos, pos + len);
            pos += len;
            return bytes;
        }

        throw new Error(`Invalid bencode at ${pos}`);
    }

    return decode();
}

function bencode(obj) {
    if (typeof obj === "number") {
        return encoder.encode(`i${obj}e`);
    }

    if (obj instanceof Uint8Array) {
        const prefix = encoder.encode(obj.length + ":");
        return concat([prefix, obj]);
    }

    if (typeof obj === "string") {
        const bytes = encoder.encode(obj);
        const prefix = encoder.encode(bytes.length + ":");
        return concat([prefix, bytes]);
    }

    if (Array.isArray(obj)) {
        return concat([
            encoder.encode("l"),
            ...obj.map(bencode),
            encoder.encode("e")
        ]);
    }

    if (obj instanceof Map) {
        const entries = [...obj.entries()]
            .sort((a, b) => compareBytes(encoder.encode(a[0]), encoder.encode(b[0])));

        return concat([
            encoder.encode("d"),
            ...entries.flatMap(([k, v]) => [bencode(k), bencode(v)]),
            encoder.encode("e")
        ]);
    }

    return new Uint8Array(0);
}

function concat(arrays) {
    const total = arrays.reduce((s, a) => s + a.length, 0);
    const out = new Uint8Array(total);
    let offset = 0;
    for (const a of arrays) {
        out.set(a, offset);
        offset += a.length;
    }
    return out;
}

function compareBytes(a, b) {
    const len = Math.min(a.length, b.length);
    for (let i = 0; i < len; i++) {
        if (a[i] !== b[i]) return a[i] - b[i];
    }
    return a.length - b.length;
}

function bytesToString(bytes) {
    try {
        return decoder.decode(bytes);
    } catch {
        return Array.from(bytes).join(",");
    }
}

function safeDecode(bytes) {
    const isAscii = bytes.every(b => b >= 32 && b < 127);
    return isAscii ? decoder.decode(bytes) : decoder.decode(bytes);
}

async function sha1(bytes) {
    const hash = await crypto.subtle.digest("SHA-1", bytes);
    return new Uint8Array(hash);
}

function formatBytes(bytes) {
    if (!bytes) return "0 B";
    const units = ["B","KiB","MiB","GiB","TiB","PiB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / 1024**i).toFixed(2) + " " + units[i];
}

const eventHandler = (e) => {
    const target = e.target instanceof Element ? e.target : e.target?.parentElement;
    const tabs = target?.closest("div.tabs");
    if (!tabs) return;

    const fileListElement = tabs.querySelector("div[id$='_filelist']");
    if (!fileListElement) return;

    const match = fileListElement.id.match(/^(\d+)_filelist$/);
    if (!match) return;

    const torrentId = Number(match[1]);
    if (handledTorrentIds[torrentId]) return;
    handledTorrentIds[torrentId] = true;

    const link = document.querySelector(`a[href^='/torrent/${torrentId}/download/']`);
    if (!link) return;

    fetch(new URL(link.getAttribute("href"), location.href), {
        credentials: "same-origin"
    })
    .then(r => r.arrayBuffer())
    .then(async buffer => {
        try {
            const root = bdecode(buffer);
            const info = root.get("info");
            if (!info) return;

            const nameBytes = info.get("name");
            const baseName = safeDecode(nameBytes);

            const pieceLength = info.get("piece length") || 0;
            const pieces = info.get("pieces");
            const pieceCount = pieces instanceof Uint8Array ? Math.floor(pieces.length / 20) : 0;

            const fileMap = new Map();

            const files = info.get("files");
            if (Array.isArray(files)) {
                files.forEach((entry, i) => {
                    const pathArr = entry.get("path");
                    const parts = pathArr.map(p => safeDecode(p));
                    const name = parts.at(-1);
                    const path = parts.slice(0, -1).join("/");

                    fileMap.set(parts.join("/").replace(whitespaceRE, ""), {
                        path,
                        name,
                        length: entry.get("length")
                    });
                });
            } else {
                fileMap.set(baseName.replace(whitespaceRE, ""), {
                    path: "",
                    name: baseName,
                    length: info.get("length") || 0
                });
            }

            const table = document.getElementById(`filelist_${torrentId}`);
            if (!table) return;

            const infoEl = document.createElement("p");

            if (files?.length) {
                infoEl.append(`Root Folder: ${baseName}`, document.createElement("br"));
            }

            infoEl.append(`Piece Count: ${pieceCount.toLocaleString()}`, document.createElement("br"));
            infoEl.append(`Piece Size: ${formatBytes(pieceLength)}`);

            if (fileMap.size > 1) {
                infoEl.append(document.createElement("br"));
                infoEl.append(`File Count: ${fileMap.size}`);
            }

            const infoHashBytes = await sha1(bencode(info));
            const infoHash = Array.from(infoHashBytes)
                .map(b => b.toString(16).padStart(2, "0"))
                .join("")
                .toUpperCase();

            infoEl.append(document.createElement("br"));
            infoEl.append(`Info Hash: ${infoHash}`);

            table.before(infoEl);

            table.querySelectorAll("tr").forEach(row => {
                const cells = row.children;
                if (!cells.length || row.querySelector("strong")) return;

                const pathEl = cells[0];
                const sizeEl = cells[cells.length - 1];

                const key = pathEl.textContent.replace(whitespaceRE, "");
                const entry = fileMap.get(key);
                if (!entry) return;

                pathEl.textContent = (entry.path ? entry.path + "/" : "") + entry.name;
                sizeEl.title = entry.length.toLocaleString() + " bytes";

                fileMap.delete(key);
            });

        } catch (err) {
            console.error("Torrent processing failed:", err);
        }
    })
    .catch(err => console.error("Fetch failed:", err));
};

document.querySelectorAll("a[href$='filelist']").forEach(link => {
    const match = link.getAttribute("href").match(/^#(\d+)[_/]filelist$/);
    if (!match) return;

    const torrentId = Number(match[1]);

    if (location.hash === `#${torrentId}/filelist`) {
        eventHandler({ target: link });
    } else {
        link.addEventListener("click", eventHandler, { once: true, capture: true });
        link.addEventListener("mouseover", eventHandler, { once: true, capture: true });
    }
});