// ==UserScript==
// @name         AB - Search autocomplete
// @namespace    AnimeBytes Nightly
// @version      0.5
// @description  :cool:
// @author       Eva
// @homepage     https://animebytes.tv/forums.php?action=viewthread&threadid=24689
// @icon         https://animebytes.tv/favicon.ico
// @grant        GM_getValue
// @grant        GM_setValue
// @match        https://animebytes.tv/*
// @require      https://github.com/momentary0/AB-Userscripts/raw/master/delicious-library/src/ab_delicious_library.js
// @license      GPL-3.0
// @run-at       document-end
// ==/UserScript==

(() => {
    'use strict';

    // SETTINGS UI (delicious style)
    if (delicious.settings.ensureSettingsInserted()) {
        const section = delicious.settings.createCollapsibleSection('Search autocomplete');
        const body = section.querySelector('.settings_section_body');
        delicious.settings.init('ABSearchACEnableHoverHighlight', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACEnableHoverHighlight',
            'Enable hover highlight',
            'Highlights results when the mouse hovers over them.'
        ));
        delicious.settings.init('ABSearchACEnableCurvedCorners', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACEnableCurvedCorners',
            'Enable curved corners',
            'Applies rounded corners to the autocomplete dropdown.'
        ));
        delicious.settings.init('ABSearchACEnableFiltering', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACEnableFiltering',
            'Enable type filtering',
            'Only shows results of the types listed in "includedTypes".'
        ));
        delicious.settings.init('ABSearchACEnableSortByYear', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACEnableSortByYear',
            'Enable sort by year toggle',
            'Adds an arrow in the first result to toggle ascending/descending year sort.'
        ));
        delicious.settings.init('ABSearchACHighlightMatchingText', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACHighlightMatchingText',
            'Highlight matching text',
            'Highlights the parts of the title/type that match the search query.'
        ));
        delicious.settings.init('ABSearchACEnableCategoryHighlighting', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACEnableCategoryHighlighting',
            'Enable category highlighting',
            'Applies background/text colour based on the series type.'
        ));
        delicious.settings.init('ABSearchACLimitVisibleBeforeScroll', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABSearchACLimitVisibleBeforeScroll',
            'Limit visible results before scroll',
            'Shows only a fixed number of results before the list becomes scrollable.'
        ));
        const note = document.createElement('p');
        note.style.margin = '15px 0';
        note.style.fontStyle = 'italic';
        note.innerHTML = `
            <strong>Advanced options</strong> (highlight colour, category colours, included types,
            number of visible results, etc.) are still configured at the top of the script.<br>
            Edit the script directly if you want to customise them further.
        `;
        body.appendChild(note);
        delicious.settings.insertSection(section);
    }

    // Settings
    const enableHoverHighlight = JSON.parse(GM_getValue('ABSearchACEnableHoverHighlight', 'true'));
    const enableCurvedCorners = JSON.parse(GM_getValue('ABSearchACEnableCurvedCorners', 'true'));
    const enableFiltering = JSON.parse(GM_getValue('ABSearchACEnableFiltering', 'true'));
    const enableSortByYear = JSON.parse(GM_getValue('ABSearchACEnableSortByYear', 'true'));
    const highlightMatchingText = JSON.parse(GM_getValue('ABSearchACHighlightMatchingText', 'true'));
    const enableCategoryHighlighting = JSON.parse(GM_getValue('ABSearchACEnableCategoryHighlighting', 'true'));
    const limitVisibleBeforeScroll = JSON.parse(GM_getValue('ABSearchACLimitVisibleBeforeScroll', 'true'));

    // Script constants
    const visibleResultsBeforeScroll = 10;
    const includedTypes = ["TV Series", "TV Special", "Movie", "OVA", "ONA", "Manga"];
    const highlightColor = '#EC106A';
    const categoryHighlightStyle = 'FULL_BACKGROUND';
    const categoryColors = {
        "TV Series": "rgba(40, 80, 120, 0.3)",
        "Movie": "rgba(120, 40, 80, 0.3)",
        "OVA": "rgba(80, 120, 40, 0.3)",
        "ONA": "rgba(120, 80, 40, 0.3)",
        "TV Special": "rgba(40, 120, 80, 0.3)",
        "Manga": "rgba(80, 40, 120, 0.3)"
    };

    // SCRIPT LOGIC
    let sortAscending = false;
    let last = 0;
    let cache = 0;
    let cached = {};
    let select = 0;
    let backgroundColor = 'black';

    const debounce = (func, timeout = 200) => {
        let timer;
        return (...args) => {
            clearTimeout(timer);
            timer = setTimeout(() => func.apply(this, args), timeout);
        };
    };

    const clearResults = ccomplete => {
        while (ccomplete.lastChild) ccomplete.removeChild(ccomplete.lastChild);
    };

    const autocomplete = async (csearch, ccomplete, ctype) => {
        const search = csearch.value.trim();
        if (!search) {
            select = 0;
            clearResults(ccomplete);
            ccomplete.style.border = 'none';
            return;
        }
        csearch.style.background = backgroundColor;
        let data = [];
        let currcache = 0;
        if (cached[ctype + search]) {
            currcache = last;
            data = cached[ctype + search];
        } else {
            const response = await fetch('/xhr/ac/search/' + ctype + '?q=' + encodeURIComponent(search) + '&cache=' + last);
            currcache = +response.url.split('&cache=')[1];
            data = await response.json();
        }
        if (currcache >= cache || cached[ctype + search]) {
            if (currcache === last) csearch.style.background = null;
            cached[ctype + search] = data;
            cache = currcache;
            if (data.results) {
                let results = data.results;
                if (enableFiltering) {
                    results = results.filter(item => includedTypes.includes(item.type));
                }
                const populateList = () => {
                    clearResults(ccomplete);
                    select = 0;
                    ccomplete.style.maxHeight = '';
                    if (enableSortByYear) {
                        results.sort((a, b) => sortAscending ? a.year - b.year : b.year - a.year);
                    }
                    results.forEach(anime => {
                        const li = document.createElement('li');
                        li.style = 'display:block !important;border-bottom:1px solid rgba(78,78,78,0.31);padding:4px 3px;white-space:nowrap';
                        const link = document.createElement('a');
                        let title = anime.name.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                        link.href = (ctype === 'anime' ? '/torrents.php?id=' : '/torrents2.php?id=') + anime.id;
                        if (title.length > 80) {
                            link.title = title;
                            title = title.substring(0, 80).trim() + '…';
                        }
                        const titlePart = title + (anime.year === '0' ? '' : ' [' + anime.year + ']');
                        const typePart = anime.type;
                        const categoryColor = categoryColors[typePart];
                        if (enableCategoryHighlighting && categoryColor) {
                            switch (categoryHighlightStyle) {
                                case 'FULL_BACKGROUND': li.style.backgroundColor = categoryColor; break;
                                case 'FULL_TEXT': link.style.color = categoryColor; break;
                            }
                        }
                        let finalTitleHTML = titlePart;
                        let finalTypeHTML = typePart;
                        if (highlightMatchingText && search.length > 0) {
                            const escaped = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                            const regex = new RegExp('(' + escaped + ')', 'gi');
                            finalTitleHTML = titlePart.replace(regex, '<span style="color:' + highlightColor + ';">$1</span>');
                            finalTypeHTML = typePart.replace(regex, '<span style="color:' + highlightColor + ';">$1</span>');
                        }
                        if (enableCategoryHighlighting && categoryHighlightStyle === 'CATEGORY_ONLY' && categoryColor && finalTypeHTML === typePart) {
                            finalTypeHTML = `<span style="color:${categoryColor};">${typePart}</span>`;
                        }
                        link.innerHTML = `${finalTitleHTML} - ${finalTypeHTML}`;
                        li.appendChild(link);
                        ccomplete.appendChild(li);
                    });

                    // Sort toggle arrow on first result
                    if (enableSortByYear && ccomplete.firstChild) {
                        const firstLi = ccomplete.firstChild;
                        const link = firstLi.querySelector('a');
                        if (link) {
                            firstLi.style.position = 'relative';
                            link.style.display = 'block';
                            link.style.width = '100%';
                            link.style.paddingLeft = '18px';
                            link.style.boxSizing = 'border-box';
                            const arrow = document.createElement('a');
                            arrow.className = 'sort-toggle-arrow';
                            arrow.style.cursor = 'pointer';
                            arrow.style.textDecoration = 'none';
                            arrow.style.fontSize = '1.2em';
                            arrow.innerHTML = sortAscending ? '▲' : '▼';
                            arrow.title = 'Sort by year: ' + (sortAscending ? 'Ascending' : 'Descending');
                            arrow.style.position = 'absolute';
                            arrow.style.left = '3px';
                            arrow.style.top = '50%';
                            arrow.style.transform = 'translateY(-50%)';
                            arrow.addEventListener('click', e => {
                                e.preventDefault();
                                e.stopPropagation();
                                sortAscending = !sortAscending;
                                populateList();
                            });
                            firstLi.insertBefore(arrow, link);
                        }
                    }

                    ccomplete.style.border = '1px solid #333';
                    if (limitVisibleBeforeScroll && ccomplete.children.length > visibleResultsBeforeScroll) {
                        let height = 0;
                        for (let i = 0; i < visibleResultsBeforeScroll; i++) {
                            height += ccomplete.children[i].offsetHeight || 30;
                        }
                        ccomplete.style.maxHeight = height + 'px';
                    }
                };
                populateList();
            } else {
                ccomplete.style.border = 'none';
            }
        }
        if (Object.keys(cached).length > 200) cached = {};
    };

    const arrowNav = event => {
        const ul = event.target.nextSibling;
        if (!ul || !ul.children.length) return;
        const results = Array.from(ul.children);
        let dir = 0;
        if (event.key === 'ArrowUp') dir = -1;
        if (event.key === 'ArrowDown') dir = 1;
        if (event.key === 'Enter') {
            const focusedItem = ul.querySelector('li.keyboard-focus');
            if (focusedItem) {
                event.preventDefault();
                const link = focusedItem.querySelector('a:not(.sort-toggle-arrow)');
                if (link && link.href) {
                    location.href = link.href;
                }
            }
            return;
        }
        if (!dir) return;
        event.preventDefault();
        ul.querySelectorAll('li.keyboard-focus').forEach(li => li.classList.remove('keyboard-focus'));
        select += dir;
        if (select < 1) select = 1;
        if (select > results.length) select = results.length;
        const item = results[select - 1];
        item.classList.add('keyboard-focus');
        item.scrollIntoView({ block: 'nearest' });
    };

    // Setup inputs
    const inputs = [
        { el: document.querySelector('form[action$="/series.php"] > .series_search, form[action$="/torrents.php"] > .series_search'), type: 'anime' },
        { el: document.querySelector("#series_name_anime"), type: 'anime' },
        { el: document.querySelector('form[action$="/torrents2.php"] > .series_search'), type: 'music' },
        { el: document.querySelector('.inputtext[name="groupname"]'), type: 'music' }
    ].filter(o => o.el);

    if (inputs.length > 0) {
        const refInput = inputs[0].el;
        backgroundColor = getComputedStyle(refInput).backgroundColor;
        inputs.forEach(({ el: input, type }) => {
            input.parentElement.style.position = 'relative';
            input.autocomplete = 'off';
            const ul = document.createElement('ul');
            ul.id = 'autocomplete_' + type;
            ul.className = 'torrentscomplete';
            ul.style.cssText = `
                position:absolute;background:${backgroundColor};color:#9a9a9a;overflow-y:auto;overflow-x:hidden;
                width:max-content;max-width:888px;z-index:1000;min-width:${input.offsetWidth}px;
                left:0;top:${input.clientHeight - 1}px;padding:0;text-align:left;
                font-size:0.723rem;border:none;
            `;
            if (input.name === 'groupname') ul.style.left = '10px';
            input.parentNode.insertBefore(ul, input.nextSibling);
            const debounced = debounce(() => autocomplete(input, ul, type));
            input.addEventListener('input', () => { input.style.background = backgroundColor; debounced(); });
            input.addEventListener('keydown', arrowNav);
            input.addEventListener('focus', () => {
                select = 0;
                ul.querySelectorAll('li.keyboard-focus').forEach(li => li.classList.remove('keyboard-focus'));
            });
        });

        document.body.addEventListener('mousedown', e => {
            if (e.target.classList.contains('sort-toggle-arrow')) e.preventDefault();
        }, true);

        // CSS
        const style = document.createElement('style');
        let css = `
            .torrentscomplete {display:none; scrollbar-width: thin; scrollbar-color: rgba(150,150,150,0.6) transparent;}
            .torrentscomplete::-webkit-scrollbar { width: 6px; }
            .torrentscomplete::-webkit-scrollbar-thumb { background-color: rgba(150,150,150,0.6); }
            .torrentscomplete::-webkit-scrollbar-thumb:hover { background-color: rgba(180,180,180,0.8); }
            .torrentscomplete > li:last-child {border-bottom:none !important;}
            input:focus + .torrentscomplete, .torrentscomplete:hover {display:block;}
            .torrentscomplete > li a {display:block;width:100%;}
            .torrentscomplete > li.keyboard-focus { outline: none; }
        `;
        if (enableSortByYear) {
            css += `.torrentscomplete > li:not(:first-child) { padding-left: 21px !important; }`;
        }
        if (enableCurvedCorners) {
            css += `.torrentscomplete { border-radius: 4px; }
                    .torrentscomplete::-webkit-scrollbar-thumb { border-radius: 3px; }`;
        }
        if (enableHoverHighlight) {
            css += `.torrentscomplete > li {
                        border-left: 3px solid transparent;
                        transition: background-color 0.1s ease-in-out, border-color 0.1s ease-in-out;
                    }
                    .torrentscomplete > li:hover,
                    .torrentscomplete > li.keyboard-focus {
                        background-color: rgba(255, 255, 255, 0.1) !important;
                        border-left-color: #FFFFFF;
                    }`;
        }

        // Only change: make first row link not stretch full width → arrow hitbox becomes small
        css += `
            .torrentscomplete > li:first-child a { width: auto !important; }
        `;

        style.textContent = css;
        document.head.appendChild(style);
    }
})();