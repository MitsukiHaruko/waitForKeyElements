// ==UserScript==
// @name         AB - Mediainfo Autofill
// @version      1.0
// @description  Mediainfo Autofiller for Animebytes
// @icon         https://animebytes.tv/favicon.ico
// @author       Chosensilver
// @match        https://animebytes.tv/upload.php*
// @exclude-match https://animebytes.tv/upload.php?type=music*
// @match         https://animebytes.tv/torrents.php?action=edit*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';



    //Container

    var mediainfo_field = document.getElementById("mediainfo_desc");
    var mediainfo_field2 = document.getElementsByName("mediainfo_desc")[1];

    function checkContains(checkString) {

        var newMediaInfo = mediainfo_field.value.replace(/ /g, "");

        var newCheckString = checkString.replace(/ /g, "");

        if (newMediaInfo.indexOf(newCheckString) != -1) {

            return true;
        }
    }

    function checkContains1(checkString) {

        var newMediaInfo = mediainfo_field2.value.replace(/ /g, "");

        var newCheckString = checkString.replace(/ /g, "");

        if (newMediaInfo.indexOf(newCheckString) != -1) {

            return true;
        }
    }

    function doFill() {

        if (checkContains(".mkv")) {
            document.getElementsByName("containers")[0].value = 'MKV';
        } else if (checkContains(".mp4")) {
            document.getElementsByName("containers")[0].value = 'MP4';
        } else if (checkContains(".avi")) {
            document.getElementsByName("containers")[0].value = 'AVI';
        } else if (checkContains(".ogm")) {
            document.getElementsByName("containers")[0].value = 'OGM';
        } else if (checkContains(".wmv")) {
            document.getElementsByName("containers")[0].value = 'WMV';
        } else if (checkContains(".mpg")) {
            document.getElementsByName("containers")[0].value = 'MPG';
        } else if (checkContains(".m2ts")) {
            document.getElementsByName("containers")[0].value = 'M2TS';
        } else if (checkContains(".vob")) {
            document.getElementsByName("containers")[0].value = 'VOB';
        } else if (checkContains(".ifo")) {
            document.getElementsByName("containers")[0].value = 'IFO';
        } else if (checkContains(".ts")) {
            document.getElementsByName("containers")[0].value = 'TS';
        } else if (checkContains(".flv")) {
            document.getElementsByName("containers")[0].value = 'FLV';
        } else if (checkContains(".rmvb")) {
            document.getElementsByName("containers")[0].value = 'RMVB';
        }


        if (checkContains("Format : AVC") && checkContains("Bit depth : 8 bits")) {
            document.getElementsByName("codecs")[0].value = 'h264';
        } else if (checkContains("Format : AVC") && checkContains("Bit depth : 10 bits")) {
            document.getElementsByName("codecs")[0].value = 'h264 10-bit';
        } else if (checkContains("Format : HEVC") && checkContains("Bit depth : 8 bits")) {
            document.getElementsByName("codecs")[0].value = 'h265';
        } else if (checkContains("Format : HEVC") && checkContains("Bit depth : 10 bits")) {
            document.getElementsByName("codecs")[0].value = 'h265 10-bit';
        } else if (checkContains("XVID")) {
            document.getElementsByName("codecs")[0].value = 'XviD';
        } else if (checkContains("DivX")) {
            document.getElementsByName("codecs")[0].value = 'DivX';
        } else if (checkContains("WMV")) {
            document.getElementsByName("codecs")[0].value = 'WMV';
        } else if (checkContains("Format : MPEG-TS")) {
            document.getElementsByName("codecs")[0].value = 'MPEG-TS';
        } else if (checkContains("Codec ID : V_MPEG2")) {
            document.getElementsByName("codecs")[0].value = 'MPEG-1/2';
        } else if (checkContains("Format : VC-1")) {
            document.getElementsByName("codecs")[0].value = 'VC-1';
        } else if (checkContains("Format : VP6")) {
            document.getElementsByName("codecs")[0].value = 'VP6';
        } else if (checkContains("Format : VP9")) {
            document.getElementsByName("codecs")[0].value = 'VP9';
        } else if (checkContains("Format : AV1")) {
            document.getElementsByName("codecs")[0].value = 'AV1';
        }


        if (checkContains("Height : 1 080 pixels") || checkContains("Width : 1 920 pixels")) {
            if (checkContains("Scan type : Progressive")) {
                document.getElementsByName("resolution")[0].value = '1080p';
            }
        } else if (checkContains("Height : 1 080 pixels") || checkContains("Width : 1 920 pixels")) {
            if (checkContains("Scan type : Interlaced")) {
                document.getElementsByName("resolution")[0].value = '1080i';
            }
        }
        if (checkContains("Height : 1 080 pixels") || checkContains("Width : 1 920 pixels")) {
            document.getElementsByName("resolution")[0].value = '1080p';

        } else if (checkContains("Width : 3 840 pixels") || checkContains("Height : 2 160 pixels")) {
            document.getElementsByName("resolution")[0].value = '4K';

        } else if (checkContains("Height : 720 pixels") || checkContains("Width : 1 280 pixels")) {
            document.getElementsByName("resolution")[0].value = '720p';

        } else if (checkContains("Height : 960 pixels") && checkContains("Width : 540 pixels")) {
            document.getElementsByName("resolution")[0].value = '960x540';

        } else if (checkContains("Width : 1 024 pixels") && checkContains("Height : 576 pixels")) {
            document.getElementsByName("resolution")[0].value = '1024x576';

        } else if (checkContains("Width : 848 pixels") && checkContains("Height : 480 pixels")) {
            document.getElementsByName("resolution")[0].value = '848x480';

        } else if (checkContains("Height : 704 pixels") && checkContains("Width : 396 pixels")) {
            document.getElementsByName("resolution")[0].value = '704x396';

        } else if (checkContains("Width : 720 pixels") && checkContains("Height : 576 pixels")) {
            document.getElementsByName("resolution")[0].value = '720x576';

        } else if (checkContains("Width : 720 pixels") && checkContains("Height : 486 pixels")) {
            document.getElementsByName("resolution")[0].value = '720x486';

        } else if (checkContains("Width : 720 pixels") && checkContains("Height : 480 pixels")) {
            document.getElementsByName("resolution")[0].value = '720x480';

        } else if (checkContains("Width : 640 pixels") && checkContains("Height : 480 pixels")) {
            document.getElementsByName("resolution")[0].value = '640x480';

        } else if (checkContains("Width : 854 pixels") && checkContains("Height : 480 pixels")) {
            document.getElementsByName("resolution")[0].value = 'OTHER';
            document.getElementsByName("other_resolution")[0].value = '854x480';
        }


        if (checkContains("Format : FLAC")) {
            document.getElementById("audio").value = 'FLAC';
        } else if (checkContains("Format : AAC") || checkContains("Format : AAC LC")) {
            document.getElementById("audio").value = 'AAC';
        } else if (checkContains("Codec ID/Hint : MP3")) {
            document.getElementById("audio").value = 'MP3';
        } else if (checkContains("Format : Vorbis")) {
            document.getElementById("audio").value = 'Vorbis';
        } else if (checkContains("Format : Opus")) {
            document.getElementById("audio").value = 'Opus';
        } else if (checkContains("Format : AC-3") || checkContains("Format : E-AC-3")) {
            document.getElementById("audio").value = 'AC3';
        } else if (checkContains("Format : TrueHD")) {
            document.getElementById("audio").value = 'TrueHD';
        } else if (checkContains("Format : DTS") && checkContains("Format profile : ES")) {
            document.getElementById("audio").value = 'DTS';
        } else if (checkContains("Format : DTS XLL") && checkContains("Format profile : MA / Core")) {
            document.getElementById("audio").value = 'DTS-HD-MA';
        } else if (checkContains("Format : DTS") && checkContains("Format profile : MA / Core")) {
            document.getElementById("audio").value = 'DTS-HD MA';
        } else if (checkContains("Format : DTS")) {
            document.getElementById("audio").value = 'DTS';
        } else if (checkContains("Format : PCM")) {
            document.getElementById("audio").value = 'PCM';
        } else if (checkContains("Format : WMA")) {
            document.getElementById("audio").value = 'WMA';
        } else if (checkContains("Format : MPEG Audio") && checkContains("Format profile : Layer 2")) {
            document.getElementById("audio").value = 'MP2';
        } else if (checkContains("Format : WMA")) {
            document.getElementById("audio").value = 'WMA';
        } else if (checkContains("Format : WavPack")) {
            document.getElementById("audio").value = 'WAV';
        } else if (checkContains("Format : WMA")) {
            document.getElementById("audio").value = 'WMA';
        } else if (checkContains("Format : Cooker")) {
            document.getElementById("audio").value = 'RealAudio';
        }

        if (checkContains("Channel(s) : 2 channels")) {
            document.getElementById("audiochannels").value = '2.0';
        } else if (checkContains("Channel(s) : 1 channels")) {
            document.getElementById("audiochannels").value = '1.0';
        } else if(checkContains("Channel(s) : 6 channels")){
            document.getElementById("audiochannels").value = '5.1';

        }

        if (checkContains("Format : ASS") || checkContains("Format : PGS")) {
            document.getElementById("subbing").value = 'Softsubs';
        }

        if (!checkContains("Text")) {
            document.getElementById("subbing").value = 'RAW';
        }


        /// PV and Lives

        if (checkContains1(".mkv")) {
            document.getElementsByName("j_containers")[0].value = 'MKV';
        } else if (checkContains1(".mp4")) {
            document.getElementsByName("j_containers")[0].value = 'MP4';
        } else if (checkContains1(".avi")) {
            document.getElementsByName("j_containers")[0].value = 'AVI';
        } else if (checkContains1(".ogm")) {
            document.getElementsByName("j_containers")[0].value = 'OGM';
        } else if (checkContains1(".wmv")) {
            document.getElementsByName("j_containers")[0].value = 'WMV';
        } else if (checkContains1(".mpg")) {
            document.getElementsByName("j_containers")[0].value = 'MPG';
        } else if (checkContains1(".m2ts")) {
            document.getElementsByName("j_containers")[0].value = 'M2TS';
        } else if (checkContains1(".vob")) {
            document.getElementsByName("j_containers")[0].value = 'VOB';
        } else if (checkContains1(".ifo")) {
            document.getElementsByName("j_containers")[0].value = 'IFO';
        } else if (checkContains1(".ts")) {
            document.getElementsByName("j_containers")[0].value = 'TS';
        } else if (checkContains1(".flv")) {
            document.getElementsByName("j_containers")[0].value = 'FLV';
        } else if (checkContains1(".rmvb")) {
            document.getElementsByName("j_containers")[0].value = 'RMVB';
        }


        if (checkContains1("Format : AVC") && checkContains1("Bit depth : 8 bits")) {
            document.getElementsByName("j_codecs")[0].value = 'h264';
        } else if (checkContains1("Format : AVC") && checkContains1("Bit depth : 10 bits")) {
            document.getElementsByName("j_codecs")[0].value = 'h264 10-bit';
        } else if (checkContains1("Format : HEVC") && checkContains1("Bit depth : 8 bits")) {
            document.getElementsByName("j_codecs")[0].value = 'h265';
        } else if (checkContains1("Format : HEVC") && checkContains1("Bit depth : 10 bits")) {
            document.getElementsByName("j_codecs")[0].value = 'h265 10-bit';
        } else if (checkContains1("XVID")) {
            document.getElementsByName("j_codecs")[0].value = 'XviD';
        } else if (checkContains1("DivX")) {
            document.getElementsByName("j_codecs")[0].value = 'DivX';
        } else if (checkContains1("WMV")) {
            document.getElementsByName("j_codecs")[0].value = 'WMV';
        } else if (checkContains1("Format : MPEG-TS")) {
            document.getElementsByName("j_codecs")[0].value = 'MPEG-TS';
        } else if (checkContains1("Codec ID : V_MPEG2")) {
            document.getElementsByName("j_codecs")[0].value = 'MPEG-1/2';
        } else if (checkContains1("Format : VC-1")) {
            document.getElementsByName("j_codecs")[0].value = 'VC-1';
        } else if (checkContains1("Format : VP6")) {
            document.getElementsByName("j_codecs")[0].value = 'VP6';
        } else if (checkContains1("Format : VP9")) {
            document.getElementsByName("j_codecs")[0].value = 'VP9';
        } else if (checkContains1("Format : AV1")) {
            document.getElementsByName("j_codecs")[0].value = 'AV1';
        }


        if (checkContains1("Height : 1 080 pixels") || checkContains1("Width : 1 920 pixels")) {
            if (checkContains1("Scan type : Progressive")) {
                document.getElementsByName("j_resolution")[0].value = '1080p';
            }
        } else if (checkContains1("Height : 1 080 pixels") || checkContains1("Width : 1 920 pixels")) {
            if (checkContains1("Scan type : Interlaced")) {
                document.getElementsByName("j_resolution")[0].value = '1080i';
            }
        }
        if (checkContains1("Height : 1 080 pixels") || checkContains1("Width : 1 920 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '1080p';

        } else if (checkContains1("Width : 3 840 pixels") || checkContains1("Height : 2 160 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '4K';

        } else if (checkContains1("Height : 720 pixels") || checkContains1("Width : 1 280 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '720p';

        } else if (checkContains1("Height : 960 pixels") && checkContains1("Width : 540 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '960x540';

        } else if (checkContains1("Width : 1 024 pixels") && checkContains1("Height : 576 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '1024x576';

        } else if (checkContains1("Width : 848 pixels") && checkContains1("Height : 480 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '848x480';

        } else if (checkContains1("Height : 704 pixels") && checkContains1("Width : 396 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '704x396';

        } else if (checkContains1("Width : 720 pixels") && checkContains1("Height : 576 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '720x576';

        } else if (checkContains1("Width : 720 pixels") && checkContains1("Height : 486 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '720x486';

        } else if (checkContains1("Width : 720 pixels") && checkContains1("Height : 480 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '720x480';

        } else if (checkContains1("Width : 640 pixels") && checkContains1("Height : 480 pixels")) {
            document.getElementsByName("j_resolution")[0].value = '640x480';

        } else if (checkContains1("Width : 854 pixels") && checkContains1("Height : 480 pixels")) {
            document.getElementsByName("j_resolution")[0].value = 'OTHER';
            document.getElementsByName("other_resolution")[0].value = '854x480';
        }


        if (checkContains1("Format : FLAC")) {
            document.getElementsByName("audio")[1].value = 'FLAC';
        } else if (checkContains1("Format : AAC") || checkContains1("Format : AAC LC")) {
            document.getElementsByName("audio")[1].value = 'AAC';
        } else if (checkContains1("Codec ID/Hint : MP3")) {
            document.getElementsByName("audio")[1].value = 'MP3';
        } else if (checkContains1("Format : Vorbis")) {
            document.getElementsByName("audio")[1].value = 'Vorbis';
        } else if (checkContains1("Format : Opus")) {
            document.getElementsByName("audio")[1].value = 'Opus';
        } else if (checkContains1("Format : AC-3") || checkContains1("Format : E-AC-3")) {
            document.getElementsByName("audio")[1].value = 'AC3';
        } else if (checkContains1("Format : TrueHD")) {
            document.getElementsByName("audio")[1].value = 'TrueHD';
        } else if (checkContains1("Format : DTS") && checkContains1("Format profile : ES")) {
            document.getElementsByName("audio")[1].value = 'DTS';
        } else if (checkContains1("Format : DTS XLL") && checkContains1("Format profile : MA / Core")) {
            document.getElementsByName("audio")[1].value = 'DTS-HD-MA';
        } else if (checkContains1("Format : DTS") && checkContains1("Format profile : MA / Core")) {
            document.getElementsByName("audio")[1].value = 'DTS-HD MA';
        } else if (checkContains1("Format : DTS")) {
            document.getElementsByName("audio")[1].value = 'DTS';
        } else if (checkContains1("Format : PCM")) {
            document.getElementsByName("audio")[1].value = 'PCM';
        } else if (checkContains1("Format : WMA")) {
            document.getElementsByName("audio")[1].value = 'WMA';
        } else if (checkContains1("Format : MPEG Audio") && checkContains1("Format profile : Layer 2")) {
            document.getElementsByName("audio")[1].value = 'MP2';
        } else if (checkContains1("Format : WMA")) {
            document.getElementsByName("audio")[1].value = 'WMA';
        } else if (checkContains1("Format : WavPack")) {
            document.getElementsByName("audio")[1].value = 'WAV';
        } else if (checkContains1("Format : WMA")) {
            document.getElementsByName("audio")[1].value = 'WMA';
        } else if (checkContains1("Format : Cooker")) {
            document.getElementsByName("audio")[1].value = 'RealAudio';
        }

        if (checkContains1("Channel(s) : 2 channels")) {
            document.getElementsByName("audiochannels")[1].value = '2.0';
        } else if (checkContains1("Channel(s) : 1 channels")) {
            document.getElementsByName("audiochannels")[1].value = '1.0';
        }


        if (checkContains1("Format : ASS") || checkContains1("Format : PGS")) {
            document.getElementById("j_subbing").value = 'Softsubs';
        }

        if (!checkContains1("Text")) {
            document.getElementById("j_subbing").value = 'RAW';
        }



    }

    let autofillBTN = document.createElement("button");
    autofillBTN.innerHTML = "Autofill Mediainfo";
    autofillBTN.classList.add("upload_forms");
    autofillBTN.onclick = function() {
        doFill();
        return false;


    };

    var mainFrame = document.getElementById("release_information");
    autofillBTN.style.cssText = "z-index: 100; margin-left: 50%; margin-right: 50%; background-color: rgba(0, 0, 0, 0); background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-attachment: scroll; background-image: linear-gradient(rgb(125, 126, 125) 0%, rgb(58, 58, 58) 100%); background-size: auto; background-origin: padding-box; background-clip: border-box; border-radius: 5px; border: none; color: white; padding: 5px;"
    //mainFrame.appendChild(autofillBTN);

    document.getElementsByName("mediainfo_desc")[0].onchange = function() {
        doFill()
    };
    document.getElementsByName("mediainfo_desc")[1].onchange = function() {
        doFill()
    };






})();