// ==UserScript==
// @name         AB - Discuss
// @namespace    AnimeBytes Nightly
// @version      2026-02-07
// @description  adds a "Discuss" link on airing shows pages that takes you to the forum discussion thread
// @author       Mitsuki Haruko
// @match        https://animebytes.tv/torrents.php?id=*
// @icon         https://animebytes.tv/favicon.ico
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    const h2Element = document.querySelector('div.thin h2');
    if (!h2Element) {
        console.warn('Series title <h2> not found.');
        return;
    }

    if (!h2Element.textContent.includes('[Airing]')) {
        console.log('No [Airing] tag – no Discuss link added.');
        return;
    }

    const titleLink = h2Element.querySelector('a');
    const seriesTitle = titleLink
        ? titleLink.textContent.trim()
        : h2Element.textContent.replace(/\[.*?\]/g, '').trim().split('-')[0].trim();

    if (!seriesTitle) {
        console.warn('Could not extract series title.');
        return;
    }

    console.log('Airing series detected: ' + seriesTitle);

    const searchUrl = 'https://animebytes.tv/forums.php?action=search&search=' + encodeURIComponent(seriesTitle);

    GM_xmlhttpRequest({
        method: 'GET',
        url: searchUrl,
        onload: function(response) {
            if (response.status !== 200) {
                console.warn('Failed to fetch forum search: ' + response.status);
                return;
            }

            const parser = new DOMParser();
            const doc = parser.parseFromString(response.responseText, 'text/html');

            const threadLinks = doc.querySelectorAll('a[href*="viewthread"]');

            let airingThreadLink = null;
            for (const link of threadLinks) {
                if (link.textContent.includes('[Airing]')) {
                    airingThreadLink = link;
                    break;
                }
            }

            if (!airingThreadLink) {
                console.log('No [Airing] thread found in forum search results.');
                return;
            }

            let threadUrl = airingThreadLink.href;
            if (!threadUrl.startsWith('http')) {
                threadUrl = 'https://animebytes.tv' + threadUrl.replace(/^\/+/, '/');
            }

            console.log('Found airing discussion thread: ' + threadUrl);

            addDiscussLink(threadUrl, seriesTitle);
        },
        onerror: function() {
            console.warn('Error fetching forum search page.');
        }
    });

    function addDiscussLink(threadUrl, seriesTitle) {
        const linkboxes = document.querySelectorAll('.linkbox');
        let targetLinkbox = null;
        for (const lb of linkboxes) {
            if (lb.querySelector('a')) {
                targetLinkbox = lb;
                break;
            }
        }
        if (!targetLinkbox) {
            console.warn('No suitable .linkbox found.');
            return;
        }

        const newLink = document.createElement('a');
        newLink.href = threadUrl;
        newLink.textContent = 'Discuss';
        newLink.className = 'ab-discuss-link';

        newLink.title = `Go to airing discussion thread for "${seriesTitle}"`;

        targetLinkbox.appendChild(newLink);

        console.log('Added "Discuss" link with class "ab-discuss-link"');
    }
})();