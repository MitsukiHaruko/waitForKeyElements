// ==UserScript==
// @name         AB - Info
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @icon         http://animebytes.tv/favicon.ico
// @version      1.0
// @description  Adds a credits footer for AnimeBytes Nightly on animebytes.tv
// @match        https://animebytes.tv/
// @grant        GM_addStyle
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // Create main credits container
    const containerDiv = document.createElement('div');
    containerDiv.id = 'animebytes-nightly-credits-container';

    // Version number
    const creditsDiv = document.createElement('div');
    creditsDiv.id = 'animebytes-nightly-credits';
    creditsDiv.textContent = 'AnimeBytes Nightly v2.4';

    // Author credit
    const authorDiv = document.createElement('div');
    authorDiv.id = 'animebytes-nightly-author';
    authorDiv.style.fontSize = 'smaller';
    authorDiv.style.opacity = '0.7';
    authorDiv.style.marginTop = '4px';

    const authorLink = document.createElement('a');
    authorLink.href = 'https://animebytes.tv/user.php?id=63182';
    authorLink.textContent = 'mitsukiharuko';
    authorLink.target = '_blank';
    authorLink.rel = 'noopener';

    authorDiv.appendChild(document.createTextNode('by '));
    authorDiv.appendChild(authorLink);

    containerDiv.appendChild(creditsDiv);
    containerDiv.appendChild(authorDiv);
    document.body.appendChild(containerDiv);
})();