// ==UserScript==
// @name         AB - Enhanced Torrent View
// @namespace    AnimeBytes Nightly
// @description  Shows required seeding time (on hover); allows sorting and filtering of torrent tables
// @include      http*://animebytes.tv/*
// @exclude      https://animebytes.tv/bookmarks.php
// @version      2.1.5
// @grant        GM_getValue
// @grant        GM_setValue
// @icon         http://animebytes.tv/favicon.ico
// @require      https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.10/dayjs.min.js
// @require      https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.11.10/plugin/customParseFormat.min.js
// @require      https://github.com/momentary0/AB-Userscripts/raw/master/delicious-library/src/ab_delicious_library.js
// ==/UserScript==

(function EnhancedTorrentView() {
    'use strict';
    const settingsKeys = ['ABTorrentsReqTime', 'ABSortTorrents', 'ABTorrentsFilter', 'ABHistDynLoad'];
    settingsKeys.forEach(k => delicious.settings.init(k, true));
    const show_required_time = GM_getValue('ABTorrentsReqTime', 'true') === 'true';
    const sort_rows = GM_getValue('ABSortTorrents', 'true') === 'true';
    const filter_torrents = GM_getValue('ABTorrentsFilter', 'true') === 'true';
    const dynamic_load = GM_getValue('ABHistDynLoad', 'true') === 'true';
    const days_per_year = 365.256363;
    const isFranchisePage = window.location.pathname === '/series.php' ||
                            window.location.pathname === '/artist.php';
    const size_RegExp = /^([\d.]+)\s(?:([a-zA-Z])i)?B/;
    const ratio_RegExp = /^(∞|--|[\d.]+)$/;
    const and_RegExp = /(and|\s)/ig;
    const duration_RegExp = /^(?:(\d+)years?)?(?:(\d+)months?)?(?:(\d+)weeks?)?(?:(\d+)days?)?(?:(\d+)hours?)?(?:(\d+)minutes?)?(?:(\d+)seconds?)?/;

    function unit_prefix(p) {
        if (!p) return 1 / 1073741824;
        return { K:1/1048576, M:1/1024, G:1, T:1024 }[p.toUpperCase()] || 1;
    }

    function get_column(row, cell) {
        let col = 0;
        for (let c of row.cells) {
            if (c === cell) break;
            col += c.colSpan;
        }
        return col;
    }

    function get_corresponding_torrent_row(row) {
        const a = row.querySelector('a[href*="/download/"], a[title="Download"]');
        if (!a) return null;
        const m = a.href.match(/torrent\/(\d+)/) || a.href.match(/id=(\d+)/);
        return m ? document.getElementById('torrent_' + m[1]) : null;
    }

    function parse_cell(cell) {
        const txt = cell.textContent.trim().replace(/,/g, '');
        let m;
        if ((m = txt.match(size_RegExp))) return parseFloat(m[1]) * unit_prefix(m[2]);
        if ((m = txt.match(ratio_RegExp))) {
            if (m[1] === '∞') return Infinity;
            if (m[1] === '--') return -1;
            return parseFloat(m[1]);
        }
        m = txt.replace(and_RegExp, '').match(duration_RegExp);
        if (m) {
            const d = m.slice(1).map(v => +v || 0);
            return 24 * (d[0]*days_per_year + d[1]*days_per_year/12 + d[2]*7 + d[3]) + d[4] + d[5]/60;
        }
        return txt.toUpperCase();
    }

    function duration_to_string(hours) {
        const days = Math.floor(hours / 24);
        const remHours = Math.floor(hours % 24);
        const minutes = Math.round((hours * 60) % 60);
        let parts = [];
        if (days) parts.push(days + ' day' + (days > 1 ? 's' : ''));
        if (remHours) parts.push(remHours + ' hour' + (remHours > 1 ? 's' : ''));
        if (minutes) parts.push(minutes + ' minute' + (minutes > 1 ? 's' : ''));
        if (parts.length === 0) return '0 minutes';
        if (parts.length === 1) return parts[0];
        return parts.slice(0, -1).join(', ') + ' and ' + parts[parts.length-1];
    }

    function addRequiredSeedingInfo(table) {
        if (!show_required_time) return;
        const rows = table.querySelectorAll('tr.group_torrent, tr.torrent');
        rows.forEach(row => {
            let sizeCell = null;
            for (let cell of row.cells) {
                if (size_RegExp.test(cell.textContent.trim())) {
                    sizeCell = cell;
                    break;
                }
            }
            if (!sizeCell) return;
            const sizeGB = parse_cell(sizeCell);
            if (typeof sizeGB !== 'number' || isNaN(sizeGB)) return;

            // Official AB rules: 72 h base + 5 h per GB over 10 GB, hard capped at 21 days (504 hours)
            const requiredHours = Math.min(504, Math.max(0, sizeGB - 10) * 5 + 72);

            // Hover title
            sizeCell.title = `Required seeding time:\n${duration_to_string(requiredHours)}\nor it will become a hit & run!`;

            const torrentRow = get_corresponding_torrent_row(row);
            if (torrentRow) {
                const blockquote = torrentRow.querySelector('blockquote');
                if (blockquote) {
                    const wrapper = document.createElement('div');
                    wrapper.style.marginTop = '12px';
                    wrapper.style.paddingTop = '4px';
                    const span = document.createElement('span');
                    span.className = 'r01';
                    span.textContent = `You need to seed this torrent for at least ${duration_to_string(requiredHours)} or it will become a hit & run!`;
                    wrapper.appendChild(span);
                    blockquote.appendChild(document.createElement('br'));
                    blockquote.appendChild(wrapper);
                }
            }
        });
    }

    function filter_torrent_table(filterBody, torrents) {
        const deselected = {};
        const checkboxes = filterBody.querySelectorAll('input[type="checkbox"]');
        for (const cb of checkboxes) {
            if (!cb.checked) deselected[cb.value] = true;
        }
        const available = {};
        const valuesByColumn = [];
        let hasDual = 0, hasFL = 0, hasRem = 0;
        for (const tr of torrents) {
            const isFL = tr.classList.contains('freeleech') || tr.querySelector('img[alt="Freeleech!"]') !== null;
            const isRem = tr.querySelector('img[alt="Remastered"]') !== null;
            const isDA = /Dual Audio/i.test(tr.cells[0]?.lastElementChild?.textContent || '');
            hasDual |= isDA ? 1 : 2;
            hasFL |= isFL ? 1 : 2;
            hasRem |= isRem ? 1 : 2;
        }
        for (const tr of torrents) {
            const corr = get_corresponding_torrent_row(tr);
            const textNode = tr.cells[0]?.lastElementChild;
            if (!textNode) continue;
            let text = textNode.textContent
                .replace(/^\s*»/, '')
                .replace(/\d+:\d+/g, '')
                .replace(/Dual Audio/ig, '')
                .replace(/\|(\s*\|)+/g, '|')
                .replace(/^\s*\|/, '')
                .replace(/\|\s*$/, '')
                .trim();
            const tags = (text.includes('|') ? text.split('|') : text.split('/'))
                .map(t => t.trim())
                .filter(Boolean);
            const isFL = tr.classList.contains('freeleech') || tr.querySelector('img[alt="Freeleech!"]') !== null;
            const isRem = tr.querySelector('img[alt="Remastered"]') !== null;
            const isDA = /Dual Audio/i.test(textNode.textContent);
            if (hasDual === 3) tags.push(isDA ? 'Dual Audio' : 'No Dual Audio');
            if (hasFL === 3) tags.push(isFL ? 'Freeleech' : 'No Freeleech');
            if (hasRem === 3) tags.push(isRem ? 'Remastered' : 'Not Remastered');
            let shouldHide = tags.some(t => deselected[t]);
            tr.style.visibility = shouldHide ? 'collapse' : '';
            if (corr) corr.style.visibility = shouldHide ? 'collapse' : '';
            tags.forEach((tag, colIdx) => {
                if (!tag) return;
                available[tag] = available[tag] ?? 0;
                if (!shouldHide) available[tag] = 1;
                while (valuesByColumn.length <= colIdx) valuesByColumn.push({});
                valuesByColumn[colIdx][tag] = 1;
            });
        }
        const form = document.createElement('form');
        const seen = new Set();
        for (const col of valuesByColumn) {
            if (!col) continue;
            const sorted = Object.keys(col).sort((a,b) => a.toUpperCase().localeCompare(b.toUpperCase()));
            for (const tag of sorted) {
                if (seen.has(tag)) continue;
                seen.add(tag);
                const label = document.createElement('label');
                label.style.marginRight = '1.1em';
                label.style.display = 'inline-block';
                const input = document.createElement('input');
                input.type = 'checkbox';
                input.value = tag;
                input.checked = !deselected[tag];
                if (available[tag] === 0 && !deselected[tag]) label.style.opacity = '0.25';
                if (sorted.length <= 1) label.style.opacity = '0.5';
                label.append(input, ' ', tag);
                form.appendChild(label);
            }
            form.appendChild(document.createElement('hr'));
        }
        while (form.lastElementChild?.tagName === 'HR') {
            form.removeChild(form.lastElementChild);
        }
        filterBody.innerHTML = '';
        if (seen.size > 0 || Object.keys(deselected).length > 0) {
            filterBody.appendChild(form);
        }
        form.addEventListener('change', () => filter_torrent_table(filterBody, torrents));
    }

    function createFilterBox(table) {
        const box = document.createElement('div');
        box.className = 'box torrent_filter_box';
        const head = document.createElement('div');
        head.className = 'head colhead strong';
        head.innerHTML = '<a href="#"><span class="triangle-right-md"><span class="stext">+/-</span></span> Filter</a>';
        const body = document.createElement('div');
        body.className = 'body pad';
        body.style.display = 'none';
        head.addEventListener('click', e => {
            e.preventDefault();
            const tri = head.querySelector('span.triangle-right-md, span.triangle-down-md');
            if (body.style.display !== 'none') {
                body.style.display = 'none';
                tri.className = 'triangle-right-md';
            } else {
                const torrents = table.querySelectorAll('tr.torrent, tr.group_torrent');
                filter_torrent_table(body, torrents);
                body.style.display = '';
                tri.className = 'triangle-down-md';
            }
        });
        box.append(head, body);
        table.parentNode.insertBefore(box, table);
    }

    function parse_table(table) {
        const headerRow = table.querySelector('tr');
        if (!headerRow) return;
        const torrents = table.querySelectorAll('tr.torrent, tr.group_torrent');
        if (torrents.length < 1) return;
        if (show_required_time) {
            addRequiredSeedingInfo(table);
        }
        if (filter_torrents && isFranchisePage) {
            createFilterBox(table);
        }
        if (!isFranchisePage && sort_rows) {
            let tableData = [];
            torrents.forEach(r => {
                const data = [r, get_corresponding_torrent_row(r)];
                for (let c of r.cells) data.push(parse_cell(c));
                tableData.push(data);
            });
            if (tableData.length < 2) return;
            const originalData = tableData.slice();
            let curCol = null;
            let curAsc = true;
            let clearBtn = null;
            const sorter = idx => (a, b) => {
                const A = a[idx + 2], B = b[idx + 2];
                if (A == null && B == null) return 0;
                if (A == null) return 1;
                if (B == null) return -1;
                return A > B ? 1 : A < B ? -1 : 0;
            };
            function render(data) {
                const tbody = data[0][0].parentNode;
                data.forEach(r => {
                    let sep = r[0].nextElementSibling;
                    while (sep && !sep.id.startsWith('group_') && !sep.classList.contains('edition_info')) {
                        sep = sep.nextElementSibling;
                    }
                    if (sep) {
                        tbody.insertBefore(r[0], sep);
                        if (r[1] && r[1] !== r[0]) tbody.insertBefore(r[1], sep);
                    } else {
                        tbody.appendChild(r[0]);
                        if (r[1] && r[1] !== r[0]) tbody.appendChild(r[1]);
                    }
                });
            }
            function clear_sort() {
                tableData = originalData.slice();
                render(tableData);
                curCol = null; curAsc = true;
                clearBtn?.remove(); clearBtn = null;
            }
            function ensureClearBtn() {
                if (clearBtn) return;
                const linkbox = document.querySelector('.linkbox');
                if (!linkbox) return;
                clearBtn = document.createElement('button');
                clearBtn.type = 'button';
                clearBtn.textContent = '[Reset sorting]';
                clearBtn.title = 'Reset table sorting to original order';
                clearBtn.className = 'ab-enhanced-reset-sort-btn';
                clearBtn.style.cssText = 'margin-left:12px; padding:1px 6px; font-size:11px; line-height:1.4; cursor:pointer; color:#ccc; background:transparent; border:1px solid #444; border-radius:3px; vertical-align:middle; user-select:none;';
                clearBtn.addEventListener('click', e => {
                    e.preventDefault(); e.stopPropagation();
                    clear_sort();
                });
                linkbox.appendChild(clearBtn);
            }
            function apply(col, asc) {
                curCol = col; curAsc = asc;
                tableData.sort(sorter(col));
                if (!asc) tableData.reverse();
                render(tableData);
                ensureClearBtn();
            }
            for (let th of headerRow.cells) {
                const idx = get_column(headerRow, th);
                th.style.cursor = 'pointer';
                th.title = 'Click to sort';
                th.addEventListener('click', e => {
                    e.preventDefault(); e.stopPropagation();
                    const asc = (curCol === idx) ? !curAsc : true;
                    apply(idx, asc);
                });
            }
        }
    }

    if (show_required_time || sort_rows || filter_torrents || dynamic_load) {
        document.querySelectorAll('table.torrent_table, table.torrent_group')
            .forEach(parse_table);
    }
})();