// ==UserScript==
// @name                    AnimeBytes - Upload Improvements
// @namespace               https://animebytes.tv/
// @version                 0.7.0
// @description             Improve upload form
// @author                  pine
// @match                   https://animebytes.tv/upload.php
// @match                   https://animebytes.tv/upload.php?type=anime&groupid=*
// @icon                    https://animebytes.tv/favicon.ico
// @require                 https://cdn.jsdelivr.net/npm/marked@18.0.0/lib/marked.umd.js#sha256=d8df3edb841dea09e437b53d516c1a7627e9130afb74e61714a5a48682d89d1c
// @require                 lib/indexeddb.js?1
// @require                 lib/lazy-load-tab.js?1
// @require                 lib/dom-functions.js?1
// @require                 lib/script-settings.js?1
// @require                 lib/markdown-to-bbcode.js?2
// @resource MangaUpdates   https://www.mangaupdates.com/images/manga-updates.svg
// @resource MyAnimeList    https://myanimelist.net/images/favicon.svg
// @resource MangaDex       https://mangadex.org/favicon.svg
// @grant                   GM.xmlHttpRequest
// @grant                   GM.getResourceUrl
// @grant                   GM_getValue
// @grant                   GM_setValue
// @connect                 mangadex.org
// @connect                 api.mangaupdates.com
// @connect                 cdn.mangaupdates.com
// @connect                 myanimelist.net
// @updateURL               https://git.gammaspectra.live/pine/userscripts/raw/branch/main/ab_upload.user.js
// @downloadURL             https://git.gammaspectra.live/pine/userscripts/raw/branch/main/ab_upload.user.js
// ==/UserScript==

// TODO: add cache expiry checks, add forced refresh checkbox
// TODO: warn if only "publishers" on mangaupdates are pixiv/twitter
// TODO: filter search results based on content type

/**
 * @import * as mdexApi from "./types/mangadex-api.d.ts"
 * @import * as muApi from "./types/mangaupdates-api.d.ts"
 * @import * as malApi from "./types/myanimelist-api.d.ts"
 */

/**
 * @typedef {mdexApi.components['schemas']['Manga']} MdexManga
 * @typedef {mdexApi.components['schemas']['MangaList']} MdexMangaSearch
 * @typedef {mdexApi.components['schemas']['CoverList']} MdexCoverSearch
 * @typedef {mdexApi.components['schemas']['Cover']} MdexCover
 * @typedef {mdexApi.components['schemas']['Response']} MdexResponse
 * @typedef {muApi.components['schemas']['SeriesModelV1']} MUManga
 * @typedef {muApi.components['schemas']['SeriesSearchResponseV1']} MUMangaSearch
 * @typedef {muApi.components['schemas']['SeriesModelSearchV1']} MUSearchManga
 * @typedef {malApi.components['schemas']['MangaForDetails']} MALManga
 * @typedef {malApi.components['schemas']['MangaList']} MALMangaSearch
 * @typedef {malApi.components['schemas']['MangaForList']} MALSearchManga
 */

/**
 * @typedef { "TV Series" | "TV Special" | "Movie" | "OVA" | "ONA" | "DVD Special" | "BD Special" } AnimeType
 * @typedef { "Album" | "Soundtrack" | "Single" | "EP" | "Compilation" | "Remix CD" | "Live Album" | "Spokenword" | "Image CD" | "Vocal CD" } MusicType
 * @typedef { "PV" | "DVD" | "Live" } PVLiveType
 * @typedef { "Manga" | "Oneshot" | "Anthology" | "Manhwa" | "Manhua" } MangaType
 * @typedef { "Novel" | "Light Novel" }  LightNovelType
 * @typedef {"Artbook"} ArtbookType
 * @typedef {MangaType | LightNovelType | ArtbookType} PrintedType
 * @typedef { "Game" | "Visual Novel" } GameType
 */

/**
 * @template T
 * @typedef {Object} ABScrapeResponse
 * @property {number} Results
 * @property {{Current: number, Max: number, Limit: {Min: number, Coerced: number, Max: number}}} Pagination
 * @property {number} Matches
 * @property {T[]|undefined} Groups
 */

/**
 * @typedef {Object} ABScrapeAnime
 * @property {number} ID
 * @property {string} CategoryName
 * @property {string} FullName
 * @property {AnimeType|PrintedType|GameType} GroupName
 * @property {number} SeriesID
 * @property {string} SeriesName
 * @property {string} Year
 * @property {string} Image
 * @property {string[]} Synonymns
 * @property {ABSynonymnsV2} SynonymnsV2
 * @property {number} Snatched
 * @property {number} Comments
 * @property {ABLinks} Links
 * @property {number} Votes
 * @property {number} AvgVote
 * @property {string|null} Description
 * @property {string|null} DescriptionHTML
 * @property {number} EpCount
 * @property {string|null} StudioList
 * @property {number} PastWeek
 * @property {boolean} Incomplete
 * @property {boolean} Ongoing
 * @property {string[]} Tags
 * @property {ABTorrent[]} Torrents
 */

/**
 * @typedef {Object} ABScrapeMusic
 * @property {number} ID
 * @property {string} CategoryName
 * @property {string} FullName
 * @property {string} GroupName
 * @property {string} Artists
 * @property {string} Year
 * @property {string} Image
 * @property {number} Snatched
 * @property {number} Comments
 * @property {number} Votes
 * @property {number} AvgVote
 * @property {string|null} Associations
 * @property {string|null} Description
 * @property {string|null} DescriptionHTML
 * @property {number} PastWeek
 * @property {boolean} Ongoing
 * @property {string[]} Tags
 * @property {ABTorrent[]} Torrents
 * /

/**
 * @typedef {Object} ABSynonymnsV2
 * @property {string} Japanese
 * @property {string} Romaji
 * @property {string} Alternative
 */

/**
 * @typedef {Object} ABLinks
 */

/**
 * @typedef {Object} ABTorrent
 * @property {number} ID
 * @property {{EditionTitle: string}} EditionData
 * @property {number} RawDownMultiplier
 * @property {number} RawUpMultiplier
 * @property {string} Link
 * @property {string} Property
 * @property {number} Snatched
 * @property {number} Seeders
 * @property {number} Leechers
 * @property {number} Status
 * @property {number} Size
 * @property {number} FileCount
 * @property {{filename: string, size:number}[]} FileList
 * @property {string} UploadTime
 */

const dbVersion = 1;
const dbName = "cacheDB";
const malMangaStore = "malManga";
const mdexMangaStore = "mdexManga";
const mdexCoverStore = "mdexCovers";
const muMangaStore = "muManga";
/**
 * @typedef {{providers: Record<string,string>}} TypeCap
 * @type {Record<string, TypeCap>}}
 */
const caps = {
    manga: { providers: { "mangadex": "MangaDex", "mangaupdates": "MangaUpdates", "myanimelist": "MyAnimeList" } },
    light_novels: { providers: { "mangaupdates": "MangaUpdates", "myanimelist": "MyAnimeList" } },
};

/** @type {ScriptConfig} */
const scriptConfig = {
    autofillScanlated: { label: "Parse torrent names to automatically check Translated and fill Release Group", default: false },
    hideExistingAutofill: { label: "Hide existing autofill inputs", default: false },
};





class GroupInfo {
    /**
     * @param {Object} opts
     * @param {string?=} opts.mainTitle
     * @param {string?=} opts.jpTitle
     * @param {string} opts.contentType
     * @param {Set<string>} opts.allowedTypes
     * @param {string|number|undefined|null} opts.year
     * @param {Array<string|undefined>} [opts.tags]
     * @param {string?=} opts.coverURL
     * @param {string?=} opts.description
     */
    constructor({
        mainTitle,
        jpTitle,
        year,
        contentType,
        allowedTypes,
        tags,
        coverURL,
        description,
    }) {
        this.mainTitle = mainTitle ?? "";
        this.jpTitle = jpTitle ?? "";
        this.contentType = this.checkType(contentType, allowedTypes);
        this.year = Number(year) ?? 0;
        this.coverURL = coverURL ?? "";
        this.description = description ?? "";
        this.tags = tags?.length ?
            new Set(tags
                .filter(t => typeof t === "string")
                .map(tag => tag.replaceAll(" ", ".").toLowerCase().replaceAll(/[^a-z0-9\.]/g, ""))
                .map(tag => this.tagMap.get(tag) ?? tag)
                .filter(tag => !this.blacklist.has(tag))) :
            new Set([]);
        this.tagString = [...this.tags.values()].join(", ");
    }

    tagMap = new Map(Object.entries({
        "boys.love": "shounen.ai",
        "girls.love": "shoujo.ai",
        "ghosts": "paranormal",
        "magical.sex.shift": "gender.bender",
        "genderswap": "gender.bender",
        "school": "school.life",
        "kids": "kodomo",
        "magical.girls": "mahou.shoujo",
        "superhero": "super.power",
        "postapocalyptic": "post.apocalyptic",
        "cgdct": "cute.girls.doing.cute.things",
        "shota": "shotacon",
        "loli": "lolicon",
    }));

    typeMap = new Map(Object.entries({
        manga: "Manga",
        oneshot: "Oneshot",
        anthology: "Anthology",
        manhwa: "Manhwa",
        manhua: "Manhua",
        lightnovel: "Light Novel",
        novel: "Light Novel",
        doujinshi: "Doujinshi",
        doujin: "Doujinshi",
    }));

    /**
     * @param {string} type
     * @param {Set<string>} allowedTypes
     */
    checkType(type, allowedTypes) {
        if (!type) {
            alert("no content type provided");
            throw new Error("no content type provided");
        }
        const normType = type.toLowerCase().replace(/[_\s-]/g, "");
        const aType = this.typeMap.get(normType);

        if (aType && allowedTypes.has(aType)) {
            return aType;
        }

        alert(`content type ${type} not allowed here`);
        throw new Error(`content type ${type} not allowed here`);
    }

    blacklist = new Set([
        "award.winning",
        "hentai",
        "adult",
        "video.games",
        "eligible.titles.for.you.should.read.this"
    ]);
}

class PrintedGroupInfo extends GroupInfo {
    /**
     * @param {Object} opts
     * @param {string?=} opts.mainTitle
     * @param {string?=} opts.jpTitle
     * @param {string?} [opts.muId]
     * @param {string|number} [opts.annId]
     * @param {string|number} [opts.malId]
     * @param {string} [opts.malSlug]
     * @param {string|undefined} opts.contentType
     * @param {string} opts.category
     * @param {string|number?=} opts.year
     * @param {Array<string|undefined>} [opts.tags]
     * @param {string?=} opts.coverURL
     * @param {string?=} opts.description
     */
    constructor({
        mainTitle,
        jpTitle,
        muId,
        annId,
        malId,
        malSlug,
        contentType,
        category,
        year,
        tags,
        coverURL,
        description,
    }) {
        const allowedTypes = {
            manga: new Set(["Manga", "Oneshot", "Anthology", "Manhwa", "Manhua", "Doujinshi"]),
            lightNovel: new Set(["Light Novel", "Novel"]),
            artbook: new Set(["Artbook"])
        }[category];
        if (!allowedTypes) throw new Error(`invalid category ${category}`);
        if (!contentType) throw new Error("No content type provided");
        super({ mainTitle, jpTitle, contentType, allowedTypes, year, tags, coverURL, description });
        if (this.typeMap.get(contentType) === "Doujinshi") if (!confirm("Content is marked Doujinshi, click OK only if you've received explicit staff approval or if series has since been been published (not self-published) by a JAPANESE publisher")) {
            throw new Error("Doujinshi is not allowed without confirmation");
        }
        this.muId = muId ?? "";
        this.annId = Number(annId) ?? 0;
        this.malId = Number(malId) ?? 0;
        this.malSlug = malSlug?.replaceAll(/[\+\s:]/g, "_").replaceAll(/[!@#\$%\^&\*\(\)<>\/\\+\[\]]/g, "") ?? "";
    }
}

function initDB() {
    return openDB(dbName, dbVersion, (db, oldVersion, e) => {
        if (oldVersion < 1) {
            db.createObjectStore(mdexMangaStore, { keyPath: "id" });
            db.createObjectStore(mdexCoverStore, { keyPath: "id" });
            db.createObjectStore(muMangaStore, { keyPath: "id" });
            db.createObjectStore(malMangaStore, { keyPath: "id" });

            console.log(`upgraded ${dbName} to v${dbVersion}`);
        }
    });
}

function getCompat() {
    return {
        marvBetterUpload: Boolean(document.querySelector(".multi-torrent-upload-button"))
    };
}

/** @param {string} text */
function detectCJKLanguage(text) {
    const hasHiragana = /\p{Script=Hiragana}/u.test(text);
    const hasKatakana = /\p{Script=Katakana}/u.test(text);
    const hasHangul = /\p{Script=Hangul}/u.test(text);
    const hasHan = /\p{Script=Han}/u.test(text);

    if (hasHiragana || hasKatakana) return "jpn";
    if (hasHan) return "cmn";
    if (hasHangul) return "kor";
    return "und";
}

/**
 * @param {string} message
 * @param {HTMLElement} element
 */
function promptDialog(message, element) {
    const { promise: result, resolve: resolveResult } = Promise.withResolvers();

    const dialog = document.createElement("dialog");
    dialog.classList.add("box", "pad");
    Object.assign(dialog.style, {
        position: "fixed",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "clamp(0px, 25%, 100%)",
        color: "inherit",
        margin: "0",
    });

    const form = Object.assign(document.createElement("form"), { method: "dialog" });
    form.style = "display: flex; flex-direction: column; gap: 12px";

    const heading = document.createElement("h3");
    heading.textContent = message;
    heading.style = "text-align: center; color: inherit";

    const cont = document.createElement("div");
    cont.append(element);

    const actions = document.createElement("div");
    actions.style = "display: flex; justify-content: flex-end; gap: 8px";

    const cancelBtn = Object.assign(document.createElement("button"), {
        className: "btn", value: "cancel", textContent: "Cancel", formNoValidate: true,
    });
    const okBtn = Object.assign(document.createElement("button"), {
        className: "btn", value: "ok", textContent: "OK",
    });

    actions.append(cancelBtn, okBtn);
    form.append(heading, cont, actions);
    dialog.append(form);
    document.body.append(dialog);

    dialog.addEventListener("close", () => resolveResult(dialog.returnValue), { once: true });

    return { dialog, result };
}

/**
 * @param {string} message
 * @param {Record<string, string[]>} options
 * @returns {Promise<string>}
 */
async function promptSelect(message, options) {
    const select = document.createElement("select");
    select.style = "display: block; margin: 0 auto";

    for (const [k, v] of Object.entries(options)) {
        if (!v.length) continue;
        const optgroup = Object.assign(document.createElement("optgroup"), { label: k });
        for (const o of v) optgroup.append(new Option(o, o));
        select.append(optgroup);
    }

    if (!select.options.length) return "";
    select.selectedIndex = -1;
    select.autofocus = true;

    const { dialog, result } = promptDialog(message, select);
    dialog.showModal();

    const returnValue = await result;
    dialog.remove();
    return returnValue === "ok" ? select.value : "";
}

/**
 * @param {Object} opts
 * @param {Element} opts.root
 * @param {Element|undefined} [opts.afterEl]
 * @param {string|undefined} [opts.description]
 * @param {Record<string, string|number>[]} [opts.inputOpts]
 * @param {string[]|undefined} [opts.buttonNames]
 * @param {string|undefined} [opts.iconSrc]
 */
function addInput({ root, afterEl, description = "", inputOpts = [{}], buttonNames = [], iconSrc = "" }) {
    const title = Object.assign(document.createElement("dt"), { textContent: description });
    if (iconSrc) {
        const img = Object.assign(document.createElement("img"), { src: GM_getResourceURL(iconSrc) });
        img.style.height = "100%";
        img.style.width = "auto";
        img.style.objectFit = "contain";
        title.append(img);
    }
    title.style.display = "flex";
    title.style.alignItems = "stretch";

    const inputs = inputOpts.map(({ type = "text", id = "", size = 50 }) => Object.assign(document.createElement("input"), { type, id, size }));

    const buttons = buttonNames.map(name => Object.assign(document.createElement("button"), { type: "button", textContent: name, classList: "btn" }));

    const dd = document.createElement("dd");
    const container = document.createElement("div");
    dd.append(container);
    container.append(...inputs.flatMap(i => [document.createTextNode(" "), i]), ...buttons.flatMap(b => [document.createTextNode(" "), b]));

    if (afterEl && root.contains(afterEl)) {
        afterEl.after(title, dd);
    } else {
        root.append(title, dd);
    }

    return { title, inputs, buttons, container };
}

function addMultifileInput() {
    for (const uploadTab of document.querySelectorAll("#dynamic_form > div:not(#packs)")) {
        if (!(uploadTab instanceof HTMLDivElement)) throw new Error(`Unexpected element type for upload tab: ${uploadTab.tagName}`);

        const type = uploadTab.id;

        const torrentFileRoot = uploadTab.querySelector("#torrent_file");
        const torrentInput = torrentFileRoot?.querySelector("input[type='file'][id^='file_input']");
        if (!(torrentFileRoot && torrentInput?.parentElement)) throw new Error(`Unable to find torrent input for ${type}`);

        /** @type {WindowProxy[]} */
        const tabs = [];
        const { title, container, inputs, buttons } = addInput({
            root: torrentFileRoot,
            afterEl: torrentInput.parentElement,
            description: "Multi Torrent Upload",
            inputOpts: [{ type: "file", accept: ".torrent, *", id: `pine-multi-file-${type}` },],
            buttonNames: ["Close opened tabs"]
        });
        Object.assign(container.style, { display: "flex", gap: "8px" });
        container.classList.add("pine-multi-file-container");
        title.classList.add("pine-multi-file-container");

        const fileInput = inputs[0];
        const closeButton = buttons[0];
        closeButton.addEventListener("click", () => { while (tabs.length) tabs.pop()?.close(); });


        const providerSelect = document.createElement("select");
        if (caps[type]?.providers) {
            for (const [k, v] of Object.entries(caps[type].providers)) {
                providerSelect.add(new Option(v, k));
            }
            fileInput.after(Object.assign(document.createElement("strong"), { textContent: "Autofill type:" }), providerSelect);
        }


        fileInput.multiple = true;
        fileInput.addEventListener("change", async (event) => {
            /** @type {FileList} */
            const files = event.target?.files;
            if (!(files instanceof FileList && files.length)) return;

            // wait of even 0 appears to be sufficient
            // wait so chrome doesn't error with `window.open blocked due to active file chooser.`
            await new Promise((resolve) => setTimeout(resolve, 0));

            for (const file of files) {
                const uuid = crypto.randomUUID();

                /** @type {WindowProxy|null} */
                const tab = lazyLoadTab({
                    title: file.name,
                    url: `${window.location.origin}/upload.php#${type}`,
                    data: { contentType: type, provider: providerSelect.value, uuid: uuid }
                });
                if (!tab) throw new Error(`failed to open tab for: ${file}`);
                tabs.push(tab);

                console.log("loaded", tab, "opened by", tab.opener, "for file:", file.name);

                window.addEventListener("message", /** @type {MessageEvent} */ async (event) => {
                    if (!(
                        event.source === tab &&
                        event.origin === window.location.origin &&
                        typeof event.data === "object" &&
                        event.data.type === "lazyLoadTab:focused" &&
                        event.data.uuid === uuid
                    )) return;

                    /** @type {Window} */
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                    if (!tab.document?.body?.id || tab.document.body.id !== "upload") {
                        console.log("waiting");
                        // TODO: figure out why this wait doesn't work so sleep can be removed
                        await waitElement("body#upload", tab.document.documentElement);
                    }

                    tab.document.body.classList.add("child-tab");
                    tab.document.head.append(Object.assign(document.createElement("style"), {
                        textContent: "body.child-tab .pine-multi-file-container { display: none !important; }"
                    }));

                    const uploadTab = tab.document.querySelector(`#dynamic_form > div#${event.data.contentType}`);
                    const filePicker = uploadTab?.querySelector(`#torrent_file input#file_input_${type}`);
                    if (!(uploadTab?.tagName == "DIV" && filePicker?.tagName === "INPUT")) return;


                    const fileData = new DataTransfer();
                    fileData.items.add(file);
                    filePicker.files = fileData.files;
                    filePicker.dispatchEvent(new Event("change"));

                    if (event.data.provider) uploadTab.querySelector(`#${event.data.provider}-autofill-${type}`).value = file.name.replace(/\s*\[.*?\](\.torrent)?$/, "");
                });
            }
            window.open()?.close();
        });
    }
}

/** @param {PrintedGroupInfo} info */
function fillMangaData(info) {
    const type = "manga";
    const root = document.querySelector(`#${type}_form > #group_information`);
    const compat = getCompat();

    if (!(root instanceof HTMLDivElement)) throw new Error("No group information field found");

    // @ts-ignore
    if (info.mainTitle) root.querySelector(`#series_name_${type}`).value = info.mainTitle; // @ts-ignore
    if (info.jpTitle) root.querySelector(`#series2_${type}`).value = info.jpTitle; // @ts-ignore
    if (info.muId) root.querySelector(`#link1_${type}`).value = `https://www.mangaupdates.com/series/${info.muId}`;  // @ts-ignore
    if (info.annId) root.querySelector(`#link2_${type}`).value = `https://www.animenewsnetwork.com/encyclopedia/manga.php?id=${info.annId}`; // @ts-ignore
    if (info.malId && info.malSlug) root.querySelector(`#link3_${type}`).value = `https://myanimelist.net/manga/${info.malId}/${info.malSlug}`; // @ts-ignore
    const typeSelector = root.querySelector(`#${type}type`); // @ts-ignore
    if (info.contentType) typeSelector.value = info.contentType;  // @ts-ignore
    if (info.year) root.querySelector(`#year_${type}`).value = info.year;  // @ts-ignore
    if (info.tags.size) root.querySelector(`#tags_${type}`).value = info.tagString; // @ts-ignore
    if (info.coverURL) root.querySelector(`#image_${type}`).value = info.coverURL;  // @ts-ignore
    if (info.description) root.querySelector(`#desc_${type}`).value = info.description;

    if (compat.marvBetterUpload && typeSelector) {
        const chipsDiv = typeSelector.previousElementSibling;
        if (!chipsDiv) return;
        for (const chip of chipsDiv.children) {
            chip.innerText === info.contentType ?
                chip.classList.add("selected") :
                chip.classList.remove("selected");
        }
    }
}

/** @param {PrintedGroupInfo} info */
function fillLNData(info) {
    const type = "light_novels";
    const root = document.querySelector(`#${type}_form > #group_information`);

    if (!(root instanceof HTMLDivElement)) throw new Error("No group information field found");

    // @ts-ignore
    if (info.mainTitle) root.querySelector(`#series_name_${type}`).value = info.mainTitle; // @ts-ignore
    if (info.jpTitle) root.querySelector(`#series2_${type}`).value = info.jpTitle; // @ts-ignore
    if (info.year) root.querySelector(`#year_${type}`).value = info.year; // @ts-ignore
    if (info.tags.size) root.querySelector(`#tags_${type}`).value = info.tagString; // @ts-ignore
    if (info.coverURL) root.querySelector(`#image_${type}`).value = info.coverURL; // @ts-ignore
    if (info.description) root.querySelector(`#desc_${type}`).value = info.description; // @ts-ignore
}

/**
 * @template TRaw
 * @template [TReturn=TRaw]
 * @param {object} opts
 * @param {string} opts.store
 * @param {string|number} opts.id
 * @param {Tampermonkey.Request} opts.request
 * @param {(res: Tampermonkey.Response<TRaw>) => boolean} [opts.validate]
 * @param {(data: TRaw) => TReturn} [opts.transform]
 * @returns {Promise<TReturn>}
 */
async function cachedFetch({ store, id, request, validate, transform }) {
    const db = await openDB(dbName, dbVersion, () => { });

    /** @type {{ value: TReturn } | undefined} */
    const rec = await getRecord(db, store, id);
    if (rec !== undefined) return rec.value;

    /** @type {Tampermonkey.Response<TRaw>} */
    const res = await GM.xmlHttpRequest({ responseType: "json", anonymous: true, ...request });

    if (!(res && res.status >= 200 && res.status < 300)) {
        throw new Error(`HTTP error! Status: ${res?.status}`);
    }

    if (typeof validate === "function" && !validate(res)) {
        throw new Error("Unexpected data");
    }

    const value = typeof transform === "function"
        ? transform(res.response)
        : /** @type {TReturn} */ res.response;

    await setRecord(db, store, value, id);
    return value;
}

/**
 * @param {string} ref
 * @param {string} category
 * @returns {Promise<PrintedGroupInfo>}
 */
async function getMdexData(ref, category) {
    const name = "MangaDex";
    const idPattern = /^[a-f0-9]{8}-([a-f0-9]{4}-){3}[a-f0-9]{12}$/;

    let id;
    if (idPattern.test(ref)) {
        id = ref;
    } else {
        const url = new URL(ref);
        const testId = url.pathname.split("/")[2] ?? "";

        if (!(
            url.host === "mangadex.org" &&
            url.pathname.startsWith("/title/") &&
            idPattern.test(testId)
        )) {
            alert(`Invalid ${name} Link`);
            throw new Error(`${name} URL [${url}] does not match expected format`);
        }
        id = testId;
    }

    /** @type {MdexManga} */
    const data = await cachedFetch({
        store: mdexMangaStore, id,
        request: { url: `https://api.mangadex.org/manga/${id}` },
        validate: r => typeof r.response.data === "object" && r.response.result === "ok",
        transform: r => r.data,
    });

    let muData, malData;
    try {
        if (data.attributes?.links?.mu) muData = await getMUData(data.attributes?.links?.mu, "manga");
        if (data.attributes?.links?.mal) malData = await getMALData(data.attributes?.links?.mal, "manga");
    } catch (e) {
        console.error(e);
    }

    /** @type {MdexCoverSearch} */
    const coverData = await cachedFetch({
        store: mdexCoverStore, id,
        request: { url: `https://api.mangadex.org/cover?order[volume]=asc&manga[]=${id}&limit=10` },
    });
    const cover = coverData?.data?.[0];
    const coverURL = cover ? `https://mangadex.org/covers/${id}/${cover.attributes?.fileName}.512.jpg` : "";

    const tags = [
        ...data.attributes?.tags?.
            filter(t => ["theme", "genre", "demo"].includes(t.attributes?.group ?? "")).
            map(tag => tag.attributes?.name?.en ?? "") ?? "",
        ...(malData?.tags.values() ?? []),
        ...(muData?.tags.values() ?? []),
    ];

    /** @type {MangaType|"Doujinshi"} */
    let cType = "Manga";
    if (data.attributes?.tags) {
        const cTypes = data?.attributes?.tags
            .filter(t => t.attributes?.group === "format")
            .flatMap(t => t.attributes?.name?.en ?? []);
        if (cTypes.length) {
            if (cTypes.includes("Doujinshi")) {
                cType = "Doujinshi";
            } else if (cType.includes("Oneshot")) {
                cType = "Oneshot";
            } else if (cTypes.includes("Manhua")) {
                cType = "Manhua";
            } else if (cTypes.includes("Manhwa")) {
                cType = "Manhwa";
            } else if (cTypes.includes("Anthology")) {
                cType = "Anthology";
            }
        }
    }

    return new PrintedGroupInfo({
        mainTitle: malData?.mainTitle ||
            muData?.mainTitle ||
            data.attributes?.title?.['ja-ro'] ||
            data.attributes?.title?.en,
        jpTitle: malData?.jpTitle || data.attributes?.altTitles?.
            find((lang,) => "ja" in lang)?.ja ||
            muData?.jpTitle,
        muId: data.attributes?.links?.mu,
        malId: data.attributes?.links?.mal,
        malSlug: malData?.malSlug,
        contentType: cType,
        category: category,
        year: muData?.year || data.attributes?.year || malData?.year,
        tags,
        coverURL,
        description: markdownToBBCode(data.attributes?.description?.en),
    });
}

/**
 * @param {string|Number} ref
 * @param {string} category
 * @returns {Promise<PrintedGroupInfo>}
 */
async function getMUData(ref, category, promptTitle = true) {
    const name = "MangaUpdates";
    const idPattern = /^[0-9a-z]{5,7}$/;

    const id = ((ref) => {
        if (typeof ref === "number") return ref;
        if (!isNaN(Number(ref))) return Number(ref);
        if (idPattern.test(ref)) return parseInt(ref, 36);

        const url = new URL(ref);
        const testId = url.pathname.split("/")[2] ?? "";
        if (!(
            ["www.mangaupdates.com", "mangaupdates.com"].includes(url.host) &&
            url.pathname.startsWith("/series/") &&
            idPattern.test(testId)
        )) {
            alert(`Invalid ${name} Link`);
            throw new Error(`${name} URL [${url}] does not match expected format`);
        }
        return parseInt(testId, 36);
    })(ref);

    /** @type {MUManga} */
    const data = await cachedFetch({
        store: muMangaStore, id,
        request: { url: `https://api.mangaupdates.com/v1/series/${id}` }
    });
    const titles = data.associated?.map(entry => {
        return {
            lang: detectCJKLanguage(entry.title), title: entry.title
        };
    });

    // https://developer.mozilla.org/en-US/docs/Web/API/LanguageDetector/detect looks very interesting if ever widely implemented
    // also browser.i18n.detectLanguage() but extension only :(
    const jpTitles = titles?.filter(title => title.lang === "jpn").map(t => t.title) ?? [];
    const cnTitles = titles?.filter(title => title.lang === "cmn").map(t => t.title) ?? [];
    const krTitles = titles?.filter(title => title.lang === "kor").map(t => t.title) ?? [];
    const unsureTitles = titles?.filter(title => title.lang === "und").map(t => t.title) ?? [];

    let title;
    if (!data.type) throw new Error("Unknown content type");
    if (["Manga", "Artbook", "Oneshot", "Novel"].includes(data.type) && jpTitles.length === 1) {
        title = jpTitles[0];
    } else if (data.type === "Manhwa" && krTitles.length === 1) {
        title = krTitles[0];
    } else if (data.type === "Manhua" && cnTitles.length === 1) {
        title = cnTitles[0];
    } else {
        title = await promptSelect(`Japanese/Original title (${name})`, {
            "Japanese Titles": jpTitles,
            "Korean Titles": krTitles,
            "Chinese (or Kanji) Titles": cnTitles,
            "Other Titles": unsureTitles,
        });
    }

    return new PrintedGroupInfo({
        mainTitle: data.title?.replace(/\s*\(Novel\)$/, ""),
        jpTitle: title?.replace(/\s*\((Novel|小説)\)$/, ""),
        muId: id.toString(36),
        contentType: data.type,
        category: category,
        year: data.year,
        tags: data.genres?.map(entry => entry.genre),
        coverURL: data.image?.url?.original,
        description: markdownToBBCode(data.description),
    });
}

/**
 * @param {string|Number} ref
 * @param {string} category
 * @returns {Promise<PrintedGroupInfo>}
 */
async function getMALData(ref, category) {
    const name = "MyAnimeList";
    const idPattern = /^\d+$/;

    const id = ((ref) => {
        if (typeof ref === "number") return ref;
        if (!isNaN(Number(ref))) return Number(ref);

        const url = new URL(ref);
        const testId = url.pathname.split("/")[2] ?? "";
        if (!(
            url.host === "myanimelist.net" &&
            url.pathname.startsWith("/manga/") &&
            idPattern.test(testId)
        )) {
            alert(`Invalid ${name} Link`);
            throw new Error(`${name} URL [${url}] does not match expected format`);
        }
        return Number(testId);
    })(ref);

    const fields = [
        "id", "title", "alternative_titles",
        "main_picture", "pictures", "background",
        "start_date", "end_date",
        "synopsis", "genres",
        "created_at", "updated_at",
        "media_type", "status", "nsfw",
        "num_volumes", "num_chapters",
        "authors{first_name,last_name}",
        "serialization{name}",
    ].join(",");

    /** @type {MALManga} */
    const data = await cachedFetch({
        store: malMangaStore, id,
        request: {
            url: `https://api.myanimelist.net/v2/manga/${id}?fields=${fields}`,
            headers: { "X-MAL-CLIENT-ID": Array.from(atob("ZTc4OTRhMTFlZjUxZTFkMTA3N2IxODZhYzAwZDQxMTY=")).reverse().join("") }
        }
    });

    return new PrintedGroupInfo({
        mainTitle: data.alternative_titles?.en || data.title,
        jpTitle: data.alternative_titles?.ja,
        malId: id,
        malSlug: data.title,
        contentType: data.media_type,
        category: category,
        year: (new Date(data?.start_date ?? "")).getUTCFullYear(),
        tags: data.genres?.map(g => g.name),
        coverURL: data.main_picture?.large,
        description: data.synopsis,
    });
}

/** @param {string} ref */
async function fillMdexData(ref) { fillMangaData(await getMdexData(ref, "manga")); }

/** @param {string|Number} ref */
async function fillMUData(ref) { fillMangaData(await getMUData(ref, "manga")); }

/** @param {string|Number} ref */
async function fillMALData(ref) { fillMangaData(await getMALData(ref, "manga")); }

/** @param {string|null|undefined} url */
async function gmFetchData(url) {
    if (!(url && URL.canParse(url))) return "";

    const r = await GM.xmlHttpRequest({ url, responseType: "blob" });

    if (!(r.response instanceof Blob && r.response.size)) return "";

    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.readAsDataURL(r.response);
    });
}

/**
 * @param {string} title
 * @param {string[]} [originalLanguages]
 * @returns {Promise<MdexManga[]>}
 */
async function searchMdex(title, originalLanguages = ["ja", "ko", "zh", "zh-hk"]) {
    const name = "MangaDex";
    const params = new URLSearchParams([
        ["includes[]", "cover_art"],
        ["contentRating[]", "safe"],
        ["contentRating[]", "suggestive"],
        ["contentRating[]", "erotica"],
        ["title", title],
        ["availableTranslatedLanguage[]", "en"],
        ["excludedTags[]", "b13b2a48-c720-44a9-9c77-39c9979373fb"], // Doujinshi
        ["limit", "24"],
    ]);
    for (const lang of originalLanguages) params.append("originalLanguage[]", lang);

    const res = await GM.xmlHttpRequest({
        url: `https://api.mangadex.org/manga?${params}`,
        responseType: "json",
        anonymous: true
    });

    if (!(res && res.status >= 200 && res.status < 300)) throw new Error(`HTTP error! Status: ${res.status}`);
    if (!(typeof res.response.data === "object" && res.response.result === "ok")) throw new Error(`invalid response`);

    /** @type {MdexMangaSearch} */
    const mangaListRes = res.response;

    if (!mangaListRes.data) throw new Error(`No data on ${name} response`);

    return mangaListRes.data;
}

/**
 * @param {string} title
 * @param {string} type
 * @returns
 */
async function searchMU(title, type) {
    const name = "MangaUpdates";

    const typeFilter = {
        manga: ["Manga", "Oneshot", "Anthology", "Manhwa", "Manhua"],
        light_novels: ["Novel"],
        artbook: ["Artbook"]
    }[type];
    if (!typeFilter) throw new Error(`Invalid type ${type} provided for ${name} search`);


    const res = await GM.xmlHttpRequest({
        url: `https://api.mangaupdates.com/v1/series/search`,
        method: "POST",
        responseType: "json",
        anonymous: true,
        headers: { "Content-Type": "application/json" },
        data: JSON.stringify({
            search: title,
            perpage: 24,
            type: typeFilter,
        })
    });

    if (!(res && res.status >= 200 && res.status < 300)) throw new Error(`HTTP error! Status: ${res.status}`);
    if (typeof res.response !== "object") throw new Error(`invalid response`);

    /** @type {MUMangaSearch} */
    const mangaListRes = res.response;

    if (!mangaListRes) throw new Error(`No data on ${name} response`);
    const data = mangaListRes.results?.map(result => result.record);

    return data;
}

/**
 * @param {string} title
 * @returns {Promise<MALSearchManga[]>}
 */
async function searchMAL(title) {
    const name = "MyAnimeList";

    const params = new URLSearchParams({ q: title, limit: "24", offset: "0", nsfw: "true" });
    const res = await GM.xmlHttpRequest({
        url: `https://api.myanimelist.net/v2/manga?q=${params}`,
        responseType: "json",
        anonymous: true,
        headers: { "X-MAL-CLIENT-ID": Array.from(atob("ZTc4OTRhMTFlZjUxZTFkMTA3N2IxODZhYzAwZDQxMTY=")).reverse().join("") },
    });

    if (!(res && res.status >= 200 && res.status < 300)) throw new Error(`HTTP error! Status: ${res.status}`);
    if (typeof res.response.data !== "object") throw new Error(`invalid response`);

    /** @type {MALMangaSearch} */
    const mangaListRes = res.response;

    if (!mangaListRes.data) throw new Error(`No data on ${name} response`);
    const data = mangaListRes.data.filter(manga => "node" in manga).map(manga => manga.node);

    return data;
}

/**
 * @param {string} message
 * @param {Array<Object|undefined>} results
 * @param {Object} generators
 * @param {(r: any) => string|number|undefined} generators.getId
 * @param {(r: any) => string|undefined} generators.getTitle
 * @param {(r: any) => string|undefined} generators.getCoverURL
 * @param {(r: any) => string|undefined} generators.getURL
 * @returns
 */
async function promptSearchResults(message, results, { getId, getTitle, getCoverURL, getURL }) {
    const container = document.createElement("div");
    Object.assign(container.style, { display: "flex", flexDirection: "column", gap: "12px", });

    const select = document.createElement("select");

    const grid = document.createElement("div");
    Object.assign(grid.style, {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
        gap: "8px",
        maxHeight: "60vh",
        overflowY: "auto",
    });

    const entries = await Promise.all(results.map(async result => {
        return {
            id: getId(result) ?? "",
            title: getTitle(result) ?? "",
            image: await gmFetchData(getCoverURL(result)),
            link: getURL(result) ?? "",
        };
    }));

    for (const { id, title, image, link } of entries) {
        const opt = new Option(title, String(id));
        select.append(opt);

        const card = Object.assign(document.createElement("div"), { title });
        Object.assign(card.style, {
            display: "flex",
            flexDirection: "column",
            gap: "4px",
            cursor: "pointer",
            textAlign: "center",
            height: "100%",
        });
        card.dataset.index = String(id);

        const thumb = document.createElement("div");
        Object.assign(thumb.style, {
            width: "100%",
            aspectRatio: "2/3",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            overflow: "hidden",
            borderRadius: "4px",
            background: "rgba(127,127,127,0.08)",
        });

        const img = document.createElement("img");
        Object.assign(img, { src: image, alt: title });
        Object.assign(img.style, {
            width: "100%",
            height: "100%",
            objectFit: "cover",
            borderRadius: "4px",
        });
        thumb.append(img);

        const label = document.createElement("span");
        label.textContent = title;
        Object.assign(label.style, {
            fontSize: "0.75em",
            overflow: "hidden",
            display: "-webkit-box",
            WebkitBoxOrient: "vertical",
            WebkitLineClamp: "3",
            whiteSpace: "normal",
            wordBreak: "break-word",
        });

        const anchor = Object.assign(document.createElement("a"), { href: link, target: "_blank", rel: "noopener noreferrer", textContent: "↗ Open", });
        Object.assign(anchor.style, { color: "inherit", opacity: "0.6", marginTop: "auto" });

        anchor.addEventListener("click", e => e.stopPropagation());

        const body = document.createElement("div");
        Object.assign(body.style, {
            display: "flex",
            flexDirection: "column",
            gap: "4px",
            padding: "6px",
            border: "2px solid transparent",
            borderRadius: "6px",
            transition: "border-color 0.15s",
        });

        body.append(thumb, label);
        card.append(body, anchor);
        grid.append(card);
    };

    function selectCard(id) {
        for (const card of grid.querySelectorAll("[data-index] > div")) card.style.borderColor = "transparent";

        const card = grid.querySelector(`[data-index="${CSS.escape(id)}"]`);
        if (card && card.firstElementChild) {
            card.firstElementChild.style.borderColor = "currentColor";
            card.scrollIntoView({ block: "nearest" });
        }

        select.value = id;
    }

    grid.addEventListener("click", e => {
        const card = e.target?.closest("[data-index]");
        if (card) selectCard(card.dataset.index);
    });

    select.selectedIndex = -1;
    select.addEventListener("change", (e) => { if (e.isTrusted) selectCard(select.value); });

    container.append(select, grid);

    const { dialog, result } = promptDialog(message, container);
    dialog.showModal();

    return result.then(returnValue => {
        const value = returnValue === "ok" ? select.value : null;
        dialog.remove();
        return value;
    });
}

/**
 * @param {string} mainTitle
 * @param {string} jpTitle
 * @param {"anime"|"music"} type
 * @returns {Promise<boolean>}
 */
async function checkDupe(mainTitle, jpTitle, type = "anime") {
    if (!mainTitle) throw new Error("title required for duplicate search");

    const announceURL = new URL(document.querySelector("div.thin.yui-navset > p > input")?.value);
    if (!announceURL) throw new Error("No announce URL found");

    const username = document.querySelector(".username")?.innerText;
    const passkey = announceURL.pathname.split("/")[1];
    if (!(username && passkey)) throw new Error("unable to find username or passkey");

    /** @param {string} title */
    const makeParams = title => new URLSearchParams({
        torrent_pass: passkey,
        username: username,
        type: type,
        sort: "relevance",
        showhidden: "1",
        searchstr: title.replaceAll(/"':\?/g, "")
    });

    const mainRes = await fetch(new URL(`/scrape.php?${makeParams(mainTitle)}`, window.location.origin), { credentials: "omit" });
    if (!mainRes.ok) throw new Error(`${mainRes.status} error`);
    /** @type {ABScrapeResponse<ABScrapeAnime>} */
    const mainData = await mainRes.json();
    if (typeof mainData !== "object") throw new Error("invalid scrape response");

    let jpGroups;
    if (jpTitle) {
        const jpRes = await fetch(new URL(`/scrape.php?${makeParams(jpTitle)}`, window.location.origin), { credentials: "omit" });
        if (!jpRes.ok) throw new Error(`${jpRes.status} error`);
        /** @type {ABScrapeResponse<ABScrapeAnime>} */
        const jpData = await jpRes.json();
        if (typeof jpData !== "object") throw new Error("invalid scrape response");
        jpGroups = jpData.Groups;
    }

    const groups = [...(mainData?.Groups ?? []), ...(jpGroups ? jpGroups : [])];
    if (!groups.length) return true;

    const mainTitleMatch = groups.find(g => g.SeriesName === mainTitle);
    const jpTitleMatches = groups.filter(g => g.SynonymnsV2.Japanese.normalize("NFKC") === jpTitle.normalize("NFKC"));
    const altTitleMatches = groups.filter(g => [g.SynonymnsV2.Romaji, g.SynonymnsV2.Alternative].includes(mainTitle));

    const div = document.createElement("div");
    Object.assign(div.style, { display: "flex", flexDirection: "column", gap: "1em" });

    if (mainTitleMatch) {
        let h = document.createElement("h2"); h.innerText = "Existing series with exact title";
        let p = Object.assign(document.createElement("p"), { textContent: "The following series matches the Main Title of your upload, confirm this torrent is related to the following series or change the Main Title to avoid uploading under an unrelated group" });
        let a = Object.assign(document.createElement("a"), { href: `/series.php?id=${mainTitleMatch.SeriesID}`, innerText: mainTitle });

        div.appendChild(document.createElement("div")).append(h, p, a);
    }

    if (jpTitleMatches && jpTitleMatches.some(g => g.SeriesID !== mainTitleMatch?.SeriesID)) {
        let h = document.createElement("h2"); h.innerText = "Existing series with exact Japanese title";
        let p = Object.assign(document.createElement("p"), { textContent: "The following series match the Japanese Title of your upload, if these are the same series you should change the main title to this" });
        const links = new Map(jpTitleMatches.map(group => [
            group.SeriesID,
            Object.assign(document.createElement("a"), { href: `/series.php?id=${group.SeriesID}`, innerText: group.SeriesName })
        ])).values();

        div.appendChild(document.createElement("div")).append(h, p, ...links);
    }

    if (altTitleMatches.length && altTitleMatches.some(g => g.SeriesID !== mainTitleMatch?.SeriesID)) {
        let h = document.createElement("h2"); h.innerText = "The following series have Romaji or Alternate Titles matching the Main Title of your upload, if these are the same series you should change the main title to this";
        const links = new Map(altTitleMatches.map(group => [
            group.SeriesID,
            Object.assign(document.createElement("a"), { href: `/series.php?id=${group.SeriesID}`, innerText: group.SeriesName })
        ])).values();

        div.appendChild(document.createElement("div")).append(h, ...links);
    }

    if (!(mainTitleMatch || jpTitleMatches.length || altTitleMatches.length)) return true;
    div.appendChild(document.createElement("div")).append(
        "If you require assistance merging a series you can ",
        Object.assign(document.createElement("a"), { href: "/forums.php?action=viewthread&threadid=2965", innerText: "request an edit" }),
        ".",
    );

    const { dialog, result } = promptDialog("", div);
    dialog.showModal();

    return await result === "ok";
}

(async () => {
    "use strict";

    const newGroup = window.location.search === "";

    for (const eventType of ["dragover", "drop"]) {
        document.addEventListener(eventType, /** @param {DragEvent} e */ e => { if (e.dataTransfer?.types.includes("Files")) e.preventDefault(); });
    };


    const div = document.createElement("div");
    div.style.marginBottom = "16px";

    const button = Object.assign(document.createElement("button"), { className: "btn", textContent: "Upload script settings" });
    button?.addEventListener("click", () => manageSettings(scriptConfig));
    div.append(button);
    document.querySelector("#dynamic_form")?.before(div);

    const fileInputSel = newGroup ?
        ".ui-tabs-panel:not([style*='display: none']) > form > #torrent_file input[name='file_input']" :
        "#torrent_file input[name='file_input']";
    document.addEventListener("drop", (e) => {
        if (!e.dataTransfer?.types.includes("Files")) return;
        if ([...e.dataTransfer.files].find(file => file.name.split(".").pop() !== "torrent")) return;

        const fileInput = document.querySelector(fileInputSel);
        if (!(fileInput instanceof HTMLInputElement)) return;
        fileInput.files = e.dataTransfer.files;
        fileInput.dispatchEvent(new Event("change"));
    });

    if (!newGroup) return;

    await initDB();
    addMultifileInput();

    for (const form of document.querySelectorAll("#dynamic_form > div:not(#packs,#music,#pvs) > .upload_forms")) {
        const virt = Object.assign(document.createElement("button"), { type: "submit", hidden: true });
        form.append(virt);
        form.addEventListener("submit", /** @param {SubmitEvent} e */ async (e) => {
            if (e.submitter === virt || !e.isTrusted) return;

            if (!(form instanceof HTMLFormElement)) return;
            e.preventDefault();

            const names = new FormData(form).getAll("series_name[]").filter(entry => typeof entry === "string");
            const proceed = await checkDupe(names[0], names[1], "anime").catch(() => false);
            if (proceed) form.requestSubmit(virt);
        });
    };
})();

// Manga
(async () => {
    "use strict";
    const type = "manga";

    const root = document.querySelector("#manga");
    if (!(root instanceof HTMLDivElement)) return;

    root.querySelector("input#file_input_manga")?.addEventListener("change", (e) => {
        if (!(e.target instanceof HTMLInputElement && e.target.files)) return;
        const releaseGroupName = root.querySelector("input#release_group_name");
        const releaseGroupDiv = root.querySelector("div#release_group_manga");
        const translatedStatus = root.querySelector("input#scanlation");

        const name = e.target.files.item(0)?.name ?? "";

        if (
            /\[.*?\](\.\w+)?.torrent$/.test(name) &&
            releaseGroupName instanceof HTMLInputElement &&
            releaseGroupDiv instanceof HTMLDivElement &&
            translatedStatus instanceof HTMLInputElement
        ) {
            const provider = root.querySelector(".pine-multi-file-container > select");
            if (provider?.value) root.querySelector(`#${provider.value}-autofill-${type}`).value = name.replace(/\s*\[.*?\](\.torrent)?$/, "");

            if (!GM_getValue("autofillScanlated", false)) return;
            translatedStatus.checked = true;
            releaseGroupDiv.style.display = "";
            releaseGroupName.value = name?.match(/\[(.*?)\](?:\.\w+)?\.torrent$/)?.[1] ?? releaseGroupName?.value;
        }
    });


    const mangaFillRoot = root.querySelector("#manga_form > #autofill > dl.box.pad");
    if (!(mangaFillRoot instanceof HTMLDListElement)) return;

    if (GM_getValue("hideExistingAutofill", false) && mangaFillRoot?.children) for (const child of mangaFillRoot.children) child.style.display = "none";

    const mdex = addInput({
        root: mangaFillRoot,
        description: "MangaDex Autofill",
        inputOpts: [{ id: `mangadex-autofill-${type}` }],
        buttonNames: ["Autofill!", "Search"]
    });
    mdex.buttons[0].addEventListener("click", () => fillMdexData(mdex.inputs[0].value));
    /** @type {Record<string, (r: MdexManga) => string>} */
    const mdexGenerators = {
        getId: r => r.id ?? "",
        getTitle: r => r.attributes?.title?.['ja-ro'] || r.attributes?.title?.en || "",
        getCoverURL: r => `https://mangadex.org/covers/${r.id}/${r.relationships?.find(rel => rel.type === "cover_art")?.attributes?.fileName}.256.jpg`,
        getURL: r => `https://mangadex.org/title/${r.id}`
    };
    mdex.buttons[1].addEventListener("click", async () => searchMdex(mdex.inputs[0].value)
        .then(results => promptSearchResults("MangaDex Results", results, mdexGenerators)
            .then(id => { if (id) fillMdexData(id); })
        ));

    const mu = addInput({
        root: mangaFillRoot,
        description: "MangaUpdates Autofill",
        inputOpts: [{ id: `mangaupdates-autofill-${type}` }],
        buttonNames: ["Autofill!", "Search"]
    });
    mu.buttons[0].addEventListener("click", () => fillMUData(mu.inputs[0].value),);
    /** @type {Record<string, (r: MUSearchManga) => string|number|undefined>} */
    const muGenerators = {
        getId: r => r.series_id,
        getTitle: r => r.title,
        getURL: r => r.url,
        getCoverURL: r => r?.image?.url?.original,
    };
    mu.buttons[1].addEventListener("click", async () => searchMU(mu.inputs[0].value, type)
        .then(results => promptSearchResults("MangaUpdates Results", results, muGenerators))
        .then(id => { if (id) fillMUData(id); })
    );

    const mal = addInput({
        root: mangaFillRoot,
        description: "MyAnimeList Autofill",
        inputOpts: [{ id: `myanimelist-autofill-${type}` }],
        buttonNames: ["Autofill!", "Search"]
    });
    mal.buttons[0].addEventListener("click", () => fillMALData(mal.inputs[0].value));
    /** @type {Record<string, (r: MALSearchManga) => string|number|undefined>} */
    const malGenerators = {
        getId: r => r.id,
        getTitle: r => r.title,
        getURL: r => `https://myanimelist.net/manga/${r.id}`,
        getCoverURL: r => r?.main_picture?.medium,
    };
    mal.buttons[1].addEventListener("click", async () => searchMAL(mal.inputs[0].value)
        .then(results => promptSearchResults("MyAnimeList Results", results, malGenerators))
        .then(id => { if (id) fillMALData(id); })
    );
})();

// Light Novels
(async () => {
    const type = "light_novels";

    const root = document.querySelector("#light_novels");
    if (!(root instanceof HTMLDivElement)) return;

    root.querySelector("input#file_input_light_novels")?.addEventListener("change", (e) => {
        if (!(e.target instanceof HTMLInputElement && e.target.files)) return;
        const releaseGroupName = root.querySelector("input#release_group_name");
        const releaseGroupDiv = root.querySelector("div#release_group_light_novels");
        const translatedStatus = root.querySelector("input#scanlation");

        const name = e.target.files.item(0)?.name ?? "";

        if (
            /\[.*?\](\.\w+)?.torrent$/.test(name) &&
            releaseGroupName instanceof HTMLInputElement &&
            releaseGroupDiv instanceof HTMLDivElement &&
            translatedStatus instanceof HTMLInputElement
        ) {
            if (!GM_getValue("autofillScanlated", false)) return;
            translatedStatus.checked = true;
            releaseGroupDiv.style.display = "";
            releaseGroupName.value = name?.match(/\[(.*?)\](?:\.\w+)?\.torrent$/)?.[1] ?? releaseGroupName?.value;
        }
    });

    const lnFillRoot = root.querySelector("#light_novels_form > #autofill > dl.box.pad");
    if (!(lnFillRoot instanceof HTMLDListElement)) return;

    if (lnFillRoot?.children) for (const child of lnFillRoot.children) child.style.display = "none";

    const mu = addInput({
        root: lnFillRoot,
        description: "MangaUpdates Autofill",
        inputOpts: [{ id: `mangaupdates-autofill-${type}` }],
        buttonNames: ["Autofill!", "Search"]
    });
    mu.buttons[0].addEventListener("click", async () => getMUData(mu.inputs[0].value, "lightNovel").then(res => fillLNData(res)));
    /** @type {Record<string, (r: MUSearchManga) => string|number|undefined>} */
    const muGenerators = {
        getId: r => r.series_id,
        getTitle: r => r.title,
        getURL: r => r.url,
        getCoverURL: r => r?.image?.url?.original,
    };
    mu.buttons[1].addEventListener("click", async () => searchMU(mu.inputs[0].value, type)
        .then(results => promptSearchResults("MangaUpdates Results", results, muGenerators))
        .then(id => { if (id) fillMUData(id); })
    );

    const mal = addInput({
        root: lnFillRoot,
        description: "MyAnimeList Autofill",
        inputOpts: [{ id: `myanimelist-autofill-${type}` }],
        buttonNames: ["Autofill!", "Search"]
    });
    mal.buttons[0].addEventListener("click", async () => getMALData(mal.inputs[0].value, "lightNovel").then(res => fillLNData(res)));
    /** @type {Record<string, (r: MALSearchManga) => string|number|undefined>} */
    const malGenerators = {
        getId: r => r.id,
        getTitle: r => r.title,
        getURL: r => `https://myanimelist.net/manga/${r.id}`,
        getCoverURL: r => r?.main_picture?.medium,
    };
    mal.buttons[1].addEventListener("click", async () => searchMAL(mal.inputs[0].value)
        .then(results => promptSearchResults("MyAnimeList Results", results, malGenerators))
        .then(id => { if (id) fillMALData(id); })
    );
})();
