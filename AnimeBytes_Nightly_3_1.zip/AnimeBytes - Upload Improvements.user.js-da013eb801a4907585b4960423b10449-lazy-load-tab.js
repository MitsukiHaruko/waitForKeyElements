/**
 * @param {Object} opts
 * @param {string} opts.title
 * @param {string|URL} opts.url
 * @param {(url: string|URL) => WindowProxy|Tampermonkey.OpenTabObject|null} [opts.tabOpener]
 * @param {Record<string,any>} [opts.data]
 * @returns {WindowProxy|Tampermonkey.OpenTabObject|null}
 */
function lazyLoadTab({ title, url, tabOpener = window.open, data }) {
    const openerOrigin = location.origin;

    /**
     * @param {{title: string, url: string|URL, openerOrigin: string}} params
     * @param {Record<string, any>} [data]
     */
    const func = (params, data) => {
        window.addEventListener("focus", () => {
            if (data && window.opener) {
                window.opener.postMessage({ ...data, ...params, type: "lazyLoadTab:focused" }, params.openerOrigin);
            }
            window.location.href = String(params.url);
        }, { once: true });
    };

    const doc = document.implementation.createHTMLDocument();
    const meta = document.createElement("meta");
    meta.setAttribute("charset", "utf-8");
    doc.head.append(meta);
    doc.title = title;
    const script = doc.createElement("script");
    script.text = `(${func})(${JSON.stringify({ title, url, openerOrigin })}, ${data ? JSON.stringify(data) : ""});`;
    doc.body.append(script);

    const blobUrl = URL.createObjectURL(new Blob(["<!DOCTYPE html>\n" + doc.documentElement.outerHTML], { type: "text/html" }));
    const tab = tabOpener(blobUrl);
    if (tab && tab instanceof Window) tab.addEventListener("load", () => URL.revokeObjectURL(blobUrl), { once: true });
    return tab;
}
