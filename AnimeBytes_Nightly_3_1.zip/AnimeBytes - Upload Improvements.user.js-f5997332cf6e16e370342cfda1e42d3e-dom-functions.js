/**
 * @param {string} selector
 * @param {ParentNode} [root=document.body]
 * @returns {Promise<Element>}
 */
function waitElement(selector, root = document.body) {
  return new Promise((resolve) => {
    const el = root.querySelector(selector);
    if (el) {
      resolve(el);
      return;
    }

    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;

          if (node.matches(selector)) {
            observer.disconnect();
            resolve(node);
            return;
          }

          const el = node.querySelector(selector);
          if (el) {
            observer.disconnect();
            resolve(el);
            return;
          }
        }
      }
    });

    observer.observe(root, { childList: true, subtree: true });
  });
}
