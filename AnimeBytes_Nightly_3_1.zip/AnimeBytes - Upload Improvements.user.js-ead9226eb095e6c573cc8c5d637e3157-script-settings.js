if (typeof promptDialog !== "function") throw ("promptDialog must be imported");
if (typeof addInput !== "function") throw ("addInput must be imported");

/**
 * @typedef {Record<string, {label: string, default: any}>} ScriptConfig
 */

/**
 * @param {ScriptConfig} config
 */
async function manageSettings(config) {
    const settingsList = document.createElement("dl");
    settingsList.style.margin = "0";
    Object.assign(settingsList.style, {
        display: "grid",
        gridTemplateColumns: "max-content 1fr",
        gap: "1lh",
        alignItems: "center",
        margin: "0"
    });

    const elementsMap = new Map();

    for (const [key, { label, default: defaultValue }] of Object.entries(config)) {
        const currentValue = GM_getValue(key, defaultValue);
        const isArray = Array.isArray(defaultValue);
        const type = typeof defaultValue;

        let inputObj;

        if (isArray) {
            inputObj = addInput({ root: settingsList, description: label, inputOpts: [] });
            const textarea = Object.assign(document.createElement("textarea"), {
                value: currentValue.join("\n"),
                rows: 4,
                style: "width: 100%; box-sizing: border-box; resize: vertical; margin-top: 4px;"
            });
            inputObj.container.append(textarea);
            elementsMap.set(key, { el: textarea, type: "array" });
        } else {
            let inputType;
            switch (type) {
                case "boolean":
                    inputType = "checkbox";
                    break;
                case "number":
                    inputType = "number";
                    break;
                case "string":
                default:
                    inputType = "text";
            }

            inputObj = addInput({
                root: settingsList,
                description: label,
                inputOpts: [{ type: inputType }]
            });

            const input = inputObj.inputs[0];
            if (type === "boolean") {
                input.checked = currentValue;
            } else {
                input.value = currentValue;
                input.style.width = "100%";
            }
            elementsMap.set(key, { el: input, type });
        }
    }

    const { dialog, result } = promptDialog("Script Settings", settingsList);
    dialog.showModal();

    const action = await result;

    if (action === "ok") {
        for (const [key, { el, type }] of elementsMap) {
            let val;

            if (type === "array") {
                val = el.value.split("\n").map(s => s.trim()).filter(s => s !== "");
            } else if (type === "boolean") {
                val = el.checked;
            } else if (type === "number") {
                val = Number(el.value);
            } else {
                val = el.value;
            }

            GM_setValue(key, val);
        }
        console.log("Settings saved successfully.");
    }

    dialog.remove();
}
