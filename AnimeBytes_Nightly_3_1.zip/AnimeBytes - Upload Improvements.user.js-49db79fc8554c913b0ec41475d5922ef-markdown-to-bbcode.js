/**
 * @import {Token,TokensList,Tokens} from "marked"
 * */
const inlineTypes = new Set(["strong", "em", "del", "codespan", "link", "image", "br", "escape", "tag"]);

if (typeof marked?.lexer !== "function") {
    throw new Error("marked.js is required. Please load via @require https://cdn.jsdelivr.net/npm/marked");
}

const domParser = new DOMParser();

/** @param {string} html */
function stripHTML(html) {
    const doc = domParser.parseFromString(html, "text/html");
    return doc.body.textContent ?? "";
};

/**
 * @param {string|undefined} markdown
 * @returns {string}
 */
function markdownToBBCode(markdown) {
    if (!markdown) return "";
    if (typeof markdown !== "string") {
        throw new TypeError(`markdownToBBCode expected a string, got ${typeof markdown}`);
    }

    const tokens = marked.lexer(markdown.replace(/\r\n/g, "\n"));
    return renderBlocks(tokens).trim() + "\n";
}

/**
 * @param {Token[]} tokens
 * @returns {string}
 */
function renderBlocks(tokens) { return tokens.map(renderBlock).join(""); }

/**
 * @param {Token} token
 * @returns {string}
 */
function renderBlock(token) {
    switch (token.type) {
        case "heading":
            return `[h${token.depth}]${renderInline(token.tokens)}[/h${token.depth}]\n`;

        case "paragraph":
            return `${renderInline(token.tokens).trim()}\n\n`;

        case "list": {
            const tag = token.ordered ? "ol" : "ul";
            const items = token.items.map(renderListItem).join("");
            return `[${tag}]\n${items}[/${tag}]\n`;
        }

        case "blockquote":
            return `[quote]\n${renderBlocks(token.tokens).trim()}\n[/quote]\n`;

        case "code":
            return `[code]\n${token.text}\n[/code]\n`;

        case "table":
            return renderTable(token);

        case "hr":
            return "[hr]\n";

        case "html":
            return stripHTML(token.text).trim() + "\n";

        case "space":
            return "\n";

        default:
            if (inlineTypes.has(token.type)) return renderInlineToken(token);
            return token.tokens ? renderBlocks(token.tokens) : (token.text ?? "");
    }
}

/**
 * @param {Tokens.ListItem} token
 * @returns {string}
 */
function renderListItem(token) {
    const checkbox =
        token.checked === true ? "[x] " :
            token.checked === false ? "[ ] " : "";

    const inner = token.tokens
        ? renderBlocks(token.tokens).trim()
        : token.text ?? "";

    return `[li]${checkbox}${inner}[/li]\n`;
}

/** @param {Token[]} tokens */
function renderInline(tokens = []) {
    return tokens.map(renderInlineToken).join("");
}

/**
 * @param {Token} token
 * @returns {string}
 */
function renderInlineToken(token) {
    switch (token.type) {
        case "text":
            return token.tokens ? renderInline(token.tokens) : token.text;
        case "strong":
            return `[b]${renderInline(token.tokens)}[/b]`;
        case "em":
            return `[i]${renderInline(token.tokens)}[/i]`;
        case "del":
            return `[s]${renderInline(token.tokens)}[/s]`;
        case "codespan":
            return `[code]${token.text}[/code]`;
        case "link":
            return `[url=${token.href}]${renderInline(token.tokens)}[/url]`;
        case "image":
            return `[img]${token.href}[/img]`;
        case "br":
            return "\n";
        case "html":
        case "tag":
            return stripHTML(token.text);
        case "escape":
            return token.text;
        default:
            return token.tokens ? renderInline(token.tokens) : (token.text ?? "");
    }
}

/** @param {Tokens.Table} token */
function renderTable(token) {
    const parts = ["[table]\n"];

    parts.push("[tr]\n");
    for (const cell of token.header) {
        parts.push(`[th]${renderInline(cell.tokens).trim()}[/th]\n`);
    }
    parts.push("[/tr]\n");

    for (const row of token.rows) {
        parts.push("[tr]\n");
        for (const cell of row) {
            parts.push(`[td]${renderInline(cell.tokens).trim()}[/td]\n`);
        }
        parts.push("[/tr]\n");
    }

    parts.push("[/table]\n");

    return parts.join("");
}
