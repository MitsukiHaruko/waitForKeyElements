/**
 * @template T
 * @typedef  {Object} CacheRecord
 * @property {IDBValidKey} id
 * @property {T} value
 * @property {number} updatedAt
 */

/**
 * @param {string} name
 * @param {number} version
 * @param {(db: IDBDatabase, oldVersion: Number, event: IDBVersionChangeEvent) => void} upgradeCallback
 * @returns {Promise<IDBDatabase>}
 */
function openDB(name, version, upgradeCallback) {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(name, version);

        request.onupgradeneeded = (event) => {
            if (upgradeCallback) {
                upgradeCallback(request.result, event.oldVersion, event);
            }
        };

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
        request.onblocked = () => reject(new Error("Upgrade blocked by another open connection"));
    });
}

/**
 * @param {IDBDatabase} db
 * @param {string} storeName
 * @param {any} value
 * @param {IDBValidKey} key
 * @returns {Promise<any>}
 */
function setRecord(db, storeName, value, key) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, "readwrite");
        const request = tx.objectStore(storeName).put({ id: key, value, updatedAt: Date.now() });
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

/**
 * @template T
 * @param {IDBDatabase} db
 * @param {string} storeName
 * @param {IDBValidKey} key
 * @returns {Promise<CacheRecord<T> | undefined>}
 */
function getRecord(db, storeName, key) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, "readonly");
        const request = tx.objectStore(storeName).get(key);

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

/**
 * @param {IDBDatabase} db
 * @param {string} storeName
 * @param {string} indexName
 * @param {any} value
 * @returns {Promise<any>}
 */
function getByIndex(db, storeName, indexName, value) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, "readonly");
        const request = tx.objectStore(storeName).index(indexName).get(value);

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

/**
 * @param {IDBDatabase} db
 * @param {string} storeName
 * @returns {Promise<any[]>}
 */
function getAllRecords(db, storeName) {
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, "readonly");
        const request = tx.objectStore(storeName).getAll();

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}
