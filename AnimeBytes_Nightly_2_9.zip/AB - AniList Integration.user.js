// ==UserScript==
// @name AB - AniList Integration
// @author Mitsuki Haruko
// @namespace AnimeBytes Nightly
// @version 1.5
// @description Adds direct AniList link, next episode/chapter countdown, optional YouTube trailer embed, personal next-episodes homepage widget, AniList banner
// @grant GM_xmlhttpRequest
// @grant GM_getValue
// @grant GM_setValue
// @match https://animebytes.tv/torrents.php?id*
// @match https://animebytes.tv/
// @match *://animebytes.tv/user.php?action=edit*
// @icon https://animebytes.tv/favicon.ico
// @require https://github.com/momentary0/AB-Userscripts/raw/master/delicious-library/src/ab_delicious_library.js
// @run-at document-end
// ==/UserScript==

(function () {
    'use strict';

    const favicons = {
        "AniList": "https://mei.kuudere.pw/ncihtSl6Awu.png",
    };

    function normalizeLinkName(txt) {
        if (!txt) return null;
        const t = txt.toLowerCase().trim().replace(/[\s|•…‥.]+/g, '');
        if (t.includes('anilist')) return 'AniList';
        return null;
    }

    function replaceLinkWithIcon(a) {
        const text = a.textContent.trim();
        const key = normalizeLinkName(text);
        if (!key || !favicons[key]) return;
        const img = document.createElement('img');
        img.src = favicons[key];
        img.alt = text || key;
        img.title = text || key;
        img.style.cssText = `
            height: 2.15em;
            width: auto;
            vertical-align: middle;
            margin: 0 5px 1px 2px;
            border-radius: 4px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.25);
            transition: transform 0.13s ease;
        `;
        img.onmouseenter = () => { img.style.transform = 'scale(1.18)'; };
        img.onmouseleave = () => { img.style.transform = 'scale(1)'; };
        a.textContent = '';
        a.appendChild(img);
    }

    // SETTINGS
    if (delicious?.settings?.ensureSettingsInserted?.()) {
        const section = delicious.settings.createCollapsibleSection('Anilist Integration (Trailers, Watchlist, Banners)');
        const body = section.querySelector('.settings_section_body');

        delicious.settings.init('ABAniListEnableTrailers', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABAniListEnableTrailers',
            'Embed YouTube trailers',
            'Shows the official trailer (if available).'
        ));

        delicious.settings.init('ABAniListTrailerAtTop', false);
        body.appendChild(delicious.settings.createCheckbox(
            'ABAniListTrailerAtTop',
            'Trailer at the Top',
            'Inserts trailer at the very top of the main column (above torrents)'
        ));

        delicious.settings.init('ABAniListTrailerAutoplay', false);
        body.appendChild(delicious.settings.createCheckbox(
            'ABAniListTrailerAutoplay',
            'Autoplay trailer (muted)',
            'Trailer starts playing automatically when loaded without sound'
        ));

        delicious.settings.init('ABAniListEnableBanners', true);
        body.appendChild(delicious.settings.createCheckbox(
            'ABAniListEnableBanners',
            'Show AniList banners',
            'Displays the large AniList banner image at the top of the page (if available)'
        ));

        delicious.settings.insertSection(section);
    }

    const enableTrailers     = JSON.parse(GM_getValue('ABAniListEnableTrailers', 'true'));
    const trailerAtTop       = JSON.parse(GM_getValue('ABAniListTrailerAtTop', 'false'));
    const autoplayTrailer    = JSON.parse(GM_getValue('ABAniListTrailerAutoplay', 'false'));
    const enableBanners      = JSON.parse(GM_getValue('ABAniListEnableBanners', 'true'));   // ← new

    const bannerStyle = document.createElement('style');
    bannerStyle.textContent = `
        #ab-anilist-banner {
            width: 100%;
            height: 200px;
            background-size: cover;
            background-position: center 25%;
            background-repeat: no-repeat;
            position: relative;
            margin: 10px 0 18px 0;
            border-radius: 6px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.35);
            overflow: hidden;
            display: block;
        }
        #ab-anilist-banner::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.05), rgba(0,0,0,0.35));
            pointer-events: none;
        }
        @media (max-width: 1100px) {
            #ab-anilist-banner {
                height: 170px;
            }
        }
    `;
    document.head.appendChild(bannerStyle);

    function insertAniListBanner(bannerUrl) {
        if (!enableBanners) return;
        if (document.getElementById('ab-anilist-banner')) return;

        const banner = document.createElement('div');
        banner.id = 'ab-anilist-banner';
        banner.style.backgroundImage = `url(${bannerUrl})`;

        const thinDiv = document.querySelector('#content div.thin');
        if (thinDiv) {
            const h3 = thinDiv.querySelector('h3');
            const mainColumn = thinDiv.querySelector('.main_column');
            if (mainColumn) {
                mainColumn.insertBefore(banner, mainColumn.firstChild);
            } else if (h3) {
                thinDiv.insertBefore(banner, h3.nextSibling);
            } else {
                thinDiv.appendChild(banner);
            }
            return;
        }

        // Fallback
        const mainColumn = document.querySelector('#content .main_column');
        if (mainColumn) mainColumn.prepend(banner);
    }

    function formatTimeUntil(seconds, isAiring = false, mediaType = 'ANIME') {
        if (seconds == null || seconds < 0) return "<span class='countdown-prefix'>—</span>";
        const diff = seconds * 1000;
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const parts = [];
        if (d > 0) parts.push(`${d}d`);
        if (h > 0) parts.push(`${h}h`);
        if (m > 0 || parts.length === 0) parts.push(`${m}m`);
        const timeStr = parts.join(' ');
        const prefix = isAiring ? 'Airing in ' : (mediaType === 'ANIME' ? 'Next ep in ' : 'Next ch in ');
        return `<span class="countdown-prefix">${prefix}</span><span class="countdown-time">${timeStr}</span>`;
    }

    function getStoredList() {
        try { return JSON.parse(GM_getValue('AB_NextEp_WatchList', '[]')) || []; }
        catch { return []; }
    }

    function saveList(arr) {
        GM_setValue('AB_NextEp_WatchList', JSON.stringify(arr));
    }

    function getStatusBadge(status) {
        const badges = {
            FINISHED: { text: 'Finished', color: '#2196F3' },
            CANCELLED: { text: 'Cancelled', color: '#F44336' },
            HIATUS: { text: 'Hiatus', color: '#9C27B0' },
            NOT_YET_RELEASED: { text: 'Upcoming', color: '#FF9800' }
        };
        const style = badges[status] || { text: status || 'Unknown', color: '#757575' };
        return `<span class="status-badge" style="background:${style.color}; color:white; padding:2px 6px; border-radius:3px; font-size:0.85em; margin-left:8px;">${style.text}</span>`;
    }

    function handleDetailPage() {
        function findSeriesElements(callback) {
            const h2 = document.querySelector('#content div.thin h2');
            const h3 = document.querySelector('#content div.thin h3');
            if (h2 && h3) {
                callback(h2, h3);
                return true;
            }
            return false;
        }

        function runWhenReady() {
            if (findSeriesElements(startDetailScript)) return;
            let attempts = 0;
            const iv = setInterval(() => {
                attempts++;
                if (findSeriesElements(startDetailScript)) clearInterval(iv);
                else if (attempts > 60) clearInterval(iv);
            }, 50);
        }

        function startDetailScript(h2, h3) {
            let seriesTitle = '', typeText = '', releaseYear = null;
            const match = h2.innerHTML.match(/>(.*?)<\/a>\s*-\s*(.*?)\s*\[(\d{4})\]/);
            if (match) {
                seriesTitle = match[1].trim();
                typeText = match[2].trim();
                releaseYear = parseInt(match[3], 10);
            } else {
                seriesTitle = h2.querySelector('a')?.textContent.trim() || h2.textContent.trim();
                releaseYear = h2.textContent.match(/\[(\d{4})\]/)?.[1] ? parseInt(RegExp.$1, 10) : null;
            }

            let mediaType = 'ANIME';
            let format = null;
            const printed = ["Manga", "Oneshot", "Manhwa", "Manhua", "Light Novel", "Anthology"];
            const animeFmt = { 'TV':'TV', 'OVA':'OVA', 'Movie':'MOVIE', 'Special':'SPECIAL', 'ONA':'ONA' };

            if (printed.includes(typeText)) {
                mediaType = 'MANGA';
            } else if (typeText in animeFmt) {
                format = animeFmt[typeText];
            }

            let searchTitle = seriesTitle;
            let shortTitle = seriesTitle.split(':')[0].trim();

            if (mediaType === 'MANGA') {
                const stats = document.querySelector(".stats.nobullet");
                if (stats) {
                    const romaji = stats.innerHTML.match(/Romaji Title:<\/strong>\s*<br>\s*(.*?)\s*<\/li>/i)?.[1]?.trim();
                    if (romaji) {
                        searchTitle = romaji;
                        shortTitle = romaji.split(':')[0].trim();
                    }
                }
            }

            fetchAniListData(searchTitle, shortTitle, mediaType, releaseYear, format, h2, h3);
        }

        function fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry = 2, useShort = true) {
            const qTitle = useShort ? shortTitle : title;
            const clean = qTitle.replace(/\[.*?\]|\(.*?\)/g, '').replace(/[^a-zA-Z0-9\s:]/g, '').trim();

            const query = `
                query ($search: String, $type: MediaType, $format: MediaFormat) {
                    Page(perPage: 12) {
                        media(search: $search, type: $type, format: $format) {
                            id
                            title { romaji english native }
                            startDate { year }
                            format
                            status
                            bannerImage
                            nextAiringEpisode { airingAt timeUntilAiring episode }
                            trailer { id site thumbnail }
                        }
                    }
                }`;

            const variables = { search: clean, type: mediaType, ...(format && { format }) };

            GM_xmlhttpRequest({
                method: 'POST',
                url: 'https://graphql.anilist.co',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                data: JSON.stringify({ query, variables }),
                onload: res => {
                    if (res.status !== 200) {
                        if (retry > 0) return setTimeout(() => fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, useShort), 1000);
                        fallback(h3, shortTitle, mediaType);
                        return;
                    }

                    try {
                        const data = JSON.parse(res.responseText);
                        const list = data.data?.Page?.media || [];

                        if (list.length === 0) {
                            if (useShort && retry > 0) return fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, false);
                            fallback(h3, shortTitle, mediaType);
                            return;
                        }

                        let media = null;
                        if (year && format) media = list.find(m => m.startDate?.year === year && m.format === format);
                        if (!media && year) media = list.find(m => m.startDate?.year === year);
                        if (!media) media = list.find(m => m.status === 'RELEASING' || m.status === 'NOT_YET_RELEASED');
                        if (!media) media = list[0];

                        // Banner
                        if (media.bannerImage) {
                            insertAniListBanner(media.bannerImage);
                        }

                        // Airing info + add button
                        const status = media.status;
                        const na = media.nextAiringEpisode;
                        let airingText = '';
                        if (status === 'RELEASING' && na?.timeUntilAiring != null) {
                            airingText = formatTimeUntil(na.timeUntilAiring, false, mediaType);
                        } else if (status === 'NOT_YET_RELEASED' && na?.airingAt) {
                            const sec = na.airingAt - Math.floor(Date.now()/1000);
                            airingText = formatTimeUntil(sec, true, mediaType);
                        }

                        if (airingText && na?.timeUntilAiring > -86400) {
                            const span = document.createElement('span');
                            span.style.fontWeight = '900';
                            span.style.fontSize = '15px';
                            span.style.marginLeft = '8px';
                            span.innerHTML = ' | ' + airingText;

                            const currentList = getStoredList();
                            const alreadyAdded = currentList.some(item => item.id === media.id);

                            const btn = document.createElement('button');
                            btn.className = 'next-ep-add-btn';
                            btn.textContent = alreadyAdded ? '[✓]' : '[+]';
                            btn.style.marginLeft = '10px';
                            btn.style.fontSize = '13px';
                            btn.style.padding = '1px 6px';
                            btn.style.cursor = alreadyAdded ? 'default' : 'pointer';
                            btn.disabled = alreadyAdded;
                            btn.title = alreadyAdded ? 'Already added to homepage list' : 'Add to Next Episodes list (homepage)';
                            btn.onclick = () => {
                                if (alreadyAdded) return;
                                const list = getStoredList();
                                list.push({
                                    id: media.id,
                                    title: media.title.romaji || media.title.english || title,
                                    type: mediaType,
                                    added: Date.now()
                                });
                                saveList(list);
                                btn.textContent = '[✓]';
                                btn.disabled = true;
                                btn.style.cursor = 'default';
                                btn.title = 'Added to homepage list!';
                            };
                            span.appendChild(btn);
                            h2.appendChild(span);
                        }

                        if (media.id) appendAniListLink(media.id, h3, mediaType);

                        // Trailer
                        const tr = media.trailer;
                        if (enableTrailers && tr?.id && tr.site?.toLowerCase() === 'youtube') {
                            let params = `rel=0&modestbranding=1`;
                            if (autoplayTrailer) params += `&autoplay=1&mute=1`;
                            const src = `https://www.youtube-nocookie.com/embed/${tr.id}?${params}`;
                            embedTrailer(src, trailerAtTop);
                        }
                    } catch (e) {
                        console.error('AniList parse error:', e);
                        fallback(h3, shortTitle, mediaType);
                    }
                },
                onerror: () => {
                    if (retry > 0) setTimeout(() => fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, useShort), 1000);
                    else fallback(h3, shortTitle, mediaType);
                }
            });
        }

        runWhenReady();
    }

    function embedTrailer(src, atTop = false) {
        const trailerSection = document.createElement('div');
        trailerSection.className = 'box trailer-box';
        trailerSection.innerHTML = `
            <div class="head"><strong>Trailer</strong></div>
            <div class="body" style="padding: 0 12px 12px 12px;">
                <div style="position: relative; width: 100%; padding-bottom: 56.25%; height: 0">
                    <iframe
                        style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"
                        src="${src}"
                        title="Anime Trailer"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen
                        referrerpolicy="strict-origin-when-cross-origin">
                    </iframe>
                </div>
            </div>`;

        if (atTop) {
            const mainColumn = document.querySelector('#content .main_column');
            if (mainColumn) mainColumn.insertBefore(trailerSection, mainColumn.firstChild);
            return;
        }

        const collages = document.querySelector('#collages');
        if (collages) { collages.insertAdjacentElement('afterend', trailerSection); return; }

        const synopsisBox = $('.box > .head > strong:contains("Plot Synopsis")').closest('.box');
        if (synopsisBox.length) { synopsisBox.after(trailerSection); return; }

        const mainColumn = document.querySelector('#content .main_column');
        if (mainColumn) mainColumn.appendChild(trailerSection);
    }

    function handleHomePage() {
        if (!location.pathname.match(/^\/$/)) return;
        const fpright = document.querySelector('.fpright');
        if (!fpright || document.getElementById('ab-next-ep-widget')) return;

        const container = document.createElement('div');
        container.id = 'ab-next-ep-widget';
        container.style.marginBottom = '20px';
        container.innerHTML = `
            <div class="head"><strong>Watch List</strong></div>
            <div class="body" id="next-ep-list" style="padding:12px; font-size:0.94em;">
                Loading...
            </div>`;
        fpright.insertBefore(container, fpright.firstChild);
        renderNextEpList();
    }

    async function renderNextEpList() {
        const listEl = document.getElementById('next-ep-list');
        if (!listEl) return;

        const watchlist = getStoredList();
        if (!watchlist.length) {
            listEl.textContent = 'No shows tracked yet. Add with → [+]';
            return;
        }

        listEl.textContent = 'Updating...';
        const items = [];

        for (const entry of watchlist) {
            try {
                const data = await fetchAniListEntry(entry.id, entry.type);
                if (!data) continue;
                const na = data.nextAiringEpisode;
                items.push({
                    ...entry,
                    timeUntil: na?.timeUntilAiring ?? null,
                    episode: na?.episode ?? null,
                    title: data.title.romaji || data.title.english || entry.title,
                    status: data.status || 'UNKNOWN'
                });
            } catch {}
        }

        items.sort((a, b) => {
            if (a.timeUntil !== null && b.timeUntil !== null) return a.timeUntil - b.timeUntil;
            if (a.timeUntil !== null) return -1;
            if (b.timeUntil !== null) return 1;
            return b.added - a.added;
        });

        if (!items.length) {
            listEl.textContent = 'No data could be loaded. Try again later.';
            return;
        }

        const ul = document.createElement('ul');
        ul.style.listStyle = 'none';
        ul.style.padding = '0';
        ul.style.margin = '0';

        for (const it of items) {
            const li = document.createElement('li');
            li.className = 'next-ep-item';
            li.dataset.anilistId = it.id;

            const countdown = it.timeUntil !== null
                ? formatTimeUntil(it.timeUntil, false, it.type)
                : '<span class="countdown-prefix">No upcoming episode</span>';

            li.innerHTML = `
                <button class="next-ep-remove" title="Remove from list">×</button>
                <div class="next-ep-header">
                    <a href="https://anilist.co/${it.type.toLowerCase()}/${it.id}" target="_blank" class="next-ep-title">
                        ${it.title}
                    </a>
                    ${it.status !== 'RELEASING' ? getStatusBadge(it.status) : ''}
                    ${it.episode ? `<span class="ep-badge">Ep ${it.episode}</span>` : ''}
                </div>
                <div class="next-ep-countdown">
                    ${countdown}
                </div>
            `;

            li.querySelector('.next-ep-remove').onclick = () => {
                let currentList = getStoredList();
                currentList = currentList.filter(e => e.id !== it.id);
                saveList(currentList);
                li.remove();
                if (!ul.hasChildNodes()) {
                    listEl.textContent = 'No shows in your list.';
                }
            };

            ul.appendChild(li);
        }

        listEl.innerHTML = '';
        listEl.appendChild(ul);
    }

    function fetchAniListEntry(id, mediaType) {
        return new Promise(resolve => {
            const query = `
            query ($id: Int, $type: MediaType) {
                Media(id: $id, type: $type) {
                    id
                    title { romaji english }
                    status
                    nextAiringEpisode { airingAt timeUntilAiring episode }
                }
            }`;

            GM_xmlhttpRequest({
                method: 'POST',
                url: 'https://graphql.anilist.co',
                headers: { 'Content-Type': 'application/json' },
                data: JSON.stringify({ query, variables: { id, type: mediaType } }),
                onload: r => {
                    if (r.status !== 200) return resolve(null);
                    try {
                        const media = JSON.parse(r.responseText).data?.Media;
                        resolve(media || null);
                    } catch {
                        resolve(null);
                    }
                },
                onerror: () => resolve(null)
            });
        });
    }

    function appendAniListLink(id, h3, mediaType) {
        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createElement('span');
        sep.textContent = ' • ';
        sep.style.color = '#888';

        const a = document.createElement('a');
        a.href = `https://anilist.co/${mediaType.toLowerCase()}/${id}`;
        a.textContent = 'AniList';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        replaceLinkWithIcon(a);

        if (last) {
            insertAfter(sep, last);
            insertAfter(a, sep);
        } else {
            h3.appendChild(sep);
            h3.appendChild(a);
        }
    }

    function fallback(h3, shortTitle, mediaType) {
        const clean = encodeURIComponent(shortTitle.toLowerCase());
        const url = `https://anilist.co/search/${mediaType.toLowerCase()}?search=${clean}`;

        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createElement('span');
        sep.textContent = ' • ';
        sep.style.color = '#888';

        const a = document.createElement('a');
        a.href = url;
        a.textContent = 'AniList Search';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        replaceLinkWithIcon(a);

        if (last) {
            insertAfter(sep, last);
            insertAfter(a, sep);
        } else {
            h3.appendChild(sep);
            h3.appendChild(a);
        }
    }

    function insertAfter(newNode, refNode) {
        refNode?.parentNode?.insertBefore(newNode, refNode.nextSibling);
    }

    if (location.pathname.includes('/torrents.php')) {
        handleDetailPage();
    } else if (location.pathname === '/' || location.pathname === '') {
        handleHomePage();
    }

})();