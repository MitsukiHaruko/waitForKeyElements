// ==UserScript==
// @name         AB - Donation Goal
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.0
// @match        *://animebytes.tv/*
// @icon         https://animebytes.tv/favicon.ico
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    // Inject styles early and hide the donate button instantly
    GM_addStyle(`
        #nav_donate { display: none !important; }

        .ab-donation-container {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            background: rgba(0, 0, 0, 0);
            pointer-events: none;
            text-align: center;
        }

        .ab-donation-number {
            display: inline-block;
            height: 12px;
            line-height: 12px;
            background-color: #1d1d1d;
            border: 1px solid #676767;
            border-radius: 5px;
            margin-top: 5px;
            cursor: pointer;
            pointer-events: auto;
            color: #9e9e9e;
            font-family: Arial, sans-serif;
            font-size: clamp(8px, 2.5vw, 10px);
            text-align: center;
            transition: width 0.3s ease-in-out;
            white-space: nowrap;
            overflow: hidden;
        }
    `);

    const tryInsertNumber = () => {
        const donateLink = document.querySelector('#nav_donate a');
        if (!donateLink) return false;

        const match = donateLink.textContent.match(/\d+/);
        let progressPercent = match ? parseInt(match[0]) : 0;

        const container = document.createElement('div');
        container.className = 'ab-donation-container';

        const numberDisplay = document.createElement('div');
        numberDisplay.className = 'ab-donation-number';
        numberDisplay.textContent = `${progressPercent}%`;

        // Function to calculate and set width dynamically
        const setWidth = (percent) => {
            // Responsive min/max
            const maxWidth = Math.max(120, Math.min(window.innerWidth * 0.35, 500));
            const minWidth = Math.max(50, Math.min(window.innerWidth * 0.15, 60));
            const widthPx = maxWidth - ((maxWidth - minWidth) * percent / 100);
            numberDisplay.style.width = widthPx + 'px';
        };

        setWidth(progressPercent);

        container.appendChild(numberDisplay);

        numberDisplay.addEventListener('click', () => {
            window.location.href = donateLink.href;
        });

        document.body.insertBefore(container, document.body.firstChild);

        // Update loop
        setInterval(() => {
            const newPercent = parseInt(donateLink.textContent.match(/\d+/)?.[0] || 0);
            if (newPercent !== progressPercent) {
                progressPercent = newPercent;
                numberDisplay.textContent = `${progressPercent}%`;
                setWidth(progressPercent);
            }
        }, 1000);

        // Update on resize for responsiveness
        window.addEventListener('resize', () => setWidth(progressPercent));

        return true;
    };

    // Wait until DOM is ready, then insert number display
    const waitForBody = setInterval(() => {
        if (document.body) {
            clearInterval(waitForBody);
            const waitForDonate = setInterval(() => {
                if (tryInsertNumber()) clearInterval(waitForDonate);
            }, 100);
        }
    }, 10);
})();
