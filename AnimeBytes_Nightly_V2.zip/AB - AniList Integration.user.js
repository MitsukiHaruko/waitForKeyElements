// ==UserScript==
// @name         AB - AniList Integration
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.2.1
// @description  Adds direct AniList link, next episode/chapter countdown, and embeds a YouTube trailer after the synopsis box
// @grant        GM_xmlhttpRequest
// @match        https://animebytes.tv/torrents.php*
// @icon         http://animebytes.tv/favicon.ico
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    // ────────────────────────────────────────────────────────────────
    // Helpers (completely unchanged)
    // ────────────────────────────────────────────────────────────────
    function findSeriesElements(callback) {
        const h2 = document.querySelector('#content div.thin h2');
        const h3 = document.querySelector('#content div.thin h3');
        if (!h2 || !h3) return false;
        callback(h2, h3);
        return true;
    }

    function runWhenReady() {
        if (findSeriesElements(startScript)) return;
        let attempts = 0;
        const interval = setInterval(() => {
            attempts++;
            if (findSeriesElements(startScript)) {
                clearInterval(interval);
            } else if (attempts >= 40) {
                console.error('AniList: Failed to find H2/H3 after 2s');
                clearInterval(interval);
            }
        }, 50);
    }

    function insertAfter(newNode, refNode) {
        refNode?.parentNode?.insertBefore(newNode, refNode.nextSibling);
    }

    function formatTimeUntil(seconds, isAiring = false, mediaType) {
        const diff = seconds * 1000;
        const d = Math.floor(diff / 86400000);
        const h = Math.floor((diff % 86400000) / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const parts = [];
        if (d > 0) parts.push(`${d} day${d > 1 ? 's' : ''}`);
        if (h > 0) parts.push(`${h} hour${h > 1 ? 's' : ''}`);
        if (m > 0 || parts.length === 0) parts.push(`${m} minute${m !== 1 ? 's' : ''}`);
        const prefix = isAiring ? 'Airing in ' : (mediaType === 'ANIME' ? 'Next ep in ' : 'Next ch in ');
        return prefix + parts.join(' ');
    }

    // ────────────────────────────────────────────────────────────────
    // Core logic — only embedTrailer placement changed
    // ────────────────────────────────────────────────────────────────
    function startScript(h2Element, h3Element) {
        let seriesTitle = '', typeText = '', releaseYear = null;
        const match = h2Element.innerHTML.match(/>(.*?)<\/a>\s*-\s*(.*?)\s*\[(\d{4})\]/);
        if (match) {
            seriesTitle = match[1].trim();
            typeText = match[2].trim();
            releaseYear = parseInt(match[3], 10);
        } else {
            seriesTitle = h2Element.querySelector('a')?.textContent.trim() || h2Element.textContent.trim();
            releaseYear = h2Element.textContent.match(/\[(\d{4})\]/)?.[1] ? parseInt(RegExp.$1, 10) : null;
        }

        let mediaType = 'ANIME';
        let format = null;
        const printed = ["Manga", "Oneshot", "Manhwa", "Manhua", "Light Novel", "Anthology"];
        const animeFmt = { 'TV':'TV', 'OVA':'OVA', 'Movie':'MOVIE', 'Special':'SPECIAL', 'ONA':'ONA' };
        if (printed.includes(typeText)) {
            mediaType = 'MANGA';
        } else if (typeText in animeFmt) {
            format = animeFmt[typeText];
        }

        let searchTitle = seriesTitle;
        let shortTitle = seriesTitle.split(':')[0].trim();
        if (mediaType === 'MANGA') {
            const stats = document.querySelector(".stats.nobullet");
            if (stats) {
                const romaji = stats.innerHTML.match(/Romaji Title:<\/strong>\s*<br>\s*(.*?)\s*<\/li>/i)?.[1]?.trim();
                if (romaji) {
                    searchTitle = romaji;
                    shortTitle = romaji.split(':')[0].trim();
                }
            }
        }

        fetchAniListData(searchTitle, shortTitle, mediaType, releaseYear, format, h2Element, h3Element);
    }

    function fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry = 2, useShort = true) {
        const qTitle = useShort ? shortTitle : title;
        const clean = qTitle.replace(/\[.*?\]|\(.*?\)/g, '').replace(/[^a-zA-Z0-9\s:]/g, '').trim();

        const query = `
            query ($search: String, $type: MediaType, $format: MediaFormat) {
                Page(perPage: 15) {
                    media(search: $search, type: $type, format: $format) {
                        id
                        title { romaji english }
                        startDate { year }
                        format
                        status
                        nextAiringEpisode { airingAt timeUntilAiring episode }
                        trailer { id site thumbnail }
                    }
                }
            }`;

        const variables = { search: clean, type: mediaType, ...(format && { format }) };

        GM_xmlhttpRequest({
            method: 'POST',
            url: 'https://graphql.anilist.co',
            data: JSON.stringify({ query, variables }),
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            onload: res => {
                if (res.status !== 200) {
                    if (retry > 0) return setTimeout(() => fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, useShort), 1000);
                    fallback(h3, shortTitle, mediaType);
                    appendAiring('', h2);
                    return;
                }
                try {
                    const data = JSON.parse(res.responseText);
                    const list = data.data?.Page?.media || [];
                    if (list.length === 0) {
                        if (useShort && retry > 0) return fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, false);
                        fallback(h3, shortTitle, mediaType);
                        appendAiring('', h2);
                        return;
                    }
                    let media = null;
                    if (year && format) media = list.find(m => m.startDate?.year === year && m.format === format);
                    if (!media && year) media = list.find(m => m.startDate?.year === year);
                    if (!media) media = list.find(m => m.status === 'RELEASING' || m.status === 'NOT_YET_RELEASED');
                    if (!media) media = list[0];

                    const status = media.status;
                    const na = media.nextAiringEpisode;
                    let airingText = '';
                    if (status === 'RELEASING' && na?.timeUntilAiring != null) {
                        airingText = formatTimeUntil(na.timeUntilAiring, false, mediaType);
                    } else if (status === 'NOT_YET_RELEASED' && na?.airingAt) {
                        const sec = na.airingAt - Math.floor(Date.now()/1000);
                        airingText = formatTimeUntil(sec, true, mediaType);
                    }
                    if (airingText) appendAiring(airingText, h2);
                    appendAniListLink(media.id, h3, mediaType);

                    const tr = media.trailer;
                    if (tr?.id && tr.site?.toLowerCase() === 'youtube') {
                        embedTrailer(`https://www.youtube-nocookie.com/embed/${tr.id}?rel=0&autoplay=0&modestbranding=1`);
                    }
                } catch (e) {
                    console.error('AniList parse error:', e);
                    fallback(h3, shortTitle, mediaType);
                    appendAiring('', h2);
                }
            },
            onerror: () => {
                if (retry > 0) setTimeout(() => fetchAniListData(title, shortTitle, mediaType, year, format, h2, h3, retry-1, useShort), 1000);
                else {
                    fallback(h3, shortTitle, mediaType);
                    appendAiring('', h2);
                }
            }
        });
    }

   function embedTrailer(src) {
    const synopsis = $('.box > .head > strong:contains("Plot Synopsis")').parent().parent();
    if (!synopsis.length) {
        console.warn('Could not find synopsis box — trailer not embedded');
        return;
    }

    const trailerSection = document.createElement('div');
    trailerSection.className = 'box trailer-box';

trailerSection.innerHTML = `
    <div class="head"><strong>Trailer</strong></div>
    <div class="body" style="padding: 0 12px 12px 12px;">
        <div style="position: relative; width: 100%; padding-bottom: 56.25%; height: 0">
            <iframe
                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"
                src="${src}"
                title="Anime Trailer"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
                referrerpolicy="strict-origin-when-cross-origin">
            </iframe>
        </div>
    </div>`;

    synopsis.after(trailerSection);
}

    function appendAiring(text, h2) {
        if (!text) return;
        const span = document.createElement('span');
        span.textContent = ' | ' + text;
        span.style.fontWeight = '900';
        span.style.fontSize = '15px';
        h2.appendChild(span);
    }

    function appendAniListLink(id, h3, mediaType) {
        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createTextNode(' | ');
        const a = document.createElement('a');
        a.href = `https://anilist.co/${mediaType.toLowerCase()}/${id}`;
        a.textContent = 'AniList';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        if (last) {
            insertAfter(sep, last);
            insertAfter(a, sep);
        } else {
            h3.appendChild(sep);
            h3.appendChild(a);
        }
    }

    function fallback(h3, shortTitle, mediaType) {
        const clean = encodeURIComponent(shortTitle.toLowerCase());
        const url = `https://anilist.co/search/${mediaType.toLowerCase()}?search=${clean}`;
        const last = [...h3.querySelectorAll('a')].pop();
        const sep = document.createTextNode(' | ');
        const a = document.createElement('a');
        a.href = url;
        a.textContent = 'AniList Search';
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        if (last) {
            insertAfter(sep, last);
            insertAfter(a, sep);
        } else {
            h3.appendChild(sep);
            h3.appendChild(a);
        }
    }

    runWhenReady();
})();