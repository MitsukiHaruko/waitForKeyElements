// ==UserScript==
// @name         AB - Auto Focus Search Bar
// @namespace    AnimeBytes Nightly
// @version      1.0
// @description  Automatically focuses the search bar (input.quicksearch.series_search) on AnimeBytes home page
// @author       TalkingJello
// @match        *://animebytes.tv/*
// @icon         http://animebytes.tv/favicon.ico
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    function focusSearchBar() {
        // Only run on home page
        if (window.location.pathname !== '/') return;

        const selectors = [
            'input.quicksearch.series_search',
            '#series_name_anime',
            'input[name="seriesname"]'
        ];

        let retries = 0;
        const maxRetries = 50; // 5 seconds (50 * 100ms)

        const attemptFocus = () => {
            let searchInput = null;
            for (const selector of selectors) {
                searchInput = document.querySelector(selector);
                if (searchInput) break;
            }

            if (searchInput) {
                searchInput.focus();
                console.log(`Focused search bar using selector: ${searchInput.tagName}${searchInput.id ? '#' + searchInput.id : ''}${searchInput.className ? '.' + searchInput.className : ''}`);
            } else if (retries < maxRetries) {
                retries++;
                console.warn(`Search bar not found (retry ${retries}/${maxRetries}), trying again...`);
                setTimeout(attemptFocus, 100);
            } else {
                console.error('Failed to find search bar after max retries');
            }
        };

        // Set up mutation observer to detect search bar addition
        const observer = new MutationObserver(() => {
            let searchInput = null;
            for (const selector of selectors) {
                searchInput = document.querySelector(selector);
                if (searchInput) {
                    searchInput.focus();
                    console.log(`MutationObserver: Focused search bar using selector: ${selector}`);
                    observer.disconnect();
                    return;
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Initial attempt after a slight delay to account for themes script
        setTimeout(attemptFocus, 100);

        // Stop observer after 5 seconds if not found
        setTimeout(() => {
            observer.disconnect();
            console.log('Stopped MutationObserver for search bar');
        }, 5000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', focusSearchBar);
    } else {
        focusSearchBar();
    }
})();