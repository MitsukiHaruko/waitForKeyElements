// ==UserScript==
// @name AB - Filelist Improvements
// @namespace AnimeBytes Nightly
// @author WeebDataHoarder
// @version 1.2.3
// @description AnimeBytes Filelist Improvements. Adds full folder path, exact file sizes, fixes path names eating spaces, adds piece information. MIT license
// @match https://animebytes.tv/torrents.php?*id=*
// @match https://animebytes.tv/torrents2.php?*id=*
// @exclude https://animebytes.tv/torrents*groupid=*
// @icon https://mei.kuudere.pw/jEBHMictkaa.png
// @grant GM_addStyle
// @require deps/compat.js?1
// @require deps/bdecode.js?2
// @run-at document-end
// ==/UserScript==

let handledTorrentIds = {};

const eventHandler = (e) => {
    const tabs = e.target.closest("div.tabs");
    if (tabs === null) return;

    const fileListElement = tabs.querySelector("div[id$='_filelist']");
    if (fileListElement === null) return;

    try {
        const torrentId = parseInt(
            fileListElement.id.match(/^(?<torrentId>[0-9]+)_filelist$/).groups.torrentId
        );

        if (torrentId in handledTorrentIds) return;
        handledTorrentIds[torrentId] = true;

        let folderElement = document.getElementById("filelist_" + torrentId + "_foldername");
        if (folderElement !== null) return;

        const downloadLink = document.querySelector(
            "tr.group_torrent a[href^='/torrent/" + torrentId + "/download/']"
        );

        fetch(new URL(downloadLink.getAttribute("href"), window.location.href).toString(), {
            method: "GET",
            mode: "same-origin",
            credentials: "omit"
        }).then(response =>
            response.arrayBuffer().then(buffer => {
                if (!response.ok) return;
                try {
                    const value = bdecode(new Uint8Array(buffer));
                    if (!("info" in value) || !("name" in value.info)) return;

                    const baseName = value.info.name;
                    const pieceSize = value.info["piece length"] || 0;
                    const pieceCount = value.info.pieces
                        ? value.info.pieces.length / 20
                        : 0;

                    let fileList = {};
                    if ("files" in value.info) {
                        value.info.files.forEach((entry, index) => {
                            const path = entry.path.slice(0, -1).join("/");
                            const name = entry.path.slice(-1)[0];
                            const matchPath = entry.path.join("/").replace(/[ \t\r\n]/g, "");
                            fileList[(path ? path + "/" : "") + name] = {
                                index,
                                path,
                                name,
                                match: matchPath,
                                length: entry.length
                            };
                        });
                    } else {
                        fileList[baseName] = {
                            index: 0,
                            path: "",
                            name: baseName,
                            match: baseName.replace(/[ \t\r\n]/g, ""),
                            length: value.info.length || 0
                        };
                    }

                    const fileCount = Object.keys(fileList).length;
                    const fileListTable = document.getElementById("filelist_" + torrentId);
                    const pieceInformation = document.createElement("p");

                    // Only show Root Folder if there are multiple files
                    if ("files" in value.info && value.info.files.length > 1) {
                        pieceInformation.append("Root Folder: " + baseName);
                        pieceInformation.append(document.createElement("br"));
                    }

                    pieceInformation.append("Piece Count: " + pieceCount.toLocaleString());
                    pieceInformation.append(document.createElement("br"));
                    pieceInformation.append(
                        "Piece Size: " +
                        ((b) => {
                            let i = ~~(Math.log2(b) / 10);
                            return (
                                (b / Math.pow(1024, i)).toFixed(2) +
                                " " +
                                ("KMGTPEZY"[i - 1] || "") +
                                "iB"
                            );
                        })(pieceSize)
                    );

                    if (fileCount > 1) {
                        pieceInformation.append(document.createElement("br"));
                        pieceInformation.append("File Count: " + fileCount.toLocaleString());
                    }

                    if ("__hash" in value.info) {
                        value.info.__hash.then(result => {
                            pieceInformation.append(document.createElement("br"));
                            pieceInformation.append(
                                "Info Hash: " +
                                Array.prototype.map
                                    .call(new Uint8Array(result), n =>
                                        n.toString(16).padStart(2, "0")
                                    )
                                    .join("")
                            );
                        });
                    }

                    fileListTable.insertAdjacentElement("beforebegin", pieceInformation);

                    fileListTable.querySelectorAll("tr").forEach(tableRow => {
                        const pathElement = tableRow.querySelector("td");
                        if (tableRow.querySelector("td > strong")) return;

                        const formattedSizeElement = tableRow.querySelector("td:last-of-type");
                        const matchPath = pathElement.textContent.replace(/[ \t\r\n]/g, "");
                        let size = "";
                        let path = "";
                        let name = pathElement.textContent;

                        for (let [key, entry] of Object.entries(fileList)) {
                            if (entry.match === matchPath) {
                                path = entry.path;
                                name = entry.name;
                                size = entry.length.toLocaleString() + " bytes";
                                delete fileList[key];
                                break;
                            }
                        }

                        while (pathElement.firstChild) {
                            pathElement.firstChild.remove();
                        }

                        let pre = document.createElement("span");
                        pre.textContent = (path ? path + "/" : "") + name;
                        pathElement.append(pre);

                        if (size) {
                            formattedSizeElement.setAttribute("title", size);
                        }
                    });

                    for (let [key, entry] of Object.entries(fileList)) {
                        console.log("Unmatched file list for #" + torrentId + ": " + key);
                        console.log(entry);
                    }

                } catch (e) {
                    console.log(e);
                }
            })
        ).catch(() => {});

    } catch (e) {
        console.log(e);
    }
};

document.querySelectorAll("a[href$='filelist']").forEach(e => {
    const match = e.getAttribute("href").match(/^#(?<torrentId>[0-9]+)[_\/]filelist$/);
    if (!match) return;

    const torrentId = parseInt(match.groups.torrentId);
    if (window.location.hash === "#" + torrentId + "/filelist") {
        eventHandler({ target: e });
    } else {
        e.addEventListener("click", eventHandler, { once: true, capture: true });
        e.addEventListener("mouseover", eventHandler, { once: true, capture: true });
    }
});
