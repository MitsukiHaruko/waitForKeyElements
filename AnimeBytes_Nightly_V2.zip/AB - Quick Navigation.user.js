// ==UserScript==
// @name        AB - Quick Navigation
// @author      Perilune
// @version     1.0
// @namespace   AnimeBytes Nightly
// @match       https://animebytes.tv/series.php*
// @match       https://animebytes.tv/artist.php*
// @icon        https://animebytes.tv/favicon.ico
// @grant       GM_addStyle
// ==/UserScript==


GM_addStyle(`
.category_title {
  font-weight: bold;
  color: inherit;
}

.quick_nav > ul {
  padding: 10px;
}
.quick_nav > ul > li:not(:last-child) {
  margin-bottom: 10px;
}
.quick_nav > ul > li > ul {
  margin-left: 0 !important;
}
`);


async function getDocument(url) {
    const response = await fetch(url);
    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    return doc;
}


function getNextPage(doc) {
    const newPage = Array.from(doc.querySelectorAll("a.next-prev:not(.last):not(.first)")).slice(-1)[0];
    if (newPage.textContent.includes("→")) {
        return newPage.href;
    }
}


function getData(ulCategories, doc = document, createNewCategories = true) {
    const categories = doc.querySelectorAll(".torrent_table");

    categories.forEach(table => {
        var liCategory;
        var ulGroup;
        var a = table.querySelector("strong > a");

        const liCategories = document.getElementsByName(a.textContent);
        if (!createNewCategories && liCategories.length > 0) {
            liCategory = liCategories[0];
            ulGroup = liCategory.querySelector("ul");
        } else {
            liCategory = doc.createElement("li");
            liCategory.setAttribute("name", a.textContent);
            var liTitle = doc.createElement("a");
            liTitle.textContent = a.textContent;
            liTitle.href = a.href;  // Not a full URL
            liTitle.className = "category_title";
            liCategory.append(liTitle);
            ulGroup = doc.createElement("ul");
        }

        var groups = table.querySelectorAll(".group");

        groups.forEach(group => {
            var liGroup = doc.createElement("li");
            liGroup.innerHTML = group.querySelector("h3").innerHTML;
            ulGroup.append(liGroup);
        })

        liCategory.append(ulGroup);
        ulCategories.append(liCategory);
    })

    if (!createNewCategories) {
        return getNextPage(doc);
    }
}


function createBox() {
    const box = document.createElement("div");
    box.className = "box quick_nav";
    const head = document.createElement("div");
    head.className = "head";
    const title = document.createElement("strong");
    title.textContent = "Quick Navigation";
    head.append(title);
    const ulCategories = document.createElement("ul");
    box.append(head, ulCategories);

    if (document.querySelector(".sidebar > div:nth-child(1) > div > p")) {
        document.querySelector(".sidebar > div:nth-child(1)").insertAdjacentElement("afterend", box);
    } else {
        document.querySelector(".sidebar").prepend(box);
    }

    return ulCategories;
}


async function main() {
    const ulCategories = createBox();

    if (!document.querySelector(".pagenums")) {
        getData(ulCategories);
    } else {
        const url = new URL(window.location.href);
        const params = new URLSearchParams(url.search);
        params.has('page') ? params.set('page', '1') : params.append('page', '1');
        url.search = params.toString();
        var nextPage = url.toString();

        do {
            const doc = await getDocument(nextPage);
            nextPage = getData(ulCategories, doc, false);
        } while (nextPage);
    }
}


main();