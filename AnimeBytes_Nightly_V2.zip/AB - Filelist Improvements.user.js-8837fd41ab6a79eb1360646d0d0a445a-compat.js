/**
 * General UserScript cross-compatibility functions
 */

if(typeof GM_addStyle !== 'function'){
    window.GM_addStyle = (css) => {
        const style = document.getElementById("GM_addStyle") || (() => {
            const style = document.createElement('style');
            style.type = 'text/css';
            style.id = "GM_addStyle";
            document.head.appendChild(style);
            return style;
        })();
        const sheet = style.sheet;
        sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
    }
}

if(typeof GM_getValue !== 'function'){
    window.GM_getValue = (name, defaultValue) => {
        let v = window.localStorage.getItem("__mediainfo_userscript_" + name);
        return v !== null ? JSON.parse(v) : defaultValue;
    }
}
if(typeof GM_setValue !== 'function'){
    window.GM_setValue = (name, value) => {
        window.localStorage.setItem("__mediainfo_userscript_" + name, JSON.stringify(value));
    }
}