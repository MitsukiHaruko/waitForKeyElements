// ==UserScript==
// @name         AB - YouTube Embed Fixer
// @namespace    AnimeBytes Nightly
// @version      0.1
// @description  Fix all YouTube embeds on PTP and others, modified from Audionut's
// @match        https://aither.cc/*
// @grant        none
// @run-at       document-end
// @icon         https://ptpimg.me/0u76po.png
// ==/UserScript==

(function() {
    'use strict';

    // Clean a YouTube embed URL: convert to nocookie and keep safe params
    function cleanYouTubeEmbed(url) {
        try {
            const u = new URL(url);
            const parts = u.pathname.split('/');
            const videoId = parts.pop() || parts.pop();
            if (!videoId) return null;

            let newUrl = `https://www.youtube-nocookie.com/embed/${videoId}`;

            // Only keep safe parameters
            const safe = ["autoplay", "start", "rel", "controls"];
            const kept = [];
            for (const p of safe) {
                if (u.searchParams.has(p)) {
                    kept.push(`${p}=${u.searchParams.get(p)}`);
                }
            }
            if (kept.length > 0) {
                newUrl += "?" + kept.join("&");
            }

            return newUrl;
        } catch (e) {
            console.warn("Invalid YouTube URL:", url, e);
            return null;
        }
    }



    // Try to override PTP's restrictive referrer policy for YouTube
    function injectReferrerPolicyOverride() {
        // Check if we already injected our meta tag
        if (document.querySelector('meta[name="referrer"][data-youtube-override]')) {
            return;
        }

        // Try to inject a more permissive referrer policy specifically for YouTube
        const metaTag = document.createElement('meta');
        metaTag.name = 'referrer';
        metaTag.content = 'strict-origin-when-cross-origin';
        metaTag.setAttribute('data-youtube-override', 'true');

        // Try to add it to head (may be blocked by CSP)
        try {
            document.head.appendChild(metaTag);
            console.log("PTP YouTube Embed Fixer: Injected referrer policy override");
        } catch (e) {
            console.warn("PTP YouTube Embed Fixer: Could not inject referrer policy:", e);
        }
    }

    // Fix YouTube iframe embeds with site-specific workarounds
    function fixAllEmbeds() {
        // Attempt to override referrer policy
        injectReferrerPolicyOverride();

        // Only target original YouTube iframes, not already converted nocookie ones
        const iframes = document.querySelectorAll("iframe[src*='youtube.com/embed']:not([src*='youtube-nocookie.com'])");
        iframes.forEach((iframe) => {
            const newSrc = cleanYouTubeEmbed(iframe.src);
            if (newSrc && iframe.src !== newSrc) {
                console.log("PTP YouTube Embed Fixer:", iframe.src, "→", newSrc);
                iframe.src = newSrc;
            }
        });

        // Apply workarounds for all YouTube iframes
        const allYouTubeIframes = document.querySelectorAll("iframe[src*='youtube.com/embed'], iframe[src*='youtube-nocookie.com/embed']");
        allYouTubeIframes.forEach((iframe) => {
            // Check current document referrer policy
            const docPolicy = document.referrerPolicy || document.querySelector('meta[name="referrer"]')?.content;
            console.log("Document referrer policy:", docPolicy);

            // Try different approaches to ensure referrer reaches YouTube
            // 1. Set explicit referrer policy on iframe (may override document policy)
            iframe.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');

            // 2. Add origin parameter to URL (YouTube fallback method)
            const currentSrc = iframe.src;
            const url = new URL(currentSrc);
            if (!url.searchParams.has('origin')) {
                // Use a fake origin that YouTube might accept better
                const fakeOrigin = 'https://www.youtube.com';
                url.searchParams.set('origin', fakeOrigin);
                iframe.src = url.toString();
                console.log("Added fake origin parameter:", url.toString());
            }

            // 3. Add additional YouTube-specific parameters
            if (!url.searchParams.has('enablejsapi')) {
                url.searchParams.set('enablejsapi', '1');
            }
            if (!url.searchParams.has('widgetid')) {
                url.searchParams.set('widgetid', Math.floor(Math.random() * 1000000));
            }

            // Update src if we added new parameters
            const finalUrl = url.toString();
            if (iframe.src !== finalUrl) {
                iframe.src = finalUrl;
                console.log("Updated with additional parameters:", finalUrl);
            }

            // 4. Ensure standard iframe attributes
            iframe.setAttribute('allowfullscreen', '');
            iframe.setAttribute('frameborder', '0');

            // 5. Comprehensive allow policy for YouTube features
            iframe.setAttribute('allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');

            // 6. Add sandbox permissions (may help with referrer policy)
            iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-presentation allow-forms');
        });
    }

    // Initial fix on page load
    fixAllEmbeds();

    // Observe for new dynamically added YouTube iframes
    const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
            if (m.type === 'childList' && m.addedNodes.length > 0) {
                fixAllEmbeds();
            } else if (m.type === 'attributes' && m.attributeName === 'src') {
                fixAllEmbeds();
            }
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src"]
    });

})();