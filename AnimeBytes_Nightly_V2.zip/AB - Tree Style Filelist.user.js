// ==UserScript==
// @name        AB - Tree Style Filelist
// @namespace   AnimeBytes Nightly
// @version     1.0
// @author      neesrod
// @description Changes filelist to be in tree style, heavily inspired by U2's filelist and based on WeebDataHoarder's "Filelist Improvements"
// @match       https://animebytes.tv/torrents.php?*id=*
// @match       https://animebytes.tv/torrents2.php?*id=*
// @exclude     https://animebytes.tv/torrents*groupid=*
// @icon        https://animebytes.tv/favicon.ico
// @grant       none
// @run-at      document-end
// ==/UserScript==

// locale, changes the number style, i.e.:
//
//   "us" - 1,056.12
//   "xh" - 1 056.12
//   "rm" - 1'056.12
//   "ee" -  1056.12
//   "pt" - 1.056,12
//   "fr" - 1 056,12
//   "et" -  1056,12
//
let locale   = "xh" // I prefer the space on xh's
var id_count = 6001 // this is used for unique ids, page-wide

function size_in_bytes(text) {
    // obviously rounded, turns "1,056.12 MiB" into 1107296256
    // split "1,056.12 MiB" into ["1,056.12", "MiB"], remove comma, parse as float, and multiply with unit conversion
    var size = parseFloat(text.split(" ")[0].replace(",", ""))
    var unit = text.split(" ")[1]

    switch (unit) {
        case "B":
            return size

        case "KiB":
            return size * 1024

        case "MiB":
            return size * 1024 ** 2

        case "GiB":
            return size * 1024 ** 3

        case "TiB":
            return size * 1024 ** 4
    }

    return -1
}

function bytes_to_text(size) {
    // turns 1107296256 into "1 056.12 MiB"
    var value = 0

    // due to reasons, multiply by 100 to save the first two decimals, then divide by 100 to put them back
    switch (true) {
        case (size >= 1024 ** 4):
            value = Math.round((size * 100) / (1024 ** 4)) / 100
            return value.toLocaleString(locale) + " TiB"

        case (size >= 1024 ** 3):
            value = Math.round((size * 100) / (1024 ** 3)) / 100
            return value.toLocaleString(locale) + " GiB"

        case (size >= 1024 ** 2):
            value = Math.round((size * 100) / (1024 ** 2)) / 100
            return value.toLocaleString(locale) + " MiB"

        case (size >= 1024):
            value = Math.round((size * 100) / 1024) / 100
            return value.toLocaleString(locale) + " KiB"

        case (size < 1024):
            return size.toLocaleString(locale) + " B"
    }

    return -1
}

function toggle_expand(start_id, end_id) {
    var toggle = document.getElementById("filetree_toggle_" + start_id)

    for (var i = start_id; i < end_id; i++) {
        var folder = document.getElementById("filetree_" + i)

        if (folder.getAttribute("filetree_status") === toggle.getAttribute("filetree_status")) {
            folder.children[0].onclick()
        }
    }

    if (toggle.getAttribute("filetree_status") === "closed") {
        toggle.setAttribute("filetree_status", "opened")
        toggle.textContent = "[-]"
    } else {
        toggle.setAttribute("filetree_status", "closed")
        toggle.textContent = "[+]"
    }
}

function toggle_folder(children, id) {
    var row = document.getElementById("filetree_" + id)

    // toggles parent's status
    if (row.getAttribute("filetree_status") === "closed") {
        row.setAttribute("filetree_status", "opened")
    } else {
        row.setAttribute("filetree_status", "closed")
    }

    // goes through the children and clicks the opened ones to toggle too, this is recursive
    for (var i = 0; i < children.length; i++) {
        var child_row = document.getElementById("filetree_" + children[i])

        if (child_row.getAttribute("filetree_status") === "opened") {
            child_row.children[0].onclick()
        }

        child_row.style.display = (child_row.style.display == "table-row" ? "none" : "table-row");
    }
}

// obviously, to make a global function just inject it into a script element
let global_function       = document.createElement('script')
global_function.innerHTML = toggle_folder.toString() + "\n" + toggle_expand.toString(); // I had no clue you could do this shit, JS is a hell of a drug
document.head.appendChild(global_function)

function create_folder_recursive(folder, folders, table) {
    // this creates a row, fills the name and size, adds an onclick and tag, then recurses to create the children
    var row  = document.createElement("tr")
    var name = document.createElement("td")
    var size = document.createElement("td")
    var data = folders[folder]

    row.setAttribute("id", "filetree_" + data.id)
    row.style.display = "none"

    if (!(data.folders.length + data.files.length)) {
        // no children, not a folder
        name.innerHTML = "<code style='font-family: monospace; font-size: 1.2em'>" + data.name + "</code>"
        size.innerHTML = "<span style='opacity: 100%'>" + bytes_to_text(data.size) + "</span>"

        row.appendChild(name)
        row.appendChild(size)
        table.appendChild(row)

        return;
    } else {
        // it's a folder
        row.setAttribute("filetree_status", "closed")
        name.setAttribute("onclick", "toggle_folder([" + data.folders + (data.folders.length ? "," : "") + data.files + "], " + data.id + ")")

        name.innerHTML = "<code style='font-family: monospace; font-size: 1.2em; font-weight: bold'>" + data.name + "</code>"
        size.innerHTML = "<span style='opacity: 60%'>[" + bytes_to_text(data.size) + "]</span>"

        row.appendChild(name)
        row.appendChild(size)
        table.appendChild(row)

        // loop through children folders, then the children files
        data.folders.concat(data.files).forEach(child => {
            create_folder_recursive(folders["."][child], folders, table)
        })
    }
}

// table nodes whose id start with "filelist", such as "filelist_990556"
document.querySelectorAll("table[id^='filelist']").forEach( (el) => {
    var rows              = Array.from(el.getElementsByTagName("tr"));
    var folders           = { ".": {} }                       // dot stores the inverse, instead of names to ids, it's ids to names
    var top_level         = { "folders" : [], "files" : [] }  // first stores top folders, second stores top files, just for aesthetic sorting

    // this adds the file count onto the title
    var title             = rows[0].children[0]
    var num_files         = document.createElement("span")
    num_files.style.float = "right"
    num_files.textContent = (rows.length - 1) + " File" + ((rows.length - 1) === 1 ? "" : "s")
    title.appendChild(num_files)

    // this adds an expand/collapse button, the JS is added after the rows loop
    title                 = rows[0].children[1]
    num_files             = document.createElement("span")
    num_files.style.float = "right"
    num_files.textContent = "[+]"
    num_files.style.fontSize = "1.2em"
    num_files.style.fontFamily = "monospace"
    num_files.setAttribute("filetree_status", "closed")
    title.appendChild(num_files)

    // exclude title row, parses the rows, creates the tree data, and removes the original
    rows.slice(1).forEach(row => {
        // first column, filename
        var filename  = row.children[0].textContent               // i.e. "BDMV/STREAM/00005.m2ts"
        // second column, size
        var size_text = row.children[1].textContent               // i.e. "1,056.12 MiB"

        var pathlist  = filename.split("/")                       // i.e. ["BDMV", "STREAM", "00005.m2ts"]
        var level     = pathlist.length - 1
        var file      = pathlist.slice(level).join("/")           // file, i.e. 00005.m2ts
        var fname     = "&nbsp;&nbsp;&nbsp;".repeat(level) + file // "&nbsp;"" is a space that won't get ignored, this makes "   00005.m2ts"

        // for loop for each level below to add the file size
        // if folder doesn't exist, create it and add id to parent
        // else simply add the size
        var parent = 0 // used to track the parent of the folder
        for (let p = 1; p < pathlist.length; p++) {
            // this will loop through all levels below, i.e. "BDMV" then "BDMV/STREAM" then "BDMV/STREAM/..."
            var folder = pathlist.slice(0, p).join("/")
            var name   = "&nbsp;&nbsp;&nbsp;".repeat(p - 1) + pathlist.slice(p-1, p).join("/")

            if (!(folder in folders)) {
                // doesn't exist yet
                id_count += 1

                // separation between children files and folders is to properly sort them, just more visually appealing
                folders[folder]        = { "id": id_count, "size": size_in_bytes(size_text), "name": name, "folders": [], "files": [] }
                folders["."][id_count] = folder

                // parent doesn't exist? then it's a root folder
                if (parent) {
                    folders[parent].folders.push(id_count)
                } else {
                    top_level.folders.push(id_count)
                }
            } else {
                folders[folder].size += size_in_bytes(size_text)
            }

            parent = folder
        }

        // create current file, same as a folder
        id_count += 1
        folders[filename]      = { "id": id_count, "size": size_in_bytes(size_text), "name": fname, "folders": [], "files": [] }
        folders["."][id_count] = filename

        // parent doesn't exist? then it's a root file
        if (parent) {
            folders[parent].files.push(id_count)
        } else {
            top_level.files.push(id_count)
        }

        row.remove()
    });

    // adds expand toggle's logic, or removes the toggle if there aren't folders
    if (top_level.folders.length) {
        num_files.setAttribute("id", "filetree_toggle_" + top_level.folders[0])
        num_files.setAttribute("onclick", "toggle_expand(" + top_level.folders[0] + "," + id_count + ")")
    } else {
        num_files.remove()
    }

    // create the top folders, all others are built recursively, then the top files
    top_level.folders.concat(top_level.files).forEach(folder_id => {
        create_folder_recursive(folders["."][folder_id], folders, rows[0].parentElement)
        document.getElementById("filetree_" + folder_id).style.display = "table-row"
    })

});