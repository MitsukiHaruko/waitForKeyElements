// ==UserScript==
// @name         AB - Comment Section Modal
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.4
// @description  Comment Modal
// @match        *://animebytes.tv/torrents*
// @icon         http://animebytes.tv/favicon.ico
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
    let isInitialized = false;

    function initCollapsibleComments() {
        if (isInitialized) return;

        const commentsSection = document.getElementById('torrent_comments');
        if (!commentsSection) return;

        const sidebar = document.querySelector('.sidebar');
        if (!sidebar) return;

        const toggleButton = createToggleButton();
        sidebar.appendChild(toggleButton);

        const modal = document.createElement('div');
        modal.classList.add('comments-modal');
        modal.style.cssText = `
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%;
            max-width: 1200px;
            height: 80vh;
            padding: 20px;
            overflow-y: auto;
            z-index: 1001;
        `;

        const styleSheet = document.createElement('style');
        styleSheet.textContent = `
            .comments-modal::-webkit-scrollbar { width: 12px; }
            .comments-modal::-webkit-scrollbar-track { background: transparent; }
            .comments-modal::-webkit-scrollbar-thumb:hover { background-color: #1d1d1d; }
            .comments-modal textarea:focus { outline: none; border: none; }
            .comments-modal img.avatar { height: 100px; object-fit: contain; }
            .comments-modal li.center { display: none; }
        `;
        document.head.appendChild(styleSheet);

        const closeButton = document.createElement('button');
        closeButton.textContent = 'Close';
        closeButton.style.cssText = `position: absolute; top: 10px; right: 10px; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer; z-index: 1002;`;

        const overlay = document.createElement('div');
        overlay.classList.add('modal-overlay');
        overlay.style.cssText = `display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); z-index: 1000;`;

        const modalContent = document.createElement('div');
        modalContent.style.position = 'relative';
        modalContent.appendChild(closeButton);
        modalContent.appendChild(commentsSection);
        modal.appendChild(modalContent);

        document.body.appendChild(overlay);
        document.body.appendChild(modal);

        // Smooth wheel scrolling
        const SCROLL_SPEED_MULTIPLIER = 3;
        window.addEventListener('wheel', (e) => {
            if (modal.style.display === 'block') {
                e.preventDefault();
                modal.scrollBy({
                    top: e.deltaY * SCROLL_SPEED_MULTIPLIER,
                    left: e.deltaX * SCROLL_SPEED_MULTIPLIER,
                    behavior: 'smooth'
                });
            }
        }, { passive: false });

        window.ABCommentsModal = modal;
        window.ABCommentsModalForceFocus = () => modal.style.display === 'block' ? modal : null;

        // === Quick reply handling ===
        const bbcodeToolbar = modal.querySelector('#bbcode');
        const quickpost = modal.querySelector('#quickpost');

        const scrollToBottom = () => {
            modal.scrollTo({
                top: modal.scrollHeight,
                behavior: 'smooth'
            });
        };

        // Textarea → show toolbar + scroll
        if (bbcodeToolbar && quickpost) {
            bbcodeToolbar.style.display = 'none';
            const showToolbarAndScroll = () => {
                if (bbcodeToolbar.style.display === 'none') bbcodeToolbar.style.display = '';
                scrollToBottom();
            };
            quickpost.addEventListener('focus', showToolbarAndScroll);
            quickpost.addEventListener('input', showToolbarAndScroll);

            const originalShowModal = showModal;
            showModal = function() {
                originalShowModal();
                bbcodeToolbar.style.display = 'none';
            };
        }

        // Pagination scroll reset
        localStorage.removeItem('commentsModalScrollPosition');
        document.querySelectorAll('a.page_link').forEach(link => {
            link.addEventListener('click', () => localStorage.removeItem('commentsModalScrollPosition'));
        });

        // Restore modal state
        const isModalOpen = localStorage.getItem('commentsModalOpen') === 'true';
        if (isModalOpen) showModal();

        modal.addEventListener('scroll', () => {
            localStorage.setItem('commentsModalScrollPosition', modal.scrollTop);
        });

        toggleButton.addEventListener('click', () => {
            modal.style.display === 'block' ? hideModal() : showModal();
        });

        closeButton.addEventListener('click', hideModal);
        overlay.addEventListener('click', hideModal);

        function showModal() {
            modal.style.display = 'block';
            overlay.style.display = 'block';
            toggleButton.textContent = 'Hide Comments';
            localStorage.setItem('commentsModalOpen', 'true');
            const saved = localStorage.getItem('commentsModalScrollPosition');
            modal.scrollTop = saved ? parseInt(saved, 10) : 0;
        }

        function hideModal() {
            modal.style.display = 'none';
            overlay.style.display = 'none';
            toggleButton.textContent = 'Show Comments';
            localStorage.setItem('commentsModalOpen', 'false');
        }

        window.addEventListener('beforeunload', () => {
            if (localStorage.getItem('commentsModalOpen') === 'true') {
                localStorage.setItem('pageScrollPosition', window.scrollY);
            }
        });

        document.body.style.height = 'auto';
        document.body.style.overflowX = 'auto';

        isInitialized = true;
    }

    function createToggleButton() {
        const b = document.createElement('button');
        b.textContent = 'Show Comments';
        b.classList.add('comments-toggle');
        b.style.cssText = `margin-bottom: 10px; cursor: pointer; padding: 5px 10px; border-radius: 10px; display: block; margin-left: auto; margin-right: auto;`;
        return b;
    }

    initCollapsibleComments();

    const observer = new MutationObserver(() => {
        if (!isInitialized) initCollapsibleComments();
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();