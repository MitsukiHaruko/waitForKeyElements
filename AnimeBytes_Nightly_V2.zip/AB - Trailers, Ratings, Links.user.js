// ==UserScript==
// @name          AB - Trailers, Ratings, Links
// @namespace     AnimeBytes Nightly
// @description   currently disabled
// @icon          http://animebytes.tv/favicon.ico
// @match         *://animebytes.tv/torrents.php?*
// @match         *://animebytes.tv/user.php?action=edit*
// ==/UserScript==