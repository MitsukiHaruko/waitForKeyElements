// ==UserScript==
// @name        AB - Read More
// @author      Perilune
// @version     0.1
// @namespace   https://github.com/soranosita
// @match       https://animebytes.tv/torrents.php*
// @match       https://animebytes.tv/torrents2.php*
// @icon        https://animebytes.tv/favicon.ico
// ==/UserScript==


async function getFullDescription(url) {
  const response = await fetch(url);
  const html = await response.text();
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const target = doc.evaluate("//strong[text()='Plot Synopsis' or text()='Torrent info']", doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

  return target.parentElement.nextElementSibling.innerHTML;
}


async function expandDescription(description, torrentLink) {
  const fullDescription = await getFullDescription(torrentLink);
  description.innerHTML = fullDescription;
}


async function main() {
  const descriptions = document.querySelectorAll(".torrent_desc");

  for (const description of descriptions) {
    if (description.textContent.endsWith("...")) {
      const torrentLink = description.parentElement.parentElement.querySelector(".group_img > span > a").href;
      const readAllLink = document.createElement("a");
      description.innerHTML += " ";
      readAllLink.textContent = "Read all";
      readAllLink.href = "javascript:void(0);";
      readAllLink.addEventListener("click", () => expandDescription(description, torrentLink));
      description.append(readAllLink);
    }
  }
}


main();
