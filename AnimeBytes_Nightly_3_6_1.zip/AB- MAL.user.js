// ==UserScript==
// @name         AB- MAL
// @match        https://myanimelist.net/*
// @match        https://animebytes.tv/*
// @run-at       document-end
// @version      1.0.10
// @author       notmarek (adapted)
// @updateURL    https://gist.github.com/.../AnimeBytesMAL.user.js
// @downloadURL  https://gist.github.com/.../AnimeBytesMAL.user.js
// @icon         https://anilistbytes.notmarek.com/AB.svg
// @require      https://cdn.jsdelivr.net/combine/npm/@violentmonkey/dom@2,npm/@violentmonkey/ui@0.7
// @require      https://raw.githubusercontent.com/momentary0/AB-Userscripts/b1e7aac27e1f49391147cf068326f278bb40e20d/delicious-library/src/ab_delicious_library.js
// @description  Adds AnimeBytes link to MyAnimeList external links
// @grant        GM.getValue
// @grant        GM.setValue
// @grant        GM.xmlHttpRequest
// ==/UserScript==

(function () {
    'use strict';

    let passkey = null;
    let username = null;
    let requestCache = new Map();

    console.log('[AnimeBytesMAL] Script initialized on:', location.href);

    if (unsafeWindow.location.href.includes('animebytes.tv')) {
        animebytesSetup();
    } else {
        mal();
    }

    async function animebytesSetup() {
        passkey = await GM.getValue('passkey', null);
        username = await GM.getValue('username', null);

        if (typeof delicious !== 'undefined' && delicious?.settings) {
            try {
                if (delicious.settings.ensureSettingsInserted?.()) {
                    const section = delicious.settings.createCollapsibleSection('MAL');
                    const body = section.querySelector('.settings_section_body');

                    const passkeyInput = document.createElement('input');
                    passkeyInput.type = 'text';
                    passkeyInput.value = passkey ? '••••••••••••••••••••' : '';
                    passkeyInput.readOnly = true;
                    passkeyInput.style.width = '50%';
                    passkeyInput.style.marginBottom = '8px';
                    passkeyInput.style.backgroundColor = '#2a2a2a';

                    const passkeyLabel = document.createElement('div');
                    passkeyLabel.innerHTML = '<strong>Passkey</strong><br><small>From your RSS feed</small>';
                    body.appendChild(passkeyLabel);
                    body.appendChild(passkeyInput);

                    const usernameInput = document.createElement('input');
                    usernameInput.type = 'text';
                    usernameInput.value = username || '';
                    usernameInput.readOnly = true;
                    usernameInput.style.width = '50%';
                    usernameInput.style.backgroundColor = '#2a2a2a';

                    const usernameLabel = document.createElement('div');
                    usernameLabel.innerHTML = '<strong>Username</strong>';
                    body.appendChild(usernameLabel);
                    body.appendChild(usernameInput);

                    const actionBtn = document.createElement('button');
                    actionBtn.className = 'ab-mal-settings-btn';
                    actionBtn.style.cssText = `display: block; margin: 0.5em 0px;`;

                    const updateButtonState = () => {
                        actionBtn.textContent = (passkey && username) ? 'Clear Settings' : 'Auto-detect & Save';
                    };

                    actionBtn.addEventListener('click', async () => {
                        if (passkey && username) {
                            await GM.setValue('passkey', null);
                            await GM.setValue('username', null);
                            passkey = null;
                            username = null;
                            passkeyInput.value = '';
                            usernameInput.value = '';
                            alert('Settings cleared.');
                        } else {
                            const rssLink = document.querySelector("link[type='application/rss+xml']");
                            const detectedPass = rssLink?.href.match(/rss_torrents_all\/(.+)/)?.[1];
                            const detectedUser = document.querySelector('.username')?.innerText?.trim();

                            if (detectedPass && detectedUser) {
                                await GM.setValue('passkey', detectedPass);
                                await GM.setValue('username', detectedUser);
                                passkey = detectedPass;
                                username = detectedUser;
                                passkeyInput.value = '••••••••••••••••••••';
                                usernameInput.value = detectedUser;
                                alert('Passkey and username saved!');
                            } else {
                                alert('❌ Failed to detect passkey or username.');
                            }
                        }
                        updateButtonState();
                    });

                    body.appendChild(actionBtn);
                    updateButtonState();
                    delicious.settings.insertSection(section);
                }
            } catch (e) {
                console.error('[AnimeBytesMAL] Delicious error:', e);
            }
        }
    }

    async function mal() {
        passkey = await GM.getValue('passkey', null);
        username = await GM.getValue('username', null);

        if (!passkey || !username) {
            console.log('[AnimeBytesMAL] Missing credentials');
            return;
        }

        const GM_get = async (url) => {
            if (requestCache.has(url)) return { json: async () => requestCache.get(url) };
            return new Promise((resolve, reject) => {
                GM.xmlHttpRequest({
                    method: 'GET',
                    url: url,
                    headers: { Accept: 'application/json' },
                    onload: r => {
                        try {
                            const data = JSON.parse(r.responseText);
                            requestCache.set(url, data);
                            resolve({ json: async () => data });
                        } catch (e) { reject(e); }
                    },
                    onerror: reject
                });
            });
        };

        const addAnimeBytesLink = async () => {

            if (document.querySelector('a[href*="animebytes.tv/torrents.php?id="]')) {
                return;
            }

            try {
                const path = unsafeWindow.location.pathname;
                const malIdMatch = path.match(/\/(anime|manga)\/(\d+)/);
                if (!malIdMatch) return;

                const malId = malIdMatch[2];
                const titleEl = document.querySelector('h1.title-name strong') || document.querySelector('h1.title-name');
                const title = titleEl?.innerText?.trim();
                if (!title) return;

                const endpoint = `https://animebytes.tv/scrape.php?torrent_pass=${passkey}&username=${username}&hentai=2&type=anime&searchstr=${encodeURIComponent(title)}`;

                const res = await GM_get(endpoint);
                const data = await res.json();
                const groups = data.Groups || [];

                let bestGroup = groups.find(g => g.Links?.MAL?.includes(`/${malId}`));
                if (!bestGroup) bestGroup = groups[0];
                if (!bestGroup) return;

                const abUrl = `https://animebytes.tv/torrents.php?id=${bestGroup.ID}`;

                const abLink = VM.h("a", {
                    class: "link ga-click",
                    href: abUrl,
                    target: "_blank",
                    "data-ga-click-type": "external-links-anime-pc-animebytes"
                },
                                    VM.h("img", {
                    src: "https://i.imgur.com/3utusmg.png",
                    style: "vertical-align: middle; margin-right: 10px; width: 16px; height: 16px; border-radius: 0 !important;"
                }),
                                    "AnimeBytes"
                                   );

                const linkContainer = VM.h("div", { class: "js-links" }, abLink);

                const externalLinksContainer = document.querySelector('.external_links');
                if (externalLinksContainer) {
                    const firstChild = externalLinksContainer.querySelector('.js-links') || externalLinksContainer.firstElementChild;
                    if (firstChild) {
                        externalLinksContainer.insertBefore(VM.m(linkContainer), firstChild);
                    } else {
                        externalLinksContainer.appendChild(VM.m(linkContainer));
                    }
                    console.log('[AnimeBytesMAL] ✅ AnimeBytes link added');
                }
            } catch (e) {
                console.error('[AnimeBytesMAL] Error:', e);
            }
        };

        // Single reliable trigger with delay
        setTimeout(addAnimeBytesLink, 1000);

        // MutationObserver for navigation
        let lastUrl = location.href;
        new MutationObserver(() => {
            if (location.href !== lastUrl) {
                lastUrl = location.href;
                setTimeout(addAnimeBytesLink, 1200);
            }
        }).observe(document.body, { childList: true, subtree: true });
    }
})();