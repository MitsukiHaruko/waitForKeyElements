// ==UserScript==
// @name                    AnimeBytes - Upload Improvements
// @namespace               https://animebytes.tv/
// @version                 0.9.12
// @description             Improve upload form
// @author                  pine
// @match                   https://animebytes.tv/upload.php
// @match                   https://animebytes.tv/upload.php?type=anime&groupid=*
// @icon                    https://animebytes.tv/favicon.ico
// @require                 https://cdn.jsdelivr.net/npm/marked@18.0.3/lib/marked.umd.js#sha256=8fe6e9d26d01533807fdb8d7d081a4de43bb3909f7ba15ac69606f5e11891599
// @resource MangaUpdates   https://www.mangaupdates.com/images/manga-updates.svg
// @resource MyAnimeList    https://myanimelist.net/images/favicon.svg
// @resource MangaDex       https://mangadex.org/favicon.svg
// @grant                   GM.xmlHttpRequest
// @grant                   GM.getResourceUrl
// @grant                   GM_getValue
// @grant                   GM_setValue
// @connect                 mangadex.org
// @connect                 api.mangaupdates.com
// @connect                 cdn.mangaupdates.com
// @connect                 myanimelist.net
// @top-level-await
// @updateURL               https://git.gammaspectra.live/pine/userscripts/raw/branch/main/src/ab-upload/meta.js
// @downloadURL             https://git.gammaspectra.live/pine/userscripts/raw/branch/main/ab_upload.user.js
// ==/UserScript==

// lib-ts/consts.ts
var path = window.location.pathname;
var selectors = Object.freeze({
  torrentEntry: "tr.group_torrent",
  entryCheckbox: "input[type='checkbox']",
  torrentUrl: `a[href^="${path}?id="][href*="&torrentid="]`,
  torrentInfo: "td:nth-child(2) > a,span:nth-child(2)",
  deletionForm: "form:has(input[value='Delete'])",
  deletionUrl: `a[href^='${path}?action=delete&torrentid=']`,
  reportUrl: "a[href^='/reports.php'][href*='&type=torrent&thingid=']"
});
var domParser = new DOMParser();

// lib-ts/dom-functions.ts
function waitElement({ selector, root = document.body, timeout = 3e4, attributes = false }) {
  const scopedSelector = selector.startsWith(":scope ") ? selector : `:scope ${selector}`;
  return new Promise((resolve, reject) => {
    const el = root.querySelector(scopedSelector);
    if (el) return resolve(el);
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches(selector)) {
            disconnect();
            return resolve(node);
          }
          if (node.childElementCount) {
            const child = node.querySelector(selector);
            if (child) {
              disconnect();
              return resolve(child);
            }
          }
        }
      }
    });
    const timer = setTimeout(() => {
      disconnect();
      reject(new Error(`Timeout of ${timeout}ms exceeded for "${selector}"`));
    }, timeout);
    const disconnect = () => {
      observer.disconnect();
      clearTimeout(timer);
    };
    observer.observe(root, { childList: true, subtree: true, attributes });
  });
}

// lib-ts/inputs.ts
function promptDialog(message, element) {
  const { promise: result, resolve: resolveResult } = Promise.withResolvers();
  const dialog = document.createElement("dialog");
  dialog.classList.add("box", "pad");
  Object.assign(dialog.style, {
    minWidth: "min(25vw, 480px)",
    maxWidth: "60vw",
    color: "inherit",
    margin: "auto"
  });
  const form = Object.assign(document.createElement("form"), { method: "dialog" });
  form.style = "display: flex; flex-direction: column; gap: 12px";
  const heading = document.createElement("h3");
  heading.textContent = message;
  heading.style = "text-align: center; color: inherit";
  const cont = document.createElement("div");
  cont.append(element);
  const actions = document.createElement("div");
  actions.style = "display: flex; justify-content: flex-end; gap: 8px";
  const cancelBtn = Object.assign(document.createElement("button"), {
    className: "btn",
    value: "cancel",
    textContent: "Cancel",
    formNoValidate: true
  });
  const okBtn = Object.assign(document.createElement("button"), {
    className: "btn",
    value: "ok",
    textContent: "OK"
  });
  actions.append(cancelBtn, okBtn);
  form.append(heading, cont, actions);
  dialog.append(form);
  document.body.append(dialog);
  dialog.addEventListener("close", () => {
    resolveResult(dialog.returnValue);
    dialog.remove();
  }, { once: true });
  return { dialog, result, okBtn, cancelBtn };
}
async function promptSelect(message, options) {
  const select = document.createElement("select");
  select.style = "display: block; margin: 0 auto";
  for (const [k, v] of Object.entries(options)) {
    if (!v.length) continue;
    const optgroup = Object.assign(document.createElement("optgroup"), { label: k });
    for (const o of v) optgroup.append(new Option(o, o));
    select.append(optgroup);
  }
  if (!select.options.length) return "";
  select.selectedIndex = -1;
  select.autofocus = true;
  const { dialog, result } = promptDialog(message, select);
  dialog.showModal();
  const returnValue = await result;
  dialog.remove();
  return returnValue === "ok" ? select.value : "";
}
function addInput({ root, afterEl, titleOpts = {}, inputDef = {}, buttonDef = {} }) {
  const title = Object.assign(document.createElement("dt"), titleOpts);
  const inputs = Object.fromEntries(
    // @ts-expect-error
    Object.entries(inputDef).map(
      ([name4, opts]) => {
        if (opts.type === "textarea") {
          delete opts.type;
          return [name4, Object.assign(document.createElement("textarea"), { size: 50, ...opts })];
        } else
          return [name4, Object.assign(document.createElement("input"), { type: "text", size: 50, ...opts })];
      }
    )
  );
  const buttons = Object.fromEntries(
    Object.entries(buttonDef).map(([name4, opts]) => [name4, Object.assign(document.createElement("button"), { type: "button", textContent: name4, className: "btn", ...opts })])
  );
  const dd = document.createElement("dd");
  const container = document.createElement("div");
  container.style = "display: flex; column-gap: 0.5em;";
  container.append(...Object.values(inputs), ...Object.values(buttons));
  dd.append(container);
  if (afterEl && root.contains(afterEl)) {
    afterEl.after(title, dd);
  } else {
    root.append(title, dd);
  }
  return { title, inputs, buttons, container };
}

// lib-ts/settings/script-settings.ts
function initSettings({ config, container, titleStyle, inputStyle }) {
  Object.assign(container.style, {
    display: "grid",
    gridTemplateColumns: "max-content max-content",
    gap: "1lh",
    justifyContent: "center"
  });
  const style = document.createElement("style");
  style.textContent = `
    @scope {
        :scope > dt { ${titleStyle} }
        :scope > dd { ${inputStyle} }
    }
`;
  container.prepend(style);
  const elementMap = /* @__PURE__ */ new Map();
  for (const [key, { label, default: defaultValue }] of Object.entries(config)) {
    const currentValue = GM_getValue(key, defaultValue);
    const type = typeof defaultValue;
    if (Array.isArray(defaultValue)) {
      const { inputs } = addInput({
        root: container,
        titleOpts: { textContent: label },
        inputDef: {
          input: {
            type: "textarea",
            value: currentValue.join("\n"),
            rows: 4,
            placeholder: "One entry per line",
            style: "min-width: 300px; min-height: 60px; box-sizing: border-box; margin-top: 4px;"
          }
        }
      });
      elementMap.set(key, { el: inputs.input, inputType: "array" });
    } else if (typeof defaultValue === "string" && /\r?\n/.test(defaultValue)) {
      const { inputs } = addInput({
        root: container,
        titleOpts: { textContent: label },
        inputDef: {
          input: {
            type: "textarea",
            value: currentValue,
            rows: 4,
            style: "min-width: 300px; min-height: 60px; box-sizing: border-box; margin-top: 4px;"
          }
        }
      });
      elementMap.set(key, { el: inputs.input, inputType: "textarea" });
    } else {
      let inputType;
      switch (type) {
        case "boolean":
          inputType = "checkbox";
          break;
        case "number":
          inputType = "number";
          break;
        case "string":
          inputType = config[key]["sensitive"] ? "password" : "text";
          break;
        default:
          inputType = "text";
      }
      const { inputs } = addInput({
        root: container,
        titleOpts: { textContent: label },
        inputDef: { input: { type: inputType } }
      });
      const input = inputs.input;
      switch (inputType) {
        case "checkbox":
          input.checked = currentValue;
          break;
        case "number":
        case "text":
        case "password":
        default:
          input.value = currentValue;
      }
      elementMap.set(key, { el: input, inputType });
    }
  }
  return { elementMap };
}
function applySettings(elementMap) {
  for (const [key, { el, inputType }] of elementMap) {
    let val;
    if (inputType === "array")
      val = el.value.split("\n").map((s) => s.trim()).filter((s) => s !== "");
    else if (inputType === "checkbox")
      val = el.checked;
    else if (inputType === "number")
      val = Number(el.value);
    else
      val = el.value;
    GM_setValue(key, val);
  }
  console.log("Settings saved successfully.");
}
function getSetting(config, name4) {
  if (!Object.keys(config).includes(name4)) throw new Error(`${name4} is not in config`);
  return GM_getValue(name4, config[name4].default);
}
async function promptSettings(config) {
  const settingsList = document.createElement("dl");
  const { elementMap } = initSettings({ config, container: settingsList });
  const { dialog, result } = promptDialog("Script Settings", settingsList);
  dialog.showModal();
  const action = await result;
  if (action === "ok") applySettings(elementMap);
  dialog.remove();
}

// lib-ts/lazy-load-tab.ts
var focusListener = ({ title, url, data }) => {
  window.addEventListener("focus", () => {
    if (data && window.opener)
      window.opener.postMessage({ title, url, data, type: "lazyLoadTab:focused" }, window.location.origin);
    window.location.href = String(url);
  }, { once: true });
};
function lazyLoadTab({ title, url, tabOpener, data }) {
  tabOpener ??= window.open;
  const doc = document.implementation.createHTMLDocument();
  const meta = document.createElement("meta");
  meta.setAttribute("charset", "utf-8");
  doc.head.append(meta);
  doc.title = title;
  const script = doc.createElement("script");
  script.text = `(${focusListener})(${JSON.stringify({ title, url, data })});`;
  doc.body.append(script);
  const blobUrl = URL.createObjectURL(new Blob(["<!DOCTYPE html>\n" + doc.documentElement.outerHTML], { type: "text/html" }));
  const tab = tabOpener(blobUrl);
  if (tab instanceof Window) tab.addEventListener("load", () => URL.revokeObjectURL(blobUrl), { once: true });
  return tab;
}
function closeAllTabs(tabs) {
  while (tabs.length) {
    try {
      tabs.pop()?.close();
    } catch {
    }
  }
}

// lib-ts/utils.ts
function stringToInstant(dateStr, timeZone = "UTC") {
  if (!dateStr) return null;
  try {
    return Temporal.Instant.from(dateStr);
  } catch {
  }
  try {
    return Temporal.PlainDateTime.from(dateStr).toZonedDateTime(timeZone).toInstant();
  } catch {
  }
  const forceUtcDate = /* @__PURE__ */ new Date(`${dateStr} UTC`);
  if (!isNaN(forceUtcDate.getTime())) {
    const plainDateTime = Temporal.PlainDateTime.from({
      year: forceUtcDate.getUTCFullYear(),
      month: forceUtcDate.getUTCMonth() + 1,
      day: forceUtcDate.getUTCDate(),
      hour: forceUtcDate.getUTCHours(),
      minute: forceUtcDate.getUTCMinutes(),
      second: forceUtcDate.getUTCSeconds()
    });
    return plainDateTime.toZonedDateTime(timeZone).toInstant();
  }
  const legacyDate = new Date(dateStr);
  if (!isNaN(legacyDate.getTime())) {
    return Temporal.Instant.fromEpochMilliseconds(legacyDate.getTime());
  }
  console.error(new Error(`Unable to parse date string: ${dateStr}`));
  return null;
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function sleepUntil(time) {
  const timeUntil = Temporal.Now.instant().until(time);
  if (timeUntil.sign === 1) await sleep(timeUntil.total({ unit: "millisecond" }));
}
function checkGMRes({ gmRes, type = "object", minCode = 200, maxCode = 299 }) {
  if (gmRes.status < minCode || gmRes.status > maxCode)
    throw new Error(`HTTP error! Status: ${gmRes.status}`);
  if (typeof gmRes.response !== type)
    throw new Error(`invalid response`);
  return;
}
function detectCJKLanguage(text) {
  const hasHiragana = /\p{Script=Hiragana}/u.test(text);
  const hasKatakana = /\p{Script=Katakana}/u.test(text);
  const hasHangul = /\p{Script=Hangul}/u.test(text);
  const hasHan = /\p{Script=Han}/u.test(text);
  if (hasHiragana || hasKatakana) return "jpn";
  if (hasHan) return "cmn";
  if (hasHangul) return "kor";
  return "und";
}
function slugify(text) {
  return text?.replaceAll(/[+\s:;]/g, "_").replaceAll(/[!@#$%^&*+()'",?/\\[\]]/g, "") ?? "";
}
async function gmFetchAsData(url) {
  if (!(url && URL.canParse(url))) return "data:,";
  const r = await GM.xmlHttpRequest({ url, responseType: "blob" });
  if (!(r.response instanceof Blob && r.response.size))
    return "data:,";
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(r.response);
  });
}
function truncAtWord(string, maxLen) {
  if (string.length <= maxLen) return string;
  let trimmed = string.slice(0, maxLen);
  const lastSpace = trimmed.lastIndexOf(" ");
  if (lastSpace !== -1) trimmed = trimmed.slice(0, lastSpace);
  return trimmed;
}
var loaderLoading = (() => {
  const div = Object.assign(document.createElement("div"), {
    style: "position:fixed; top: 50%; left: 50%; margin-top: -8px; margin-left: -8px; z-index: 99999;"
  });
  Object.assign(div.appendChild(document.createElement("img")), { loading: "lazy", src: "/static/common/loader.gif" });
  return div;
})();
var loaderComplete = (() => {
  const div = Object.assign(document.createElement("div"), {
    style: "position: fixed; top: 50%; left: 50%; margin-top: -150px; margin-left: -150px; z-index: 99999;"
  });
  Object.assign(div.appendChild(document.createElement("img")), { loading: "lazy", src: "/static/common/ajax_complete.png" });
  return div;
})();
var loaderIncomplete = (() => {
  const div = Object.assign(document.createElement("div"), {
    style: "position:fixed; top: 50%; left: 50%; margin-top: -150px; margin-left: -150px; z-index: 99999;"
  });
  Object.assign(div.appendChild(document.createElement("img")), { loading: "lazy", src: "/static/common/ajax_incomplete.png" });
  return div;
})();

// lib-ts/groups/group.ts
var tagMap = new Map(Object.entries({
  "boys.love": "shounen.ai",
  "girls.love": "shoujo.ai",
  "ghosts": "paranormal",
  "magical.sex.shift": "gender.bender",
  "genderswap": "gender.bender",
  "school": "school.life",
  "kids": "kodomo",
  "magical.girls": "mahou.shoujo",
  "superhero": "super.power",
  "postapocalyptic": "post.apocalyptic",
  "cgdct": "cute.girls.doing.cute.things",
  "shota": "shotacon",
  "loli": "lolicon"
}));
var tagBlacklist = /* @__PURE__ */ new Set([
  "award.winning",
  "hentai",
  "adult",
  "video.games",
  "eligible.titles.for.you.should.read.this"
]);
var nameMap = new Map(Object.entries({
  manga: "Manga",
  oneshot: "Oneshot",
  anthology: "Anthology",
  manhwa: "Manhwa",
  manhua: "Manhua",
  lightnovel: "Light Novel",
  novel: "Light Novel",
  doujinshi: "Doujinshi",
  doujin: "Doujinshi",
  tv: "TV Series",
  ova: "OVA",
  movie: "Movie",
  // TODO: figure out what to do here, we have a few different kinds of specials
  special: "",
  ona: "ONA"
}));
var GroupInfo = class {
  mainTitle;
  jpTitle;
  allTitles;
  contentType;
  year;
  coverURL;
  description;
  tags;
  tagString;
  constructor({ mainTitle, jpTitle, allTitles, year, contentType, tags, coverURL, description }) {
    this.mainTitle = mainTitle?.normalize("NFKC") ?? "";
    this.jpTitle = jpTitle?.normalize("NFKC") ?? "";
    this.allTitles = allTitles?.map((title) => title.normalize("NFKC")) ?? [];
    this.year = Number(year) || 0;
    this.coverURL = coverURL ?? "";
    this.description = description ?? "";
    this.tags = tags?.length ? new Set(tags.filter((tag) => typeof tag === "string").map((tag) => tag.replaceAll(" ", ".").toLowerCase().replaceAll(/[^a-z0-9.]/g, "")).map((tag) => tagMap.get(tag) ?? tag).filter((tag) => !tagBlacklist.has(tag))) : /* @__PURE__ */ new Set();
    this.tagString = [...this.tags.values()].join(", ");
    this.contentType = this.checkType(contentType);
  }
  checkType(type) {
    if (!type) throw new Error("Missing content type");
    const normType = type.toLowerCase().replace(/[_\s-]/g, "");
    if (normType === "special")
      return alert(`Type "${type}" is valid but non-specific, select type manually`), "";
    const aType = nameMap.get(normType);
    if (aType === "Doujinshi") {
      if (!confirm("Content is marked Doujinshi, click OK only if you've received explicit staff approval or if series has since been been published (not self-published) by a JAPANESE publisher")) {
        throw new Error("Doujinshi is not allowed without confirmation");
      }
    }
    if (aType)
      return aType;
    else {
      alert(`content type ${type} not allowed here`);
      throw new Error(`content type ${type} not allowed here`);
    }
  }
};

// lib-ts/groups/printed.ts
var PrintedGroupInfo = class extends GroupInfo {
  muId;
  annId;
  malId;
  malSlug;
  constructor({ mainTitle, jpTitle, allTitles, muId, annId, malId, malSlug, contentType, year, tags, coverURL, description }) {
    super({ mainTitle, jpTitle, allTitles, contentType, year, tags, coverURL, description });
    if (muId) this.muId = muId;
    if (annId) this.annId = Number(annId);
    if (malId) this.malId = Number(malId);
    if (malSlug) this.malSlug = slugify(malSlug);
  }
};

// lib-ts/indexeddb.ts
function openDB(name4, version, upgradeCallback) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(name4, version);
    request.onupgradeneeded = (event) => {
      if (upgradeCallback) {
        upgradeCallback(request.result, event.oldVersion, event);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error("Upgrade blocked by another open connection"));
  });
}
function setRecord(db, storeName, value, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const request = tx.objectStore(storeName).put({ id: key, value, updatedAt: Date.now() });
    let result;
    request.onsuccess = () => result = request.result;
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(new Error("Transaction aborted"));
  });
}
function getRecord(db, storeName, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const request = tx.objectStore(storeName).get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function cachedFetch({
  db,
  store,
  id,
  validateCache = () => true,
  maxAge = Infinity,
  request,
  validateRes = () => true,
  transform = (res) => res
}) {
  if (typeof maxAge === "number" && maxAge < 0)
    throw new Error(`negative maxAge: ${maxAge}`);
  const rec = await getRecord(db, store, id);
  if (rec && Date.now() - rec.updatedAt < maxAge && validateCache(rec.value))
    return { data: rec.value, cached: true };
  const gmRes = await GM.xmlHttpRequest({
    responseType: "json",
    anonymous: true,
    ...request,
    onload: (gmRes2) => checkGMRes({ gmRes: gmRes2 })
  });
  if (!validateRes(gmRes.response)) throw new Error("Unexpected data");
  const value = transform(gmRes.response);
  await setRecord(db, store, value, id);
  return { data: value, cached: false };
}

// lib-ts/markdown-to-bbcode.ts
if (typeof marked === "function")
  throw new Error("marked.js is required. Please load via @require https://cdn.jsdelivr.net/npm/marked");
var blockTypes = /* @__PURE__ */ new Set(["blockquote", "code", "def", "heading", "hr", "html", "list", "paragraph", "table", "text", "fences", "lheading", "newline"]);
var inlineTypes = /* @__PURE__ */ new Set(["code", "text", "del", "link", "br", "escape", "tag", "_backpedal", "anyPunctuation", "autolink", "blockSkip", "delLDelim", "delRDelim", "emStrongLDelim", "emStrongRDelimAst", "emStrongRDelimUnd", "nolink", "punctuation", "reflink", "reflinkSearch", "url"]);
function htmlText(html) {
  const doc = domParser.parseFromString(html, "text/html");
  return doc.body.textContent;
}
function markdownToBBCode(markdown) {
  if (!markdown) return "";
  if (typeof markdown !== "string") {
    throw new TypeError(`expected a string, got ${typeof markdown}`);
  }
  const tokens = marked.lexer(markdown.replace(/\r\n/g, "\n"));
  return renderBlocks(tokens).trim() + "\n";
}
function renderBlocks(tokens) {
  return tokens ? tokens.map(renderBlock).join("") : "";
}
function renderBlock(token) {
  switch (token.type) {
    case "heading":
    case "lheading": {
      let size;
      switch (token.depth) {
        case 1:
          size = 6;
          break;
        case 2:
          size = 4;
          break;
        case 3:
          size = 2;
          break;
        default:
          return `[b]${renderInline(token.tokens)}[/b]
`;
      }
      return `[b][size=${size}]${renderInline(token.tokens)}[/size][/b]
`;
    }
    case "paragraph":
      return `${renderInline(token.tokens).trim()}

`;
    case "text":
      return token.tokens ? `${renderInline(token.tokens)}
` : `${token.text}
`;
    case "list": {
      const tag = token.ordered ? "ol" : "ul";
      const items = token.items.map(renderListItem).join("\n");
      return `[${tag}]
${items}[/${tag}]
`;
    }
    case "blockquote":
      return `[quote]
${renderBlocks(token.tokens).trim()}
[/quote]
`;
    case "code":
    case "fences":
      return `[code]
${token.text}
[/code]
`;
    case "table":
      return renderTable(token);
    case "hr":
      return "[hr]\n";
    case "html":
      return htmlText(token.text).trim() + "\n";
    case "space":
    case "newline":
      return "\n";
    case "def":
      return "";
    default:
      if (inlineTypes.has(token.type))
        return renderInlineToken(token);
      if ("tokens" in token && blockTypes.has(token.type))
        return renderBlocks(token.tokens);
      if ("text" in token)
        return token.text;
      return "";
  }
}
function renderListItem(token) {
  const checkbox = token.checked === true ? "[x] " : token.checked === false ? "[ ] " : "";
  const inner = token.tokens ? renderBlocks(token.tokens).trim() : token.text ?? "";
  return `[li]${checkbox}${inner}[/li]`;
}
function renderInline(tokens = []) {
  return tokens.map(renderInlineToken).join("");
}
function renderInlineToken(token) {
  switch (token.type) {
    case "text":
      return token.tokens ? renderInline(token.tokens) : token.text;
    case "strong":
      return `[b]${renderInline(token.tokens)}[/b]`;
    case "em":
      return `[i]${renderInline(token.tokens)}[/i]`;
    case "del":
      return `[s]${renderInline(token.tokens)}[/s]`;
    case "codespan":
      return `\`${token.text}\``;
    case "link":
    case "autolink":
      return `[url=${token.href}]${renderInline(token.tokens)}[/url]`;
    case "url": {
      const href = token["href"] ?? token["text"] ?? "";
      return `[url=${href}]${href}[/url]`;
    }
    case "image":
      return `[img]${token.href}[/img]`;
    case "br":
    case "newline":
      return "\n";
    case "tag":
      return token["text"] ?? "";
    case "escape":
      return token.text;
    default:
      if ("tokens" in token && token.tokens) {
        return renderInline(token.tokens);
      }
      return token["text"] ?? "";
  }
}
function renderTable(token) {
  const parts = ["[table]\n"];
  parts.push("[tr]\n");
  for (const cell of token.header) {
    parts.push(`[th]${renderInline(cell.tokens).trim()}[/th]
`);
  }
  parts.push("[/tr]\n");
  for (const row of token.rows) {
    parts.push("[tr]\n");
    for (const cell of row) {
      parts.push(`[td]${renderInline(cell.tokens).trim()}[/td]
`);
    }
    parts.push("[/tr]\n");
  }
  parts.push("[/table]\n");
  return parts.join("");
}

// lib-ts/metadata/extdb.ts
var dbName = "cacheDB";
var dbVersion = 2;
var malMangaStore = "malManga";
var malAnimeStore = "malAnime";
var mdexMangaStore = "mdexManga";
var mdexCoverStore = "mdexCovers";
var muMangaStore = "muManga";
function openExtDB() {
  return openDB(dbName, dbVersion, (db, oldVersion, e) => {
    if (oldVersion < 1) {
      db.createObjectStore(mdexMangaStore, { keyPath: "id" });
      db.createObjectStore(mdexCoverStore, { keyPath: "id" });
      db.createObjectStore(muMangaStore, { keyPath: "id" });
      db.createObjectStore(malMangaStore, { keyPath: "id" });
      console.log(`upgraded ${dbName} to v${dbVersion}`);
    }
    if (oldVersion < 2) {
      db.createObjectStore(malAnimeStore, { keyPath: "id" });
      console.log(`upgraded ${dbName} to v${dbVersion}`);
    }
  });
}
var extDB = await openExtDB();

// lib-ts/groups/anime.ts
var AnimeGroupInfo = class extends GroupInfo {
  adbId;
  annId;
  malId;
  malSlug;
  epCount;
  startDate;
  endDate;
  constructor({ mainTitle, jpTitle, allTitles, adbId, annId, malId, malSlug, contentType, year, tags, coverURL, description, epCount, startDate, endDate }) {
    if (!contentType)
      throw new Error("No content type provided");
    super({ mainTitle, jpTitle, allTitles, contentType, year, tags, coverURL, description });
    this.adbId = adbId ?? 0;
    this.annId = Number(annId) || 0;
    this.malId = Number(malId) || 0;
    this.malSlug = slugify(malSlug);
    this.startDate = stringToInstant(startDate);
    this.endDate = stringToInstant(endDate);
    this.epCount = epCount ? Number(epCount) : 0;
  }
};

// lib-ts/metadata/utils.ts
function refToId({ name: name4, ref, idPattern: idPattern4, hostnames, prefix, simpleMap, cast }) {
  const id = simpleMap(ref);
  if (id) return cast(id);
  const errors = [];
  const url = new URL(ref.toString());
  if (!hostnames.includes(url.hostname))
    errors.push(Error(`Provided hostname ${url.hostname} not in ${hostnames}`));
  if (!url.pathname.startsWith(prefix))
    errors.push(Error(`Unexpected pathname prefix ${url.pathname}`));
  const testId = url.pathname.split(prefix)[1]?.split("/")[0];
  if (!(testId && testId !== "0" && idPattern4.test(testId))) {
    errors.push(Error(`${name4} ID [${testId ?? "undefined"}] does not match expected format`));
  }
  if (errors.length) {
    for (const err of errors) console.error(err.message);
    alert(`Invalid ${name4} Link`);
    throw new Error(`${name4} URL [${url}] does not match expected format`);
  }
  return cast(testId);
}

// lib-ts/metadata/consts.ts
var malClientId = Array.from(atob("ZTc4OTRhMTFlZjUxZTFkMTA3N2IxODZhYzAwZDQxMTY=")).reverse().join("");

// lib-ts/metadata/mal.ts
var name = "MyAnimeList";
var idPattern = /^\d+$/;
var malMaxQueryLen = 64;
var malPrintedCategoryMap = {
  manga: ["manga", "manhwa", "manhua", "one_shot"],
  light_novels: ["light_novel", "novel"],
  artbooks: []
};
var ABMALTypeMap = {
  "TV Series": ["tv"],
  OVA: ["ova"],
  Movie: ["movie"],
  "BD Special": ["special"],
  "TV Special": ["special"],
  "DVD Special": ["special"],
  ONA: ["ona"],
  PV: ["music"],
  Manga: ["manga"],
  Anthology: ["manga"],
  "Light Novel": ["light_novel", "novel"],
  Oneshot: ["one_shot"],
  Manhwa: ["manhwa"],
  Manhua: ["manhua"]
};
var animeFields = [
  "id",
  "title",
  "alternative_titles",
  "main_picture",
  "pictures",
  "background",
  "start_date",
  "end_date",
  "synopsis",
  "genres",
  "created_at",
  "updated_at",
  "media_type",
  "status",
  "nsfw",
  "num_episodes",
  "start_season",
  "broadcast",
  "source",
  "average_episode_duration"
].join(",");
var printedFields = [
  "id",
  "title",
  "alternative_titles",
  "main_picture",
  "pictures",
  "background",
  "start_date",
  "end_date",
  "synopsis",
  "genres",
  "created_at",
  "updated_at",
  "media_type",
  "status",
  "nsfw",
  "num_volumes",
  "num_chapters",
  "authors{first_name,last_name}",
  "serialization{name}"
].join(",");
var malPrintedMapper = {
  getId: (r) => r.id,
  getTitle: (r) => r.title,
  getURL: (r) => `https://myanimelist.net/manga/${r.id}`,
  getCoverURL: (r) => r.main_picture?.medium
};
var malAnimeMapper = {
  getId: (r) => r.id,
  getTitle: (r) => r.title,
  getURL: (r) => `https://myanimelist.net/manga/${r.id}`,
  getCoverURL: (r) => r.main_picture?.medium
};
var malPrintedProvider = {
  name: "MyAnimeList (Printed)",
  linkTitle: "MAL",
  get: (ref) => getMALPrinted(ref),
  search: (title, type) => searchMALPrinted({ title, types: ABMALTypeMap[type] }),
  idToUrl: (id) => `https://myanimelist.net/manga/${id}`,
  category: "printed",
  mapper: malPrintedMapper,
  builtIn: true,
  linkType: 7
};
var malAnimeProvider = {
  name: "MyAnimeList (Anime)",
  linkTitle: "MAL",
  get: (ref) => getMALAnime({ ref }).then((rec) => rec.data),
  search: (title, _) => searchMALAnime({ title }),
  idToUrl: (id) => `https://myanimelist.net/anime/${id}`,
  category: "anime",
  mapper: malAnimeMapper,
  builtIn: true,
  linkType: 7
};
async function getMALAnime({ ref, maxAge }) {
  const id = refToId({
    name,
    idPattern,
    ref,
    hostnames: ["myanimelist.net"],
    prefix: "/anime/",
    simpleMap: (ref2) => Number(ref2) || null,
    cast: Number
  });
  const { data, cached } = await cachedFetch({
    db: extDB,
    store: malAnimeStore,
    id,
    maxAge,
    request: {
      url: `https://api.myanimelist.net/v2/anime/${id}?fields=${animeFields}`,
      headers: { "X-MAL-CLIENT-ID": malClientId }
    }
  });
  const broadcastTime = data.broadcast?.start_time ? `T${data.broadcast.start_time}+09:00` : "";
  const startDate = data.start_date ? data.start_date + broadcastTime : null;
  const endDate = data.end_date ? data.end_date + broadcastTime : null;
  const allTitles = [
    data.title ?? [],
    ...data.alternative_titles?.synonyms ?? [],
    data.alternative_titles?.en ?? [],
    data.alternative_titles?.ja ?? []
  ].flat();
  return {
    data: new AnimeGroupInfo({
      mainTitle: data.alternative_titles?.en || data.title,
      jpTitle: data.alternative_titles?.ja,
      allTitles,
      malId: id,
      malSlug: data.title,
      contentType: data.media_type,
      year: new Date(data.start_date ?? "").getUTCFullYear(),
      tags: data.genres?.map((g) => g.name),
      coverURL: data.main_picture?.large,
      description: data.synopsis,
      startDate,
      endDate,
      epCount: data.num_episodes
    }),
    cached
  };
}
async function getMALPrinted(ref) {
  const id = refToId({
    name,
    idPattern,
    ref,
    hostnames: ["myanimelist.net"],
    prefix: "/manga/",
    simpleMap: (ref2) => Number(ref2) || null,
    cast: Number
  });
  const { data } = await cachedFetch({
    db: extDB,
    store: malMangaStore,
    id,
    request: {
      url: `https://api.myanimelist.net/v2/manga/${id}?fields=${printedFields}`,
      headers: { "X-MAL-CLIENT-ID": malClientId }
    }
  });
  const allTitles = [
    data.title ?? [],
    data.alternative_titles?.synonyms ?? [],
    data.alternative_titles?.en ?? [],
    data.alternative_titles?.ja ?? []
  ].flat();
  return new PrintedGroupInfo({
    mainTitle: data.alternative_titles?.en || data.title,
    jpTitle: data.alternative_titles?.ja,
    allTitles,
    malId: id,
    malSlug: data.title,
    contentType: data.media_type,
    year: new Date(data.start_date ?? "").getUTCFullYear(),
    tags: data.genres?.map((g) => g.name),
    coverURL: data.main_picture?.large,
    description: data.synopsis
  });
}
async function searchMALAnime({ title, max = 24, perPage = 24, cache = false, cacheCond = () => true, extraParams }) {
  const results = [];
  const params = new URLSearchParams({ q: truncAtWord(title, malMaxQueryLen), limit: perPage.toString(), offset: "0", nsfw: "true", fields: animeFields, ...extraParams });
  let nextUrl = params.has("status") ? `https://api.myanimelist.net/v2/anime/search?${params}` : `https://api.myanimelist.net/v2/anime?${params}`;
  for (let offset = 0, last = Temporal.Now.instant(); nextUrl && offset < max; offset += perPage) {
    if (offset) await sleepUntil(last.add({ milliseconds: 500 }));
    const gmRes = await GM.xmlHttpRequest({
      url: nextUrl,
      responseType: "json",
      anonymous: true,
      headers: { "X-MAL-CLIENT-ID": malClientId },
      onloadstart: () => last = Temporal.Now.instant()
    });
    checkGMRes({ gmRes });
    const animeListRes = gmRes.response;
    results.push(...animeListRes.data?.flatMap((anime) => anime.node ?? []) ?? []);
    nextUrl = animeListRes.paging?.next;
  }
  if (cache) {
    for (const result of results) {
      if (cacheCond(result) && result.id) setRecord(extDB, malAnimeStore, result, result.id);
    }
  }
  return results;
}
async function searchMALPrinted({ title, types }) {
  const params = new URLSearchParams({ q: truncAtWord(title, malMaxQueryLen), limit: "24", offset: "0", nsfw: "true", fields: printedFields });
  const gmRes = await GM.xmlHttpRequest({
    url: `https://api.myanimelist.net/v2/manga?${params}`,
    responseType: "json",
    anonymous: true,
    headers: { "X-MAL-CLIENT-ID": malClientId }
  });
  checkGMRes({ gmRes });
  const printedListRes = gmRes.response;
  if (!printedListRes.data) throw new Error(`No data on ${name} response`);
  return printedListRes.data.flatMap((printed) => printed.node ?? []).filter((printed) => printed.media_type && types.includes(printed.media_type));
}

// lib-ts/metadata/mu.ts
var name2 = "MangaUpdates";
var idPattern2 = /^[0-9a-z]{5,7}$/;
var cleanTitleExp = /\s*[(（](Novel|小説)[）)]$/;
var muCategoryMap = {
  manga: ["Manga", "Oneshot", "Anthology", "Manhwa", "Manhua"],
  light_novels: ["Novel"],
  artbooks: ["Artbook"]
};
var ABMUTypeMap = {
  Manga: ["Manga", "Anthology"],
  Anthology: ["Manga", "Anthology"],
  "Light Novel": ["Novel"],
  Oneshot: ["Manga"],
  Manhwa: ["Manhwa"],
  Manhua: ["Manhua"],
  Artbook: ["Artbook"]
};
var muMapper = {
  getId: (r) => r.series_id,
  getTitle: (r) => r.title,
  getURL: (r) => r.url,
  getCoverURL: (r) => r.image?.url?.original
};
var mangaupdatesProvider = {
  name: "MangaUpdates",
  linkTitle: "Manga-Updates",
  get: (ref) => getMUData(ref),
  search: (title, type) => searchMU(title, ABMUTypeMap[type]),
  idToUrl: (id) => `https://www.mangaupdates.com/series/${Number(id).toString(36)}`,
  mapper: muMapper,
  builtIn: true,
  linkType: 5
};
async function searchMU(title, types) {
  const gmRes = await GM.xmlHttpRequest({
    url: `https://api.mangaupdates.com/v1/series/search`,
    method: "POST",
    responseType: "json",
    anonymous: true,
    headers: { "Content-Type": "application/json" },
    data: JSON.stringify({ search: title, perpage: 24, type: types }),
    onload: (gmRes2) => checkGMRes({ gmRes: gmRes2 })
  });
  const mangaListRes = gmRes.response;
  if (!mangaListRes) throw new Error(`No data on ${name2} response`);
  const data = mangaListRes.results?.flatMap((result) => result.record ?? []) ?? [];
  return data;
}
async function getMUData(ref, promptTitle = true) {
  const id = refToId({
    name: name2,
    idPattern: idPattern2,
    ref,
    hostnames: ["www.mangaupdates.com", "mangaupdates.com"],
    prefix: "/series/",
    simpleMap: (ref2) => typeof ref2 === "number" || Number(ref2) ? Number(ref2) : idPattern2.test(ref2) ? parseInt(ref2, 36) : null,
    cast: (b) => typeof b === "number" ? b : parseInt(b, 36)
  });
  const { data } = await cachedFetch({
    db: extDB,
    store: muMangaStore,
    id,
    request: { url: `https://api.mangaupdates.com/v1/series/${id}` }
  });
  const titles = data.associated?.map((entry) => ({ lang: detectCJKLanguage(entry.title), title: entry.title }));
  if (!data.type) throw new Error("Unknown content type");
  const [jpTitles, cnTitles, krTitles, unsureTitles] = [[], [], [], []];
  if (titles?.length) for (const { lang, title } of titles) switch (lang) {
    case "jpn":
      jpTitles.push(title);
      break;
    case "cmn":
      cnTitles.push(title);
      break;
    case "kor":
      krTitles.push(title);
      break;
    default:
      unsureTitles.push(title);
  }
  let ogTitle = null;
  if (["Manga", "Artbook", "Oneshot", "Novel"].includes(data.type) && jpTitles.length === 1) {
    ogTitle = jpTitles[0];
  } else if (data.type === "Manhwa" && krTitles.length === 1) {
    ogTitle = krTitles[0];
  } else if (data.type === "Manhua" && cnTitles.length === 1) {
    ogTitle = cnTitles[0];
  } else if (promptTitle) {
    ogTitle = await promptSelect(`Japanese/Original title (${name2})`, {
      "Japanese Titles": jpTitles,
      "Korean Titles": krTitles,
      "Chinese (or Kanji) Titles": cnTitles,
      "Other Titles": unsureTitles
    });
  }
  const allTitles = [
    data.title ?? [],
    data.associated?.map((entry) => entry.title) ?? []
  ].flat().map((title) => title.replace(cleanTitleExp, ""));
  return new PrintedGroupInfo({
    mainTitle: data.title?.replace(cleanTitleExp, ""),
    jpTitle: ogTitle?.replace(cleanTitleExp, ""),
    allTitles,
    muId: id.toString(36),
    contentType: data.type,
    year: data.year,
    tags: data.genres?.map((entry) => entry.genre),
    coverURL: data.image?.url?.original,
    description: markdownToBBCode(data.description)
  });
}

// lib-ts/metadata/mdex.ts
var name3 = "MangaDex";
var idPattern3 = /^[a-f0-9]{8}-([a-f0-9]{4}-){3}[a-f0-9]{12}$/;
var mdexMapper = {
  getId: (r) => r.id ?? "",
  getTitle: (r) => r.attributes?.title?.["ja-ro"] || r.attributes?.title?.["en"] || "",
  getCoverURL: (r) => `https://mangadex.org/covers/${r.id}/${r.relationships?.find((rel) => rel.type === "cover_art")?.attributes?.["fileName"]}.256.jpg`,
  getURL: (r) => `https://mangadex.org/title/${r.id}`
};
var mangadexProvider = {
  name: "MangaDex",
  linkTitle: "MangaDex",
  get: (id) => getMdexData(id),
  search: (title) => searchMdex(title),
  idToUrl: (id) => `https://mangadex.org/title/${id}`,
  mapper: mdexMapper
};
var typeLangMap = {
  Manga: ["ja"],
  Oneshot: ["ja", "ko", "zh", "zh-hk"],
  Anthology: ["ja"],
  Manhua: ["zh", "zh-hk"],
  Manhwa: ["ko"]
};
async function searchMdex(title, type) {
  const params = new URLSearchParams([
    ["includes[]", "cover_art"],
    ["contentRating[]", "safe"],
    ["contentRating[]", "suggestive"],
    ["contentRating[]", "erotica"],
    ["title", title],
    ["availableTranslatedLanguage[]", "en"],
    // Doujinshi
    ["excludedTags[]", "b13b2a48-c720-44a9-9c77-39c9979373fb"],
    ["limit", "24"]
  ]);
  if (type) for (const lang of typeLangMap[type]) params.append("originalLanguage[]", lang);
  const gmRes = await GM.xmlHttpRequest({ url: `https://api.mangadex.org/manga?${params}`, responseType: "json", anonymous: true });
  checkGMRes({ gmRes });
  const mangaListRes = gmRes.response;
  if (!mangaListRes.data) throw new Error(`No data on ${name3} response`);
  return mangaListRes.data;
}
async function getMdexData(ref) {
  const id = refToId({
    name: name3,
    idPattern: idPattern3,
    ref,
    hostnames: ["mangadex.org"],
    prefix: "/title/",
    simpleMap: (ref2) => {
      if (idPattern3.test(ref2)) return ref2;
    },
    cast: String
  });
  const { data } = await cachedFetch({
    db: extDB,
    store: mdexMangaStore,
    id,
    request: { url: `https://api.mangadex.org/manga/${id}` },
    validateRes: (r) => typeof r.data === "object" && r.result === "ok",
    // validateRes runs before transform
    transform: (r) => r.data
  });
  let muData, malData;
  try {
    if (data.attributes?.links?.["mal"])
      malData = await getMALPrinted(data.attributes.links["mal"]);
    if (data.attributes?.links?.["mu"])
      muData = await getMUData(data.attributes.links["mu"], Boolean(malData?.jpTitle));
  } catch (e) {
    console.error(e);
  }
  const { data: coverData } = await cachedFetch({
    db: extDB,
    store: mdexCoverStore,
    id,
    request: { url: `https://api.mangadex.org/cover?order[volume]=asc&manga[]=${id}&limit=10` }
  });
  const cover = coverData.data?.find((c) => c.attributes?.locale === "ja" && Number(c.attributes.volume) >= 1) ?? coverData.data?.find((c) => c.attributes?.locale === "ja") ?? coverData.data?.[0];
  const coverURL = cover ? `https://mangadex.org/covers/${id}/${cover.attributes?.fileName}.512.jpg` : "";
  const tags = [
    ...data.attributes?.tags?.filter((t) => ["theme", "genre", "demo"].includes(t.attributes?.group ?? "")).flatMap((tag) => tag.attributes?.name?.["en"] ?? "") ?? [],
    ...malData?.tags.values() ?? [],
    ...muData?.tags.values() ?? []
  ];
  const allTitles = [
    Object.values(data.attributes?.title ?? {}),
    Object.values(data.attributes?.altTitles ?? {}).flatMap((altTitle) => Object.values(altTitle))
  ].flat();
  let type = "Manga";
  if (data.attributes?.tags) {
    const types = data.attributes.tags.filter((t) => t.attributes?.group === "format").flatMap((t) => t.attributes?.name?.["en"] ?? []);
    if (types.length) {
      if (types.includes("Doujinshi"))
        type = "Doujinshi";
      else if (types.includes("Oneshot"))
        type = "Oneshot";
      else if (typeLangMap.Manhua.includes(data.attributes.originalLanguage))
        type = "Manhua";
      else if (typeLangMap.Manhwa.includes(data.attributes.originalLanguage))
        type = "Manhwa";
      else if (types.includes("Anthology"))
        type = "Anthology";
    }
  }
  return new PrintedGroupInfo({
    mainTitle: malData?.mainTitle || muData?.mainTitle || data.attributes?.title?.["ja-ro"] || data.attributes?.title?.["en"],
    jpTitle: malData?.jpTitle || data.attributes?.altTitles?.find((lang) => "ja" in lang)?.["ja"] || muData?.jpTitle,
    allTitles,
    muId: data.attributes?.links?.["mu"],
    malId: data.attributes?.links?.["mal"],
    malSlug: malData?.malSlug,
    contentType: type,
    year: muData?.year || data.attributes?.year || malData?.year,
    tags,
    coverURL,
    description: markdownToBBCode(data.attributes?.description?.["en"])
  });
}

// lib-ts/metadata/metadata.ts
var categoryProviders = {
  manga: { mangadex: mangadexProvider, mangaupdates: mangaupdatesProvider, malPrinted: malPrintedProvider },
  light_novels: { mangaupdates: mangaupdatesProvider, malPrinted: malPrintedProvider },
  anime: { malAnime: malAnimeProvider },
  artbooks: {},
  games: {},
  live_action: {},
  music: {},
  packs: {},
  pvs: {},
  visual_novels: {}
};
async function promptSearchResults(message, results, { getId, getTitle, getCoverURL, getURL }) {
  if (!results?.filter((r) => r).length) return alert("No results found.");
  const container = document.createElement("div");
  Object.assign(container.style, { display: "flex", flexDirection: "column", gap: "12px" });
  const select = document.createElement("select");
  const grid = document.createElement("div");
  Object.assign(grid.style, {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
    gap: "8px",
    width: "min(1000px, 40vw)",
    maxHeight: "60vh",
    overflowY: "auto"
  });
  const entries = await Promise.all(results.map(async (result2) => ({
    id: getId(result2) ?? "",
    title: getTitle(result2) ?? "",
    image: await gmFetchAsData(getCoverURL(result2)),
    link: getURL(result2) ?? ""
  })));
  for (const { id, title, image, link } of entries) {
    const opt = new Option(title, String(id));
    select.append(opt);
    const card = Object.assign(document.createElement("div"), { title });
    Object.assign(card.style, {
      display: "flex",
      flexDirection: "column",
      gap: "4px",
      cursor: "pointer",
      textAlign: "center",
      height: "100%"
    });
    card.dataset["index"] = String(id);
    const thumb = document.createElement("div");
    Object.assign(thumb.style, {
      width: "100%",
      aspectRatio: "2/3",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      borderRadius: "4px",
      background: "rgba(127,127,127,0.08)"
    });
    const img = document.createElement("img");
    Object.assign(img, { src: image, alt: title });
    Object.assign(img.style, {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      borderRadius: "4px"
    });
    thumb.append(img);
    const label = document.createElement("span");
    label.textContent = title;
    Object.assign(label.style, {
      fontSize: "0.75em",
      overflow: "hidden",
      display: "-webkit-box",
      WebkitBoxOrient: "vertical",
      WebkitLineClamp: "3",
      whiteSpace: "normal",
      wordBreak: "break-word"
    });
    const anchor = Object.assign(document.createElement("a"), { href: link, target: "_blank", rel: "noopener noreferrer", textContent: "\u2197 Open" });
    Object.assign(anchor.style, { color: "inherit", opacity: "0.6", marginTop: "auto" });
    anchor.addEventListener("click", (e) => e.stopPropagation());
    const body = document.createElement("div");
    Object.assign(body.style, {
      display: "flex",
      flexDirection: "column",
      gap: "4px",
      padding: "6px",
      border: "2px solid transparent",
      borderRadius: "6px",
      transition: "border-color 0.15s"
    });
    body.append(thumb, label);
    card.append(body, anchor);
    grid.append(card);
  }
  ;
  const selectCard = (id) => {
    for (const card2 of grid.querySelectorAll("[data-index] > div")) card2.style.borderColor = "transparent";
    const card = grid.querySelector(`[data-index="${CSS.escape(id)}"]`);
    if (card && card.firstElementChild) {
      card.firstElementChild.style.borderColor = "currentColor";
      card.scrollIntoView({ block: "nearest" });
    }
    select.value = id;
  };
  grid.addEventListener("click", (e) => {
    const card = e.target?.closest("div[data-index]");
    if (card) selectCard(card.dataset.index);
  });
  select.selectedIndex = -1;
  select.addEventListener("change", (e) => {
    if (e.isTrusted) selectCard(select.value);
  });
  container.append(select, grid);
  const { dialog, result } = promptDialog(message, container);
  dialog.showModal();
  return result.then((returnValue) => {
    const value = returnValue === "ok" ? select.value : null;
    dialog.remove();
    return value;
  });
}

// src/ab-upload/main.ts
var scriptConfig = {
  autofillScanlated: { label: "Determine Translation status and Release Group from filename", default: false },
  hideExistingAutofill: { label: "Hide existing autofill inputs", default: false },
  autoSearch: { label: "Automatically search on tabs opened by Multi Torrent input", default: false },
  // forceRefresh: {  label: "Refresh regardless of cache", default: false },
  checkDupes: { label: "Use /scrape.php to check for dupes (uses passkey above upload form)", default: true }
  // checkDigital: {  label: "Simple search of torrent name to automatically check if digital", default: false },
  // printedGroupNameExp: { label: "Regular expression to use to use to capture group name from filename", default: "" },
};
function getCompat() {
  return {
    marvBetterUpload: Boolean(document.querySelector(".multi-torrent-upload-button"))
  };
}
function chipDivsCompat(chipsDiv, contentType) {
  if (!chipsDiv) return;
  for (const chip of chipsDiv.children) {
    if (chip.innerText === contentType)
      chip.classList.add("selected");
    else
      chip.classList.remove("selected");
  }
}
function addMultifileInput() {
  const uploadMap = /* @__PURE__ */ new WeakMap();
  for (const uploadTab of document.querySelectorAll("#dynamic_form > div:not(#packs)")) {
    if (!(uploadTab instanceof HTMLDivElement)) throw new Error(`Unexpected element type for upload tab: ${uploadTab.tagName}`);
    const category = uploadTab.id;
    const torrentFileRoot = uploadTab.querySelector("#torrent_file");
    const torrentInput = torrentFileRoot?.querySelector("input[type='file'][id^='file_input']");
    if (!(torrentFileRoot && torrentInput?.parentElement)) throw new Error(`Unable to find torrent input for ${category}`);
    torrentInput.style.maxWidth = "100%";
    const tabs = [];
    const { title, container, inputs, buttons } = addInput({
      root: torrentFileRoot,
      afterEl: torrentInput.parentElement,
      titleOpts: { textContent: "Multi Torrent Upload" },
      inputDef: { multiFile: { type: "file", accept: ".torrent, *", id: `pine-multi-file-${category}` } },
      buttonDef: { closeTab: { textContent: "Close opened tabs" } }
    });
    Object.assign(container.style, { display: "flex", gap: "8px", maxWidth: "100%" });
    container.classList.add("pine-multi-file-container");
    title.classList.add("pine-multi-file-container");
    const fileInput = inputs.multiFile;
    fileInput.style.maxWidth = "100%";
    buttons.closeTab.addEventListener("click", () => closeAllTabs(tabs));
    const providerSelect = document.createElement("select");
    if (categoryProviders[category]) {
      for (const [k, v] of Object.entries(categoryProviders[category]))
        providerSelect.add(new Option(v.name, k));
      fileInput.after(Object.assign(document.createElement("strong"), { textContent: "Autofill type:" }), providerSelect);
    }
    fileInput.multiple = true;
    fileInput.addEventListener("change", async (event) => {
      const files = event.target?.files;
      if (!(files instanceof FileList && files.length)) return;
      await sleep(0);
      for (const file of files) {
        const uuid = crypto.randomUUID();
        const tab = lazyLoadTab({
          title: file.name,
          url: `${window.location.origin}/upload.php#${category}`,
          data: { provider: providerSelect.value, category, uuid }
        });
        if (!tab) {
          console.error("Failed to open tab for", file);
          continue;
        }
        tabs.push(tab);
        uploadMap.set(tab, { uuid, file });
        console.debug("loaded", tab, "opened by", tab.opener, "for file:", file.name);
      }
      window.open()?.close();
    });
  }
  window.addEventListener("message", async (event) => {
    const tab = event.source;
    if (!tab) return;
    const uploadInfo = event.data.data;
    if (!uploadInfo) return;
    const { uuid, file } = uploadMap.get(tab) ?? {};
    if (!file) throw new Error("File not found");
    if (!(event.origin === window.location.origin && event.data.type === "lazyLoadTab:focused" && uploadInfo.uuid === uuid)) return;
    await sleep(1e3);
    if (tab.document.body.id !== "upload") {
      console.debug("waiting");
      await waitElement({ selector: "body#upload", root: tab.document.documentElement });
    }
    for (const el of tab.document.querySelectorAll(".pine-multi-file-container")) el.remove();
    const uploadForm = tab.document.querySelector(`#dynamic_form > div#${uploadInfo.category}`);
    const filePicker = uploadForm?.querySelector(`#torrent_file input#file_input_${uploadInfo.category}`);
    if (!(uploadForm?.tagName == "DIV" && filePicker?.tagName === "INPUT")) return;
    const fileData = new DataTransfer();
    fileData.items.add(file);
    filePicker.files = fileData.files;
    filePicker.dispatchEvent(new Event("change"));
    const autofill = uploadForm.querySelector(`#${uploadInfo.provider}-autofill-${uploadInfo.category}`);
    if (autofill && uploadInfo.provider) {
      autofill.value = file.name.replace(/\s*\[.*?\](\.torrent)?$/, "");
      if (getSetting(scriptConfig, "autoSearch") && autofill.value) {
        const search = autofill.closest("div")?.querySelectorAll("button").values().find((b) => b.textContent === "Search");
        if (search && autofill.value) search.click();
      }
    } else {
      console.error("Unable to find autofill element for:", "tab", tab, "uuid", uploadInfo.uuid);
    }
  });
}
function fillMangaData(info) {
  const category = "manga";
  const root = document.querySelector(`#${category}_form > #group_information`);
  const compat = getCompat();
  if (!(root instanceof HTMLDivElement)) throw new Error("No group information field found");
  if (info.mainTitle)
    root.querySelector(`#series_name_${category}`).value = info.mainTitle;
  if (info.jpTitle)
    root.querySelector(`#series2_${category}`).value = info.jpTitle;
  if (info.muId)
    root.querySelector(`#link1_${category}`).value = `https://www.mangaupdates.com/series/${info.muId}`;
  if (info.annId)
    root.querySelector(`#link2_${category}`).value = `https://www.animenewsnetwork.com/encyclopedia/manga.php?id=${info.annId}`;
  if (info.malId && info.malSlug)
    root.querySelector(`#link3_${category}`).value = `https://myanimelist.net/manga/${info.malId}/${info.malSlug}`;
  const typeSelector = root.querySelector(`#${category}type`);
  if (info.contentType)
    typeSelector.value = info.contentType;
  if (info.year)
    root.querySelector(`#year_${category}`).value = info.year;
  if (info.tags.size)
    root.querySelector(`#tags_${category}`).value = info.tagString;
  if (info.coverURL)
    root.querySelector(`#image_${category}`).value = info.coverURL;
  if (info.description)
    root.querySelector(`#desc_${category}`).value = info.description;
  if (compat.marvBetterUpload && typeSelector) chipDivsCompat(typeSelector.previousElementSibling, info.contentType);
}
function fillLNData(info) {
  const category = "light_novels";
  const root = document.querySelector(`#${category}_form > #group_information`);
  if (!(root instanceof HTMLDivElement)) throw new Error("No group information field found");
  if (info.mainTitle)
    root.querySelector(`#series_name_${category}`).value = info.mainTitle;
  if (info.jpTitle)
    root.querySelector(`#series2_${category}`).value = info.jpTitle;
  if (info.year)
    root.querySelector(`#year_${category}`).value = info.year;
  if (info.tags.size)
    root.querySelector(`#tags_${category}`).value = info.tagString;
  if (info.coverURL)
    root.querySelector(`#image_${category}`).value = info.coverURL;
  if (info.description)
    root.querySelector(`#desc_${category}`).value = info.description;
}
async function fillMdexData(ref) {
  fillMangaData(await getMdexData(ref));
}
async function fillMUData(ref) {
  fillMangaData(await getMUData(ref));
}
async function fillMALData(ref) {
  fillMangaData(await getMALPrinted(ref));
}
async function checkDupe(mainTitle, jpTitle, type = "anime") {
  if (!mainTitle) throw new Error("title required for duplicate search");
  const announceURL = URL.parse(document.querySelector("div.thin.yui-navset > p > input")?.value ?? "");
  if (!announceURL) throw new Error("No announce URL found");
  const username = document.querySelector(".username")?.innerText;
  const passkey = announceURL.pathname.split("/")[1];
  if (!(username && passkey)) throw new Error("unable to find username or passkey");
  const makeParams = (title) => new URLSearchParams({
    torrent_pass: passkey,
    username,
    type,
    sort: "relevance",
    showhidden: "1",
    searchstr: title.replaceAll(/"':\?/g, "")
  });
  const mainRes = await fetch(`/scrape.php?${makeParams(mainTitle)}`, { credentials: "omit" });
  if (!mainRes.ok)
    throw new Error(`${mainRes.status} error`);
  const mainData = await mainRes.json();
  if (typeof mainData !== "object") throw new Error("invalid scrape response");
  let jpGroups;
  if (jpTitle) {
    const jpRes = await fetch(`/scrape.php?${makeParams(jpTitle)}`, { credentials: "omit" });
    if (!jpRes.ok)
      throw new Error(`${jpRes.status} error`);
    const jpData = await jpRes.json();
    if (typeof jpData !== "object") throw new Error("invalid scrape response");
    jpGroups = jpData.Groups;
  }
  const groups = [...mainData.Groups ?? [], ...jpGroups ? jpGroups : []];
  if (!groups.length) return true;
  const mainTitleMatch = groups.find((g) => g.SeriesName === mainTitle);
  const jpTitleMatches = groups.filter((g) => g.SynonymnsV2.Japanese.normalize("NFKC") === jpTitle.normalize("NFKC"));
  const altTitleMatches = groups.filter((g) => [g.SynonymnsV2.Romaji, g.SynonymnsV2.Alternative].includes(mainTitle));
  const div = document.createElement("div");
  Object.assign(div.style, { display: "flex", flexDirection: "column", gap: "1em" });
  if (mainTitleMatch) {
    const h = document.createElement("h2");
    h.innerText = "Existing series with exact title";
    const p = Object.assign(document.createElement("p"), { textContent: "The following series matches the Main Title of your upload, confirm this torrent is related to the following series or change the Main Title to avoid uploading under an unrelated group" });
    const a = Object.assign(document.createElement("a"), { href: `/series.php?id=${mainTitleMatch.SeriesID}`, innerText: mainTitle });
    div.appendChild(document.createElement("div")).append(h, p, a);
  }
  if (jpTitleMatches.length && jpTitleMatches.some((g) => g.SeriesID !== mainTitleMatch?.SeriesID)) {
    const h = document.createElement("h2");
    h.innerText = "Existing series with exact Japanese title";
    const p = Object.assign(document.createElement("p"), { textContent: "The following series match the Japanese Title of your upload, if these are the same series you should change the main title to this" });
    const links = new Map(jpTitleMatches.map((group) => [
      group.SeriesID,
      Object.assign(document.createElement("a"), { href: `/series.php?id=${group.SeriesID}`, innerText: group.SeriesName })
    ])).values();
    div.appendChild(document.createElement("div")).append(h, p, ...links);
  }
  if (altTitleMatches.length && altTitleMatches.some((g) => g.SeriesID !== mainTitleMatch?.SeriesID)) {
    const h = document.createElement("h2");
    h.innerText = "The following series have Romaji or Alternate Titles matching the Main Title of your upload, if these are the same series you should change the main title to this";
    const links = new Map(altTitleMatches.map((group) => [
      group.SeriesID,
      Object.assign(document.createElement("a"), { href: `/series.php?id=${group.SeriesID}`, innerText: group.SeriesName })
    ])).values();
    div.appendChild(document.createElement("div")).append(h, ...links);
  }
  if (!(mainTitleMatch || jpTitleMatches.length || altTitleMatches.length)) return true;
  div.appendChild(document.createElement("div")).append(
    "If you require assistance merging a series you can ",
    Object.assign(document.createElement("a"), { href: "/forums.php?action=viewthread&threadid=2965", innerText: "request an edit" }),
    "."
  );
  const { dialog, result } = promptDialog("", div);
  dialog.showModal();
  return await result === "ok";
}
(() => {
  "use strict";
  const newGroup = window.location.pathname === "/upload.php" && window.location.search === "";
  for (const eventType of ["dragover", "drop"]) {
    document.addEventListener(eventType, (e) => {
      if (e.dataTransfer?.types.includes("Files")) e.preventDefault();
    });
  }
  ;
  const div = document.createElement("div");
  div.style.marginBottom = "1lh";
  const button = Object.assign(document.createElement("button"), { className: "btn", textContent: "Upload script settings" });
  button.addEventListener("click", () => promptSettings(scriptConfig));
  div.append(button);
  document.querySelector("#dynamic_form")?.before(div);
  const fileInputSel = newGroup ? ".ui-tabs-panel:not([style*='display: none']) > form > #torrent_file input[name='file_input']" : "#torrent_file input[name='file_input']";
  document.addEventListener("drop", (e) => {
    if (!e.dataTransfer?.types.includes("Files")) return;
    if ([...e.dataTransfer.files].find((file) => file.name.split(".").pop() !== "torrent")) return;
    const fileInput = document.querySelector(fileInputSel);
    if (!(fileInput instanceof HTMLInputElement)) return;
    fileInput.files = e.dataTransfer.files;
    fileInput.dispatchEvent(new Event("change"));
  });
  if (newGroup) {
    addMultifileInput();
    if (getSetting(scriptConfig, "checkDupes")) for (const form of document.querySelectorAll("#dynamic_form > div:not(#packs,#music,#pvs) > .upload_forms")) {
      const virt = Object.assign(document.createElement("button"), { type: "submit", hidden: true });
      form.append(virt);
      form.addEventListener("submit", async (e) => {
        if (e.submitter === virt || !e.isTrusted) return;
        if (!(form instanceof HTMLFormElement)) return;
        e.preventDefault();
        const names = new FormData(form).getAll("series_name[]").filter((entry) => typeof entry === "string");
        const proceed = await checkDupe(names[0], names[1], "anime").catch(() => false);
        if (proceed) form.requestSubmit(virt);
      });
    }
    ;
  }
})();
(() => {
  "use strict";
  const category = "manga";
  const root = document.querySelector("#manga");
  if (!(root instanceof HTMLDivElement)) return;
  root.querySelector("input#file_input_manga")?.addEventListener("change", (e) => {
    if (!(e.target instanceof HTMLInputElement && e.target.files)) return;
    const releaseGroupName = root.querySelector("input#release_group_name");
    const releaseGroupDiv = root.querySelector("div#release_group_manga");
    const translatedStatus = root.querySelector("input#scanlation");
    const name4 = e.target.files.item(0)?.name ?? "";
    if (/\[.*?\](\.\w+)?.torrent$/.test(name4) && releaseGroupName instanceof HTMLInputElement && releaseGroupDiv instanceof HTMLDivElement && translatedStatus instanceof HTMLInputElement) {
      const provider = root.querySelector(".pine-multi-file-container > select");
      if (provider?.value) root.querySelector(`#${provider.value}-autofill-${category}`).value = name4.replace(/\s*\[.*?\](\.torrent)?$/, "");
      if (!getSetting(scriptConfig, "autofillScanlated")) return;
      translatedStatus.checked = true;
      releaseGroupDiv.style.display = "";
      releaseGroupName.value = name4.match(/\[(.*?)\](?:\.\w+)?\.torrent$/)?.[1] ?? releaseGroupName.value;
    }
  });
  const mangaFillRoot = root.querySelector("#manga_form > #autofill > dl.box.pad");
  if (!(mangaFillRoot instanceof HTMLDListElement)) return;
  if (getSetting(scriptConfig, "hideExistingAutofill") && mangaFillRoot.children.length) {
    for (const child of mangaFillRoot.children) child.style.display = "none";
  }
  const mdex = addInput({
    root: mangaFillRoot,
    titleOpts: { textContent: "MangaDex Autofill" },
    inputDef: { fill: { id: `mangadex-autofill-${category}` } },
    buttonDef: { autofill: { textContent: "Autofill!" }, search: { textContent: "Search" } }
  });
  mdex.buttons.autofill.addEventListener("click", () => fillMdexData(mdex.inputs.fill.value));
  mdex.buttons.search.addEventListener(
    "click",
    async () => {
      const results = await searchMdex(mdex.inputs.fill.value);
      const id = await promptSearchResults("MangaDex Results", results, mdexMapper);
      if (id) void fillMdexData(id);
    }
  );
  const mu = addInput({
    root: mangaFillRoot,
    titleOpts: { textContent: "MangaUpdates Autofill" },
    inputDef: { fill: { id: `mangaupdates-autofill-${category}` } },
    buttonDef: { autofill: { textContent: "Autofill!" }, search: { textContent: "Search" } }
  });
  mu.buttons.autofill.addEventListener("click", () => fillMUData(mu.inputs.fill.value));
  mu.buttons.search.addEventListener(
    "click",
    async () => {
      const results = await searchMU(mu.inputs.fill.value, muCategoryMap[category]);
      const id = await promptSearchResults("MangaUpdates Results", results, muMapper);
      if (id) void fillMUData(id);
    }
  );
  const mal = addInput({
    root: mangaFillRoot,
    titleOpts: { textContent: "MyAnimeList Autofill" },
    inputDef: { fill: { id: `myanimelist-autofill-${category}` } },
    buttonDef: { autofill: { textContent: "Autofill!" }, search: { textContent: "Search" } }
  });
  mal.buttons.autofill.addEventListener("click", () => fillMALData(mal.inputs.fill.value));
  mal.buttons.search.addEventListener("click", async () => {
    const results = await searchMALPrinted({ title: mal.inputs.fill.value, types: malPrintedCategoryMap[category] });
    const id = await promptSearchResults("MyAnimeList Results", results, malPrintedMapper);
    if (id) void fillMALData(id);
  });
})();
(() => {
  const category = "light_novels";
  const root = document.querySelector("#light_novels");
  if (!(root instanceof HTMLDivElement)) return;
  root.querySelector("input#file_input_light_novels")?.addEventListener("change", (e) => {
    if (!(e.target instanceof HTMLInputElement && e.target.files)) return;
    const releaseGroupName = root.querySelector("input#release_group_name");
    const releaseGroupDiv = root.querySelector("div#release_group_light_novels");
    const translatedStatus = root.querySelector("input#scanlation");
    const name4 = e.target.files.item(0)?.name ?? "";
    if (/\[.*?\](\.\w+)?.torrent$/.test(name4) && releaseGroupName instanceof HTMLInputElement && releaseGroupDiv instanceof HTMLDivElement && translatedStatus instanceof HTMLInputElement) {
      if (!getSetting(scriptConfig, "autofillScanlated")) return;
      translatedStatus.checked = true;
      releaseGroupDiv.style.display = "";
      releaseGroupName.value = name4.match(/\[(.*?)\](?:\.\w+)?\.torrent$/)?.[1] ?? releaseGroupName.value;
    }
  });
  const lnFillRoot = root.querySelector("#light_novels_form > #autofill > dl.box.pad");
  if (!(lnFillRoot instanceof HTMLDListElement)) return;
  if (lnFillRoot.children.length) for (const child of lnFillRoot.children) child.style.display = "none";
  const mu = addInput({
    root: lnFillRoot,
    titleOpts: { textContent: "MangaUpdates Autofill" },
    inputDef: { fill: { id: `mangaupdates-autofill-${category}` } },
    buttonDef: { autofill: { textContent: "Autofill!" }, search: { textContent: "Search" } }
  });
  mu.buttons.autofill.addEventListener("click", () => getMUData(mu.inputs.fill.value).then((res) => fillLNData(res)));
  mu.buttons.search.addEventListener(
    "click",
    async () => {
      const results = await searchMU(mu.inputs.fill.value, muCategoryMap[category]);
      const id = await promptSearchResults("MangaUpdates Results", results, muMapper);
      if (id) fillLNData(await getMUData(id));
    }
  );
  const mal = addInput({
    root: lnFillRoot,
    titleOpts: { textContent: "MyAnimeList Autofill" },
    inputDef: { fill: { id: `myanimelist-autofill-${category}` } },
    buttonDef: { autofill: { textContent: "Autofill!" }, search: { textContent: "Search" } }
  });
  mal.buttons.autofill.addEventListener("click", () => getMALPrinted(mal.inputs.fill.value).then((res) => fillLNData(res)));
  mal.buttons.search.addEventListener(
    "click",
    async () => {
      const results = await searchMALPrinted({ title: mal.inputs.fill.value, types: malPrintedCategoryMap[category] });
      const id = await promptSearchResults("MyAnimeList Results", results, malPrintedMapper);
      if (id) fillLNData(await getMALPrinted(id));
    }
  );
})();
