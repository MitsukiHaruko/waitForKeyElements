// ==UserScript==
// @name        AB - Enhanced Torrent View
// @namespace   AnimeBytes Nightly
// @description Shows required seeding time; allows sorting and filtering of torrent tables;
// @include     http*://animebytes.tv*
// @exclude      https://animebytes.tv/bookmarks.php
// @version     1.09
// @grant       GM_getValue
// @grant       GM_setValue
// @icon        http://animebytes.tv/favicon.ico
// @require     https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.8.23/dayjs.min.js
// @require     https://cdnjs.cloudflare.com/ajax/libs/dayjs/1.8.23/plugin/customParseFormat.js
// @require     https://github.com/momentary0/AB-Userscripts/raw/master/delicious-library/src/ab_delicious_library.js
// ==/UserScript==

(function EnhancedTorrentView() {
    // ──────────────────────────────────────────────────────────────
    // SETTINGS
    // ──────────────────────────────────────────────────────────────
    const settingsKeys = ['ABTorrentsReqTime', 'ABSortTorrents', 'ABTorrentsFilter', 'ABHistDynLoad'];
    settingsKeys.forEach(key => delicious.settings.init(key, true));

    if (delicious.settings.ensureSettingsInserted()) {
        const section = delicious.settings.createCollapsibleSection('Enhanced Torrent View');
        const body = section.querySelector('.settings_section_body');

        body.appendChild(delicious.settings.createCheckbox(
            'ABTorrentsReqTime',
            'Show required seeding time',
            'Shows minimal required seeding time for torrents in their description and when size is hovered.'
        ));
        body.appendChild(delicious.settings.createCheckbox(
            'ABSortTorrents',
            'Sort torrents',
            'Allows torrent tables to be sorted.'
        ));
        body.appendChild(delicious.settings.createCheckbox(
            'ABTorrentsFilter',
            'Filter torrents',
            'Shows a box above torrent tables to filter by tags.'
        ));
        body.appendChild(delicious.settings.createCheckbox(
            'ABHistDynLoad',
            'Dynamic history tables',
            'Dynamically load more pages into the transfer history page.'
        ));

        delicious.settings.insertSection(section);
    }

    // ──────────────────────────────────────────────────────────────
    // CONFIG
    // ──────────────────────────────────────────────────────────────
    const show_required_time = GM_getValue('ABTorrentsReqTime', 'true') === 'true';
    const sort_rows          = GM_getValue('ABSortTorrents', 'true') === 'true';
    const filter_torrents    = GM_getValue('ABTorrentsFilter', 'true') === 'true';
    const dynamic_load       = GM_getValue('ABHistDynLoad', 'true') === 'true';

    const days_per_year = 365.256363;

    // ──────────────────────────────────────────────────────────────
    // REGEX & PARSING
    // ──────────────────────────────────────────────────────────────
    const size_RegExp      = /^([\d\.]+)\s(?:([a-zA-Z])i)?B(?:\s\(([\d\.]+)%\))?$/;
    const ratio_RegExp     = /^(∞|\-\-|[\d\.]+)$/;
    const and_RegExp       = /(and|\s)/ig;
    const duration_RegExp  = /^(?:(\d+)years?)?(?:(\d+)months?)?(?:(\d+)weeks?)?(?:(\d+)days?)?(?:(\d+)hours?)?(?:(\d+)minutes?)?(?:(\d+)seconds?)?(?:ago)?(?:\s*\([^)]*\)\s*)*$/;
    const datetime_RegExp  = /^(\d+)\-(\d{1,2})\-(\d{1,2})\s+(\d{1,2}):(\d{1,2})$/;
    const abs_datetime_RegExp = /^([a-z]{3}) (\d{2}) (\d{4}) (\d{2}:\d{2}) [a-z]+$/i;
    const monthNumbers = {Jan:1,Feb:2,Mar:3,Apr:4,May:5,Jun:6,Jul:7,Aug:8,Sep:9,Oct:10,Nov:11,Dec:12};

    function unit_prefix(p) {
        if (p === undefined) return 1/1073741824;
        switch (p.toUpperCase()) {
            case '': return 1/1073741824;
            case 'K': return 1/1048576;
            case 'M': return 1/1024;
            case 'G': return 1;
            case 'T': return 1024;
            case 'P': return 1048576;
            case 'E': return 1073741824;
            default: return 0;
        }
    }

    // ──────────────────────────────────────────────────────────────
    // UTILITIES
    // ──────────────────────────────────────────────────────────────
    function get_column(row, cell) {
        let col = 0;
        for (let c of row.cells) {
            if (c === cell) break;
            col += c.colSpan;
        }
        return col;
    }

    function get_cell(row, idx) {
        let col = 0;
        for (let c of row.cells) {
            if (col === idx) return c;
            col += c.colSpan;
        }
        return null;
    }

    function get_next_separator_element_sibling(row) {
        while (row && !row.id.startsWith('group_') && !row.classList.contains('edition_info')) {
            row = row.nextElementSibling;
        }
        return row;
    }

    function get_corresponding_torrent_row(row) {
        const a = row.querySelector('a[href*="/download/"]');
        if (!a) return null;
        const m = a.href.match(/torrent\/(\d+)\/download/i);
        if (!m) return null;
        const tr = document.getElementById('torrent_' + m[1]);
        return tr && tr !== row ? tr : null;
    }

    function duration_to_string(hours) {
        const days = Math.floor(hours / 24);
        const hrs  = Math.floor(hours % 24);
        const mins = Math.ceil((hours * 60) % 60);
        let s = `${days} days`;
        if (hrs > 0)  s += mins === 0 ? ' and ' : ', ';
        if (hrs > 0)  s += `${hrs} hours`;
        if (mins > 0) s += ` and ${mins} minutes`;
        return s;
    }

    // ──────────────────────────────────────────────────────────────
    // CELL PARSING
    // ──────────────────────────────────────────────────────────────
    function parse_cell(cell) {
        const txt = cell.textContent.trim();
        const txtNoComma = txt.replace(/,/g, '').trim();
        const img = cell.querySelector('img');
        const span = cell.querySelector('span[title]');

        if (txt === '' && img) return img.alt.toUpperCase();

        let m = txtNoComma.match(size_RegExp);
        if (m) return parseFloat(m[1]) * unit_prefix(m[2]);

        m = txtNoComma.match(datetime_RegExp);
        if (m) return new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5]);

        m = txtNoComma.match(abs_datetime_RegExp);
        if (m) {
            const month = String(monthNumbers[m[1]]).padStart(2,'0');
            return Date.parse(`${m[3]}-${month}-${m[2]}T${m[4]}:00`);
        }

        m = txtNoComma.replace(and_RegExp, '').match(duration_RegExp);
        if (m) {
            const d = [];
            for (let i=1; i<m.length; i++) d.push(m[i] ? +m[i] : 0);
            return 24*(d[0]*days_per_year + d[1]*days_per_year/12 + d[2]*7 + d[3]) + d[4] + d[5]/60 + d[6]/3600;
        }

        m = txtNoComma.match(ratio_RegExp);
        if (m) {
            switch (m[1]) {
                case '∞': return Infinity;
                case '--': return -0.2;
                case '0': return -0.1;
                default: return parseFloat(m[1]);
            }
        }

        return /^Never(\s*\([^)]*\)\s*)*$/i.test(txtNoComma) ? 0 : txt.toUpperCase();
    }

    // ──────────────────────────────────────────────────────────────
    // ROW PROCESSING
    // ──────────────────────────────────────────────────────────────
    function parse_row(row, size_index, duration_index, hr_index) {
        const size_cell = size_index !== null ? get_cell(row, size_index) : null;
        const dur_cell  = duration_index !== null ? get_cell(row, duration_index) : null;
        const size = size_cell ? parse_cell(size_cell) : 1;
        const torrent_row = get_corresponding_torrent_row(row);

        // ─── REQUIRED SEEDING TIME (BACK!) ───
        if (size_index !== null && show_required_time) {
            let req = Math.max(0, size - 10) * 5 + 72;
            req = Math.min(21 * 24, req); // cap at 21 days
            const txt = duration_to_string(req);

            // Hover on size
            if (size_cell) {
                size_cell.title = `You need to seed this torrent for at least\n${txt}\nor it will become a hit and run!`;
            }

            // In torrent description
            if (torrent_row) {
                const bq = torrent_row.querySelector('blockquote');
                if (bq) {
                    bq.appendChild(document.createElement('br'));
                    bq.innerHTML += `You need to seed this torrent for at least <span class="r01">${txt}</span> or it will become a hit and run!`;
                }
            }
        }

        // Build row data for sorting
        const data = [row, torrent_row];
        if (sort_rows) {
            for (let c of row.cells) {
                data.push(parse_cell(c));
                if (c.colSpan > 1) {
                    for (let i = 2; i <= c.colSpan; i++) data.push(null);
                }
            }
        }

        // H&R remaining time
        if (hr_index !== null && duration_index !== null) {
            const cell = get_cell(row, duration_index);
            const m = cell.textContent.replace(/^[^(]*(\(|$)/, '').replace(/\s*left\s*\)[^)]*$/, '').replace(and_RegExp, '').match(duration_RegExp);
            let rem = '0.0000';
            if (m) {
                const d = [];
                for (let i=1; i<m.length; i++) d.push(m[i] ? +m[i] : 0);
                rem = (24*(d[0]*days_per_year + d[1]*days_per_year/12 + d[2]*7 + d[3]) + d[4] + d[5]/60 + d[6]/3600).toFixed(4);
            }
            while (rem.length < 16) rem = '0' + rem;
            data[hr_index + 2] = rem + data[hr_index + 2];
        }

        return data;
    }

    // ──────────────────────────────────────────────────────────────
    // TABLE PROCESSING
    // ──────────────────────────────────────────────────────────────
    function parse_table(table) {
        const headerRow = table.querySelector('tr');
        const cells = headerRow.cells;

        let size_idx = null, dur_idx = null, hr_idx = null;
        let col = 0;
        for (let c of cells) {
            const txt = c.textContent.replace(/\u00a0/g, ' ').trim().toLowerCase();
            const title = c.title.trim().toLowerCase();
            if (size_idx === null && (txt === 'size' || title === 'size' || c.querySelector('*[title="Size"]'))) size_idx = col;
            if (dur_idx === null && (txt === 'seeding time' || txt === 'seed time')) dur_idx = col;
            if (hr_idx === null && txt === 'h&r') hr_idx = col;
            col += c.colSpan;
        }

        const torrents = table.querySelectorAll('tr.torrent, tr.group_torrent');
        const table_data = [];
        for (let r of torrents) {
            table_data.push(parse_row(r, size_idx, dur_idx, hr_idx));
        }

        // ───── SORTING (icon or text clickable) ─────
        if (sort_rows && table_data.length > 1) {
            let curCol = null, curAsc = true;

            const sorter = idx => (a,b) => {
                const A = a[idx+2], B = b[idx+2];
                if (A===null && B===null) return 0;
                if (A===null) return 1;
                if (B===null) return -1;
                return A > B ? 1 : A < B ? -1 : 0;
            };

            const apply = (col, asc) => {
                curCol = col; curAsc = asc;
                table_data.sort(sorter(col));
                if (!asc) table_data.reverse();

                const tbody = table_data[0][0].parentNode;
                for (const r of table_data) {
                    const sep = get_next_separator_element_sibling(r[0]);
                    if (sep) {
                        tbody.insertBefore(r[0], sep);
                        if (r[1]) tbody.insertBefore(r[1], sep);
                    } else {
                        tbody.appendChild(r[0]);
                        if (r[1] && r[0] !== r[1]) tbody.appendChild(r[1]);
                    }
                }

                // Reset
                headerRow.querySelectorAll('th').forEach(th => {
                    th.style.backgroundColor = '';
                    th.style.fontWeight = 'normal';
                    const img = th.querySelector('img.sortable-icon');
                    if (img) { img.style.filter = 'brightness(0.7)'; img.style.opacity = '0.7'; }
                });

                // Active
                const active = headerRow.cells[col];
                if (active) {
                    active.style.backgroundColor = asc ? '#e6f7e6' : '#fce8e8';
                    active.style.fontWeight = 'bold';
                    const img = active.querySelector('img.sortable-icon');
                    if (img) {
                        img.style.filter = asc
                            ? 'hue-rotate(90deg) brightness(1.4)'
                            : 'hue-rotate(-60deg) brightness(1.4)';
                        img.style.opacity = '1';
                    }
                }
            };

            for (let i=0; i<cells.length; i++) {
                const th = cells[i];
                const idx = get_column(headerRow, th);
                const img = th.querySelector('img');

                th.style.cursor = 'pointer';
                th.title = 'Click to sort by this column';
                th.style.userSelect = 'none';

                if (img) {
                    img.classList.add('sortable-icon');
                    img.style.transition = 'all .2s ease';
                    img.style.opacity = '0.7';
                    img.style.filter = 'brightness(0.7)';
                }

                th.addEventListener('click', e => {
                    e.stopPropagation(); e.preventDefault();
                    const asc = (curCol === idx) ? !curAsc : false;
                    apply(idx, asc);
                });

                th.addEventListener('mouseenter', () => {
                    if (curCol !== idx) {
                        th.style.backgroundColor = '#f5f5f5';
                        if (img) { img.style.filter = 'brightness(1.1)'; img.style.opacity = '1'; }
                    }
                });
                th.addEventListener('mouseleave', () => {
                    if (curCol !== idx) {
                        th.style.backgroundColor = '';
                        if (img) { img.style.filter = 'brightness(0.7)'; img.style.opacity = '0.7'; }
                    }
                });
            }

            const style = document.createElement('style');
            style.textContent = `
                table.torrent_table th, table.torrent_group th { transition: background-color .2s, font-weight .1s; }
                img.sortable-icon { transition: filter .2s, opacity .2s; image-rendering:-webkit-optimize-contrast; }
            `;
            document.head.appendChild(style);
        }

        // ───── DYNAMIC HISTORY LOADING ─────
        if (dynamic_load) {
            const urlMatch = document.URL.match(/page=(\d+)/i);
            let curPage = urlMatch ? +urlMatch[1] : 1;
            let prevPage = curPage - 1, nextPage = curPage + 1, lastPage = Infinity;
            const pagenums = [];
            if (table.previousElementSibling) {
                const p = table.previousElementSibling.querySelector('div.pagenums');
                if (p) pagenums.push(p);
            }
            if (table.nextElementSibling) {
                const p = table.nextElementSibling.querySelector('div.pagenums');
                if (p) pagenums.push(p);
            }

            const prevLinks = [], nextLinks = [];

            const loadPage = (prev) => e => {
                if (e) { e.stopPropagation(); e.preventDefault(); }
                const page = prev ? prevPage-- : nextPage++;
                if (page < 1 || page > lastPage) return;

                if (page === 1) prevLinks.forEach(a => a.parentNode && a.parentNode.removeChild(a));
                if (page === lastPage) nextLinks.forEach(a => a.parentNode && a.parentNode.removeChild(a));

                let url = document.URL.split('#')[0];
                url = url.replace(/page=\d+/i, '') + (url.includes('?') ? '&' : '?') + 'page=' + page;

                const xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.send();
                xhr.onreadystatechange = () => {
                    if (xhr.readyState !== 4) return;
                    const doc = new DOMParser().parseFromString(xhr.responseText, 'text/html');
                    const newRows = doc.querySelectorAll('tr.torrent, tr.group_torrent');
                    for (let r of newRows) {
                        table_data.push(parse_row(r, size_idx, dur_idx, hr_idx));
                    }
                    if (curCol !== null) apply(curCol, curAsc);
                };
            };

            pagenums.forEach(pn => {
                const last = pn.lastElementChild;
                if (last && last.href) {
                    const m = last.href.match(/page=(\d+)/i);
                    lastPage = m ? +m[1] : 1;
                } else {
                    lastPage = parseInt(last.textContent.trim(), 10) || 1;
                }

                const clone = pn.parentNode.cloneNode(true);
                const newPn = clone.querySelector('div.pagenums');
                newPn.innerHTML = '';

                if (curPage > 1) {
                    const a = document.createElement('a');
                    a.href = '#'; a.className = 'next-prev';
                    a.textContent = 'Load previous page dynamically';
                    a.addEventListener('click', loadPage(true), true);
                    newPn.appendChild(a);
                    prevLinks.push(a);
                }
                if (curPage < lastPage) {
                    const a = document.createElement('a');
                    a.href = '#'; a.className = 'next-prev';
                    a.textContent = 'Load next page dynamically';
                    a.addEventListener('click', loadPage(false), true);
                    newPn.appendChild(a);
                    nextLinks.push(a);
                }

                pn.parentNode.parentNode.insertBefore(clone, pn.parentNode.nextSibling);
            });
        }

        // ───── FILTER BOX ─────
        if (filter_torrents && torrents.length > 1) {
            const box = document.createElement('div');
            const head = document.createElement('div');
            const body = document.createElement('div');
            box.className = 'box torrent_filter_box';
            box.style.width = '100%'; box.style.float = 'left'; box.style.marginBottom = '10px';
            head.className = 'head colhead strong';
            body.className = 'body pad'; body.style.display = 'none';
            head.innerHTML = '<a href="#"><span class="triangle-right-md"><span class="stext">+/-</span></span> Filter </a>';

            head.addEventListener('click', e => {
                if (e) { e.stopPropagation(); e.preventDefault(); }
                const span = head.querySelector('span');
                if (body.style.display !== 'none') {
                    body.style.display = 'none';
                    span.className = 'triangle-right-md';
                } else {
                    filter_table(body);
                    body.style.display = '';
                    span.className = 'triangle-down-md';
                }
            });

            box.appendChild(head); box.appendChild(body);
            table.parentNode.insertBefore(box, table);
        }

        function filter_table(container) {
            const deselected = {};
            if (container.hasChildNodes()) {
                container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                    if (!cb.checked) deselected[cb.value] = true;
                });
            }

            const newForm = document.createElement('form');
            const tags = {}, colVals = [];
            let dual = 0, fl = 0, rem = 0;

            for (let t of torrents) {
                const free = /freeleech/.test(t.className) || t.querySelector('img[alt="Freeleech!"]');
                const remas = t.querySelector('img[alt="Remastered"]');
                const dualAudio = /Dual Audio/.test(t.cells[0].lastElementChild.textContent);
                dual |= dualAudio ? 1 : 2;
                fl   |= free ? 1 : 2;
                rem  |= remas ? 1 : 2;
            }

            for (let t of torrents) {
                const corr = get_corresponding_torrent_row(t);
                const free = /freeleech/.test(t.className) || t.querySelector('img[alt="Freeleech!"]');
                const remas = t.querySelector('img[alt="Remastered"]');
                let txt = t.cells[0].lastElementChild.textContent;
                const dualAudio = /Dual Audio/i.test(txt);

                txt = txt.replace(/^\s*»/i, '').replace(/\d+:\d+/g, '').replace(/Dual Audio/ig, '')
                         .replace(/\|(\s*\|)+/g, '|').replace(/^\s*\|/, '').replace(/\|\s*$/, '');
                const parts = txt.includes('|') ? txt.split('|') : txt.split('/');
                const torrentTags = parts.map(s => s.trim());

                if (dual === 3) torrentTags.push(dualAudio ? 'Dual Audio' : 'No Dual Audio');
                if (fl === 3)   torrentTags.push(free ? 'Freeleech' : 'No Freeleech');
                if (rem === 3)  torrentTags.push(remas ? 'Remastered' : 'Not Remastered');

                let hide = false;
                for (const tag of torrentTags) if (deselected[tag]) { hide = true; break; }
                for (const tag of torrentTags) {
                    if (tag === '') continue;
                    if (!tags[tag]) tags[tag] = 0;
                    if (!hide) tags[tag] = 1;
                    while (colVals.length <= torrentTags.indexOf(tag)) colVals.push({});
                    if (!colVals[torrentTags.indexOf(tag)][tag]) colVals[torrentTags.indexOf(tag)][tag] = 1;
                }

                t.style.display = hide ? 'none' : '';
                if (corr) corr.style.display = hide ? 'none' : '';
            }

            if (colVals.length || Object.keys(deselected).length) {
                const shown = {};
                for (const col of colVals) {
                    const sorted = Object.keys(col).sort((a,b) => a.localeCompare(b));
                    for (const tag of sorted) {
                        if (shown[tag]) continue;
                        shown[tag] = 1;
                        const lbl = document.createElement('label');
                        lbl.innerHTML = `<input type="checkbox" ${deselected[tag]?'':'checked'} value="${tag}"> ${tag}`;
                        lbl.style.marginRight = '1em'; lbl.style.display = 'inline-block';
                        if (tags[tag] === 0 && !deselected[tag]) lbl.style.opacity = '0.25';
                        if (sorted.length <= 1) lbl.style.opacity = '0.5';
                        newForm.appendChild(lbl);
                    }
                    newForm.appendChild(document.createElement('hr'));
                }
                while (newForm.lastElementChild && newForm.lastElementChild.tagName === 'HR')
                    newForm.removeChild(newForm.lastChild);

                newForm.addEventListener('change', () => filter_table(container));
                if (container.hasChildNodes()) container.replaceChild(newForm, container.firstChild);
                else container.appendChild(newForm);
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // MAIN
    // ──────────────────────────────────────────────────────────────
    if (show_required_time || sort_rows || filter_torrents || dynamic_load) {
        document.querySelectorAll('table.torrent_table, table.torrent_group').forEach(parse_table);
    }
}).call(this);