// ==UserScript==
// @name         AB - Highlight Non-Zero Leeches
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.0
// @description  Highlight non-zero seeders in red
// @match        *://animebytes.tv/torrents*
// @icon         https://animebytes.tv/favicon.ico
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  // 1. Inject CSS
  const style = document.createElement('style');
  style.textContent = `
    tr.group_torrent td.non-zero-cell {
      color: #b82625 !important;
    }
  `;
  document.head.appendChild(style);

  // 2. Wait for the DOM and check cells
  function highlightNonZeroCells() {
    document.querySelectorAll('tr.group_torrent').forEach(row => {
      const cell = row.querySelector('td:nth-child(5)');
      if (cell && cell.textContent.trim() !== '0') {
        cell.classList.add('non-zero-cell');
      }
    });
  }

  // Run immediately if DOM is ready, or wait for load
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    highlightNonZeroCells();
  } else {
    document.addEventListener('DOMContentLoaded', highlightNonZeroCells);
  }
})();
