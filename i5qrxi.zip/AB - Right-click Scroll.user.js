// ==UserScript==
// @name         AB - Right-click Scroll
// @author       Mitsuki Haruko
// @namespace    AnimeBytes Nightly
// @version      1.0
// @description  Smooth velocity-based right-click scrolling with acceleration and modal targeting, toggleable in settings under General
// @match        *://animebytes.tv/*
// @match        *://animebytes.tv/user.php?action=edit*
// @icon         https://animebytes.tv/favicon.ico
// @require      https://raw.githubusercontent.com/momentary0/AB-Userscripts/b1e7aac27e1f49391147cf068326f278bb40e20d/delicious-library/src/ab_delicious_library.js
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    const listenerOptions = { capture: false, passive: false };

    // Settings-related functions
    function insertSettingsUi() {
        if (!delicious.settings.ensureSettingsInserted()) {
            console.warn('Failed to insert settings UI: delicious library not ready');
            return;
        }

        // Check if General section already exists
        let section = document.querySelector('[data-section-id="general-settings"]');
        let s;
        if (!section) {
            section = delicious.settings.createCollapsibleSection('General');
            section.setAttribute('data-section-id', 'general-settings');
            s = section.querySelector('.settings_section_body');
            // Prepend the General section to ensure it's first
            const settingsContainer = document.querySelector('#user_edit > .settings_section');
            if (settingsContainer) {
                settingsContainer.insertBefore(section, settingsContainer.firstChild);
            } else {
                delicious.settings.insertSection(section);
            }
        } else {
            s = section.querySelector('.settings_section_body');
        }

        const initial = GM_getValue('rightClickScrollEnabled', true);
        console.log('Initial rightClickScrollEnabled:', initial);

        // Create custom checkbox
        const checkboxContainer = document.createElement('div');
        checkboxContainer.style.margin = '10px 0';
        const input = document.createElement('input');
        input.type = 'checkbox';
        input.id = 'rightClickScrollEnabled';
        input.checked = initial;
        const label = document.createElement('label');
        label.htmlFor = 'rightClickScrollEnabled';
        label.style.marginLeft = '5px';
        label.textContent = 'Enable Right-Click Scroll';
        const description = document.createElement('div');
        description.style.fontSize = '0.9em';
        description.style.color = '#666';
        description.textContent = 'Toggle smooth velocity-based right-click scrolling with acceleration on the main page and comment modal.';
        checkboxContainer.appendChild(input);
        checkboxContainer.appendChild(label);
        checkboxContainer.appendChild(description);
        s.appendChild(checkboxContainer);

        console.log('Custom checkbox set to:', input.checked);

        // Monitor checkbox for unexpected changes
        const observer = new MutationObserver(() => {
            const storedValue = GM_getValue('rightClickScrollEnabled', true);
            if (input.checked !== storedValue) {
                console.warn('Checkbox state changed unexpectedly to:', input.checked, 'Correcting to:', storedValue);
                input.checked = storedValue;
            }
        });
        observer.observe(input, { attributes: true, attributeFilter: ['checked'] });

        input.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            GM_setValue('rightClickScrollEnabled', enabled);
            console.log('Checkbox changed, rightClickScrollEnabled set to:', enabled, 'Stored value:', GM_getValue('rightClickScrollEnabled'));
            updateEventListeners(enabled);
        });

        // Handle form submission
        const settingsForm = document.querySelector('form');
        if (settingsForm) {
            settingsForm.addEventListener('submit', (e) => {
                const enabled = input.checked;
                GM_setValue('rightClickScrollEnabled', enabled);
                console.log('Form submitted, rightClickScrollEnabled set to:', enabled, 'Stored value:', GM_getValue('rightClickScrollEnabled'));
                updateEventListeners(enabled);
            });
        }

        // Handle save button click as a fallback
        const saveButton = document.querySelector('input[type="submit"][value="Save Settings"]');
        if (saveButton) {
            saveButton.addEventListener('click', (e) => {
                const enabled = input.checked;
                GM_setValue('rightClickScrollEnabled', enabled);
                console.log('Save button clicked, rightClickScrollEnabled set to:', enabled, 'Stored value:', GM_getValue('rightClickScrollEnabled'));
                updateEventListeners(enabled);
            });
        }

        // Insert section if not already inserted
        if (!section.parentElement) {
            delicious.settings.insertSection(section);
        }

        console.log('Inserted General settings UI');

        // Dispatch event to notify other scripts that General section is ready
        const event = new CustomEvent('generalSettingsReady', {
            detail: { sectionId: 'general-settings' }
        });
        document.dispatchEvent(event);

        // Ensure checkbox state is correct after insertion
        setTimeout(() => {
            const storedValue = GM_getValue('rightClickScrollEnabled', true);
            if (input.checked !== storedValue) {
                console.warn('Post-insertion checkbox state mismatch, set to:', storedValue);
                input.checked = storedValue;
            } else {
                console.log('Post-insertion checkbox state correct:', storedValue);
            }
        }, 100);
    }

    let isRightMouseDown = false;
    let lastX = 0;
    let lastY = 0;
    let lastTime = 0;
    let velocityX = 0;
    let velocityY = 0;

    const SMOOTHING_FACTOR = 0.15;
    const BASE_SCALE = 0.05;
    const ACCEL_SCALE = 0.00025;
    const MOVEMENT_THRESHOLD = 0.5;

    function blockContextMenu(e) {
        if (GM_getValue('rightClickScrollEnabled', true)) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
        }
    }

    function getScrollTarget(x, y) {
        const modal = document.querySelector('.comments-modal');
        if (modal && getComputedStyle(modal).display !== 'none') return modal;

        if (window.ABCommentsModal && window.ABCommentsModal.style.display === 'block') return window.ABCommentsModal;

        if (typeof window.ABCommentsModalForceFocus === 'function') {
            const forced = window.ABCommentsModalForceFocus();
            if (forced) return forced;
        }

        const hovered = document.elementFromPoint(x, y);
        if (modal && modal.contains(hovered)) return modal;

        return window;
    }

    function handleMouseDown(e) {
        if (e.button === 2 && GM_getValue('rightClickScrollEnabled', true)) {
            isRightMouseDown = true;
            lastX = e.clientX;
            lastY = e.clientY;
            lastTime = performance.now();
            velocityX = 0;
            velocityY = 0;
            e.preventDefault();
        }
    }

    function handleMouseUp(e) {
        if (e.button === 2) {
            isRightMouseDown = false;
            velocityX = 0;
            velocityY = 0;
            e.preventDefault();
        }
    }

    function handleMouseMove(e) {
        if (!isRightMouseDown || !GM_getValue('rightClickScrollEnabled', true)) return;

        const now = performance.now();
        const dt = (now - lastTime) / 1000;
        if (dt === 0) return;

        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;

        const accelX = dx / dt;
        const accelY = dy / dt;

        velocityX += SMOOTHING_FACTOR * (accelX - velocityX);
        velocityY += SMOOTHING_FACTOR * (accelY - velocityY);

        const scale = BASE_SCALE + ACCEL_SCALE * (Math.abs(accelX) + Math.abs(accelY));
        const scrollX = velocityX * scale;
        const scrollY = velocityY * scale;

        const scrollTarget = getScrollTarget(e.clientX, e.clientY);

        if (Math.abs(scrollX) > MOVEMENT_THRESHOLD || Math.abs(scrollY) > MOVEMENT_THRESHOLD) {
            if (scrollTarget === window) {
                window.scrollBy({ left: scrollX, top: scrollY, behavior: 'auto' });
            } else {
                scrollTarget.scrollBy({ left: scrollX, top: scrollY });
            }
        }

        lastX = e.clientX;
        lastY = e.clientY;
        lastTime = now;

        e.preventDefault();
    }

    function handleSelectStart(e) {
        if (isRightMouseDown && GM_getValue('rightClickScrollEnabled', true)) {
            e.preventDefault();
        }
    }

    function updateEventListeners(forceEnabled) {
        const enabled = typeof forceEnabled === 'boolean'
            ? forceEnabled
            : GM_getValue('rightClickScrollEnabled', true);

        console.log('Updating event listeners, enabled:', enabled, 'Stored value:', GM_getValue('rightClickScrollEnabled'));

        document.removeEventListener('contextmenu', blockContextMenu, listenerOptions);
        document.removeEventListener('mousedown', handleMouseDown, listenerOptions);
        document.removeEventListener('mouseup', handleMouseUp, listenerOptions);
        document.removeEventListener('mousemove', handleMouseMove, listenerOptions);
        document.removeEventListener('selectstart', handleSelectStart, listenerOptions);

        if (enabled) {
            document.addEventListener('contextmenu', blockContextMenu, listenerOptions);
            document.addEventListener('mousedown', handleMouseDown, listenerOptions);
            document.addEventListener('mouseup', handleMouseUp, listenerOptions);
            document.addEventListener('mousemove', handleMouseMove, listenerOptions);
            document.addEventListener('selectstart', handleSelectStart, listenerOptions);
        }
    }

    function init() {
        const isSettingsPage = window.location.pathname === '/user.php' && new URLSearchParams(window.location.search).get('action') === 'edit';

        // Initialize event listeners with current setting
        const enabled = GM_getValue('rightClickScrollEnabled', true);
        console.log('Initializing with rightClickScrollEnabled:', enabled, 'Stored value:', GM_getValue('rightClickScrollEnabled'));
        updateEventListeners(enabled);

        if (isSettingsPage) {
            insertSettingsUi();
        }

        const observer = new MutationObserver(() => {
            const modal = document.querySelector('.comments-modal');
            if (modal && getComputedStyle(modal).display !== 'none') {
                updateEventListeners(GM_getValue('rightClickScrollEnabled', true));
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    if (typeof GM_getValue === 'undefined' || typeof GM_setValue === 'undefined') {
        console.error('GM_getValue or GM_setValue not available. Please run this script in a userscript manager like Tampermonkey.');
        return;
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();