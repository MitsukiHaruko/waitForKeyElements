// ==UserScript==
// @name         AB - Home page
// @namespace    AnimeBytes Nightly
// @version      1.2
// @description  Fully customizable homepage: hide AotW, AotF, Last Uploads, replace news, style collages
// @author       Mitsuki Haruko
// @match        https://animebytes.tv/
// @match        *://animebytes.tv/user.php?action=edit*
// @require      https://raw.githubusercontent.com/momentary0/AB-Userscripts/b1e7aac27e1f49391147cf068326f278bb40e20d/delicious-library/src/ab_delicious_library.js
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-end
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

(function() {
    'use strict';

    // Always-active CSS
    GM_addStyle(`
        #COLLAGE_TABLE img, #collage_table img {
            width: 138px !important;
            height: 209px !important;
            filter: brightness(80%) !important;
        }

        #COLLAGE_TABLE img:hover, #collage_table img:hover {
            filter: brightness(100%) !important;
        }

        #rutCarousel {
            display: block !important;
            width: 840px;
        }

        .next, .prev {
        scale: 70% !important;
        }

        #cover-slider {
            width: 800px !important;
        }

        #cover-slider .slider {
            width: 700px !important;
        }

        /* Optional: Force hide class (more reliable than display) */
        #rutCarousel.hide-by-userscript {
            display: none !important;
        }
    `);

    // Conditional CSS for news replacement
    const newsReplacementStyles = `
        .fpright { margin-right: -100px; }
        .news_entry { margin-left: -100px; }
    `;

    function manageNewsStyles(enabled) {
        const styleId = 'news-replacement-styles';
        const existing = document.getElementById(styleId);
        if (existing) existing.remove();

        if (enabled) {
            GM_addStyle(`
                #${styleId} { display: none; }
                ${newsReplacementStyles}
            `);
            console.log('Applied news replacement styles');
        } else {
            console.log('Removed news replacement styles');
        }
    }

    // Toggle visibility of AotW, AotF, and Last Uploads
    function manageElementVisibility() {
        const aotwHidden = JSON.parse(GM_getValue('aotwEnabled', 'false'));
        const aotfHidden = JSON.parse(GM_getValue('aotfEnabled', 'false'));
        const lastUploadsHidden = JSON.parse(GM_getValue('lastUploadsEnabled', 'false'));

        const aotwEl = document.querySelector('#aotw');
        const aotfEl = document.querySelector('#aotf');
        const carouselEl = document.querySelector('#rutCarousel');

        // AotW
        if (aotwEl) {
            aotwEl.style.display = aotwHidden ? 'none' : '';
            console.log(`#aotw is ${aotwHidden ? 'hidden' : 'visible'}`);
        } else if (aotwHidden) {
            console.warn('#aotw not found (but should be hidden)');
        }

        // AotF
        if (aotfEl) {
            aotfEl.style.display = aotfHidden ? 'none' : '';
            console.log(`#aotf is ${aotfHidden ? 'hidden' : 'visible'}`);
        } else if (aotfHidden) {
            console.warn('#aotf not found (but should be hidden)');
        }

        // Last Uploads Carousel
        if (carouselEl) {
            if (lastUploadsHidden) {
                carouselEl.classList.add('hide-by-userscript');
            } else {
                carouselEl.classList.remove('hide-by-userscript');
            }
            console.log(`#rutCarousel is ${lastUploadsHidden ? 'hidden' : 'visible'}`);
            carouselEl.dataset.visibilityApplied = 'true'; // Mark as processed
        } else if (lastUploadsHidden && !carouselEl?.dataset.visibilityApplied) {
            console.warn('#rutCarousel not found yet (will retry via observer)');
        }
    }

    // Apply image styles
    function applyImageStyles() {
        const selectors = ['#COLLAGE_TABLE', '#collage_table'];
        let total = 0;

        selectors.forEach(sel => {
            const table = document.querySelector(sel);
            if (table) {
                const imgs = table.querySelectorAll('img');
                total += imgs.length;
                console.log(`Found ${imgs.length} images in ${sel}`);
            }
        });

        if (total > 0) {
            console.log(`Styled ${total} collage images (138x209, 80% brightness)`);
        }
    }

    // Observe collage table
    function observeCollageTable() {
        const observer = new MutationObserver(() => {
            if (document.querySelector('#COLLAGE_TABLE, #collage_table')) {
                applyImageStyles();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
        applyImageStyles();

        setTimeout(() => {
            observer.disconnect();
            console.log('Stopped collage observer');
        }, 10000);
    }

    // Observe #rutCarousel (dynamic)
    function observeRutCarousel() {
        const observer = new MutationObserver(() => {
            const carousel = document.querySelector('#rutCarousel');
            if (carousel && !carousel.dataset.visibilityApplied) {
                console.log('#rutCarousel loaded → applying visibility');
                manageElementVisibility();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });

        // Initial check
        if (document.querySelector('#rutCarousel')) {
            manageElementVisibility();
        }

        setTimeout(() => {
            observer.disconnect();
            console.log('Stopped #rutCarousel observer');
        }, 15000);
    }

    // Replace news with airing page
    async function replaceNewsEntry() {
        try {
            const res = await fetch('https://animebytes.tv/airing', { credentials: 'include' });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);

            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const content = doc.querySelector('div.thin:nth-child(3)');
            const target = document.querySelector('.news_entry');

            if (content && target) {
                target.innerHTML = content.innerHTML;
                console.log('News replaced with airing anime');
            }
        } catch (e) {
            console.error('News replacement failed:', e);
        }
    }

    // Settings UI
    function insertSettingsUi() {
        if (!delicious.settings.ensureSettingsInserted()) return;

        const section = delicious.settings.createCollapsibleSection('Home Page');
        const body = section.querySelector('.settings_section_body');

        // News Replacement
        delicious.settings.init('newsReplacementEnabled', true);
        body.appendChild(delicious.settings.createCheckbox(
            'newsReplacementEnabled',
            'News Replacement',
            'Replace news with airing anime images'
        ));

        // Hide AotW
        delicious.settings.init('aotwEnabled', false);
        body.appendChild(delicious.settings.createCheckbox(
            'aotwEnabled',
            'Hide AotW',
            'Hide Anime of the Week section'
        ));

        // Hide AotF
        delicious.settings.init('aotfEnabled', false);
        body.appendChild(delicious.settings.createCheckbox(
            'aotfEnabled',
            'Hide AotF',
            'Hide Anime of the Fortnight section'
        ));

        // Hide Last Uploads
        delicious.settings.init('lastUploadsEnabled', false);
        body.appendChild(delicious.settings.createCheckbox(
            'lastUploadsEnabled',
            'Hide Last Uploads',
            'Hide the "Last Uploads" carousel'
        ));

        delicious.settings.insertSection(section);
        console.log('Settings UI inserted');
    }

    // Main
    function main() {
        applyImageStyles();
        observeCollageTable();
        observeRutCarousel(); // Critical for dynamic #rutCarousel

        if (window.location.pathname === '/user.php' && new URLSearchParams(window.location.search).get('action') === 'edit') {
            insertSettingsUi();
            return;
        }

        const newsEnabled = JSON.parse(GM_getValue('newsReplacementEnabled', 'true'));
        manageNewsStyles(newsEnabled);
        if (newsEnabled) replaceNewsEntry();

        manageElementVisibility(); // Initial pass
    }

    main();
})();