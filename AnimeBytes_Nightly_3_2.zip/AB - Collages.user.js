// ==UserScript==
// @name AB - Collages
// @namespace AnimeBytes Nightly
// @version 0.2.0
// @description Clicking on covers in collages takes you directly to the show page
// @author mitsukiharuko
// @homepage https://animebytes.tv/forums.php?action=viewthread&threadid=25615
// @icon https://animebytes.tv/favicon.ico
// @updateURL https://gist.github.com/po5/5308a84da0faafb1eb2ea38e703c4a1f/raw/comfy-collages.user.js
// @downloadURL https://gist.github.com/po5/5308a84da0faafb1eb2ea38e703c4a1f/raw/comfy-collages.user.js
// @grant none
// @match https://animebytes.tv/collage.php?*
// @license GPL-3.0
// @run-at document-end
// ==/UserScript==

"use strict";

const css = document.createElement("style");
css.type = "text/css";
css.innerHTML = `
    #collage_table td a[href^="#group_"] img {
        cursor: pointer;
        transition: box-shadow 0.2s;
    }
    #collage_table td a[href^="#group_"] img:hover {
        box-shadow: 0 0 0 4px #f00c;
    }
`;
document.head.appendChild(css);

function makeDirectLinks() {
    // Target all collage cover links: <a href="#group_xxx">
    document.querySelectorAll('#collage_table a[href^="#group_"]').forEach(link => {
        const groupIdSelector = link.hash; // e.g. "#group_12345"

        // Find the "View Torrent" / group link inside the hidden/associated torrent row
        const groupLink = document.querySelector(groupIdSelector + ' a[title="View Torrent"]');

        if (groupLink && groupLink.href) {
            // Set the cover link directly to the show/group page
            link.href = groupLink.href;

            // Optional: store original hash if needed for other scripts, but not required here
            link.children[0].setAttribute('data-original-hash', link.hash.replace('#', ''));

            // Remove any old click handlers if present
            const newLink = link.cloneNode(true);
            link.parentNode.replaceChild(newLink, link);
        } else {
            console.warn('Direct link script: Could not find group link for', groupIdSelector);
        }
    });

    // Optional: hide some clutter on collage pages (keeps it "comfy")
    const garbageSelectors = [
        ".torrent_table",
        ".torrent_filter_box",
        "#collage_table + * ~ *:not([class='box']):not(br):not(#collage_comment_div)",
        "table + [class='box']:not(:last-child)",
        "#collage_table + br"
    ];

    garbageSelectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => {
            el.style.display = "none";
        });
    });
}

// Run immediately
makeDirectLinks();

// Re-run if bookmarks collage is dynamically loaded
if (document.getElementById("bookmarks_collage")) {
    new MutationObserver(() => makeDirectLinks()).observe(document.getElementById("bookmarks_collage"), {
        childList: true,
        subtree: true
    });
}