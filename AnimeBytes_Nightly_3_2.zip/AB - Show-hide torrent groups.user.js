// ==UserScript==
// @name         AB - Show/hide torrent groups
// @version      0.1
// @description  Makes torrent groups collapsible on series/franchise pages and adds buttons to show/hide all groups
// @author       _placeholder
// @match        https://animebytes.tv/series.php*
// @icon         https://animebytes.tv/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    const startCollapsed = false;

    function getGroups(tables){
        let groups = [];
        tables.forEach(table => {
            const tableChildren = Array.from(table.children[0].children);
            let currentGroup = null;
            tableChildren.forEach((tag) => {
                if (tag.classList.contains("group")) {
                    if (currentGroup) {
                        groups.push(currentGroup);
                    }
                    currentGroup = [tag];
                } else if (currentGroup) {
                    currentGroup.push(tag);
                }
            });
            if (currentGroup) {
                groups.push(currentGroup);
            }
        });
        groups = groups.map(group => ({header: group[0], rows: group.slice(1), hidden: false}));
        return groups;
    }

    function showGroup(group){
        if(group.hidden) toggleGroup(group);
    }

    function hideGroup(group){
        if(!group.hidden) toggleGroup(group);
    }

    function toggleGroup(group){
        const groupTitle = group.header.querySelector("h3");
        if (groupTitle){
            const hideText = groupTitle.querySelector(".hidetext");
            if (hideText){
                hideText.textContent = group.hidden ? " (Hide)" : " (Show)";

                // show/hide tags inside group header (bit hacky because i also want to hide whitespace)
                if(!group.hidden){
                    // wrap all tags except group title in a div and hide it
                    const nodesToHide = Array.from(group.header.children[0].childNodes).filter(node => node !== groupTitle);
                    const tagsDiv = document.createElement("div");
                    tagsDiv.className = "hiddentags";
                    tagsDiv.style.display = "none";
                    nodesToHide.forEach(node => tagsDiv.appendChild(node));
                    group.header.children[0].insertBefore(tagsDiv, groupTitle.nextSibling);

                } else{
                    // unwrap tags from div and show them
                    const tagsDiv = group.header.querySelector(".hiddentags");
                    if (tagsDiv) {
                        const nodesToUnhide = Array.from(tagsDiv.childNodes);
                        nodesToUnhide.forEach(node => group.header.children[0].appendChild(node));
                        tagsDiv.remove();
                    }
                }

                // show/hide rows in the group
                group.rows.forEach(row => {
                    row.style.display = group.hidden ? "" : "none";
                });
            }
        }
        group.hidden = !group.hidden;
    }

    const tables = document.querySelectorAll(".torrent_table");
    const groups = getGroups(tables);

    // make groups collapsible
    groups.forEach(group => {
        const groupTitle = group.header.querySelector("h3");
        if (groupTitle) {
            const hideText = document.createElement("a");
            hideText.className = "hidetext";
            hideText.textContent = " (Hide)";
            hideText.addEventListener("click", (event) => {
                event.preventDefault();
                toggleGroup(group);
            });
            groupTitle.appendChild(hideText);
        }
    });

    if(startCollapsed){
        groups.forEach(group => hideGroup(group));
    }

    // add buttons to collapse/expand all groups
    const box = document.querySelector(".box.center");
    box.appendChild(document.createElement("br"));

    const collapseAll = document.createElement("a");
    collapseAll.textContent = "Collapse All";
    collapseAll.href = "#";
    collapseAll.addEventListener("click", (event) => {
        event.preventDefault();
        groups.forEach(group => hideGroup(group));
    });
    box.appendChild(collapseAll);

    const textNode = document.createTextNode(" | ");
    box.appendChild(textNode);

    const showAll = document.createElement("a");
    showAll.textContent = "Show All";
    showAll.href = "#";
    showAll.addEventListener("click", (event) => {
        event.preventDefault();
        groups.forEach(group => showGroup(group));
    });
    box.appendChild(showAll);

})();