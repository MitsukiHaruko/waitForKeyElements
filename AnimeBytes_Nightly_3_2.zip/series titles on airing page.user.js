// ==UserScript==
// @name         series titles on airing page
// @namespace    Violentmonkey Scripts
// @match        https://animebytes.tv/airing*
// @grant        none
// @version      1.0
// @author       metonym
// @description  add the series title below poster images on the airing page
// @icon         https://animebytes.tv/favicon.ico
// ==/UserScript==

function insertTitles() {
  'use strict';
  let elms = document.querySelectorAll("td > a");
  elms.forEach((elm) => {
    let title = elm.firstElementChild.title;
    var seriesTitleBox = document.createElement("div");
    seriesTitleBox.innerText = title;
    seriesTitleBox.className = "nym_series_title";
    elm.appendChild(seriesTitleBox);
  });
}

insertTitles();